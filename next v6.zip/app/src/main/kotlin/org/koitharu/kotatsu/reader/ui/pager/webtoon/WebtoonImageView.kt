package org.koitharu.kotatsu.reader.ui.pager.webtoon

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView
import org.koitharu.kotatsu.core.util.ext.resolveDp
import kotlin.math.roundToInt

class WebtoonImageView @JvmOverloads constructor(
    context: Context,
    attr: AttributeSet? = null,
) : SubsamplingScaleImageView(context, attr) {

    private val ct = PointF()

    private var scrollPos = 0
    private var pendingScrollPos = -1
    private var debugPaint: Paint? = null
    private var host: RecyclerView? = null

    /** How far beyond the visible part of the list tiles are decoded, in list heights. */
    var prefetchFraction = 1f

    private val prefetchMargin: Int
        get() = ((host?.height ?: height) * prefetchFraction).toInt()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        host = findHost()
    }

    override fun onDetachedFromWindow() {
        host = null
        super.onDetachedFromWindow()
    }

    /**
     * A page is a viewport-sized window onto a very tall image and is itself only partly (or, while
     * prefetched, not at all) visible inside the list. Decode only what the list shows plus a margin,
     * not everything this view's bounds cover.
     */
    override fun computeTileWindow(out: Rect) {
        val rv = host
        if (rv == null || rv.height <= 0) {
            super.computeTileWindow(out)
            return
        }
        val margin = prefetchMargin
        out.set(0, -margin, rv.width, rv.height + margin)
        try {
            rv.offsetRectIntoDescendantCoords(this, out)
        } catch (_: IllegalArgumentException) {
            super.computeTileWindow(out)
        }
    }

    override fun isTileLoadingDeferred(): Boolean = (host as? WebtoonRecyclerView)?.isFastScrolling == true

    override val tileKeepSlop: Int
        get() = prefetchMargin / 2

    private fun findHost(): RecyclerView? {
        var p = parent
        while (p != null && p !is RecyclerView) {
            p = p.parent
        }
        return p as? RecyclerView
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (isDebugDrawingEnabled) {
            drawDebug(canvas)
        }
    }

    fun scrollBy(delta: Int) {
        val maxScroll = getScrollRange()
        if (maxScroll == 0) {
            return
        }
        val newScroll = scrollPos + delta
        scrollToInternal(newScroll.coerceIn(0, maxScroll))
    }

    fun scrollTo(y: Int) {
        val maxScroll = getScrollRange()
        if (maxScroll == 0) {
            scrollToInternal(0)
            return
        }
        scrollToInternal(y.coerceIn(0, maxScroll))
    }

    fun getScroll() = scrollPos

    fun getScrollRange(): Int {
        if (!isReady) {
            return 0
        }
        val totalHeight = (sHeight * width / sWidth.toFloat()).roundToInt()
        return (totalHeight - height).coerceAtLeast(0)
    }

    /**
     * [getScrollRange] reports `0` both for an image shorter than the view and for one that has not been
     * decoded yet, and callers cannot tell those apart. Without this guard the second case divides by
     * `sWidth == 0`: float division yields `Infinity` rather than throwing, so `minScale` and `maxScale`
     * both become infinite, and SSIV clamps the image to that scale as soon as it does decode - the page
     * then renders as a hugely magnified crop, silently and only in webtoon mode.
     */
    private fun canScale(): Boolean = isReady && sWidth > 0 && sHeight > 0 && width > 0

    override fun recycle() {
        scrollPos = 0
        pendingScrollPos = -1
        super.recycle()
    }

    override fun getSuggestedMinimumHeight(): Int {
        var desiredHeight = super.getSuggestedMinimumHeight()
        if (sHeight == 0) {
            val parentHeight = parentHeight()
            if (desiredHeight < parentHeight) {
                desiredHeight = parentHeight
            }
        }
        return desiredHeight
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val widthSpecMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightSpecMode = MeasureSpec.getMode(heightMeasureSpec)
        val parentWidth = MeasureSpec.getSize(widthMeasureSpec)
        val parentHeight = MeasureSpec.getSize(heightMeasureSpec)
        val resizeWidth = widthSpecMode != MeasureSpec.EXACTLY
        val resizeHeight = heightSpecMode != MeasureSpec.EXACTLY
        var desiredWidth = parentWidth
        var desiredHeight = parentHeight
        if (sWidth > 0 && sHeight > 0) {
            if (resizeWidth && resizeHeight) {
                desiredWidth = sWidth
                desiredHeight = sHeight
            } else if (resizeHeight) {
                desiredHeight = (sHeight.toDouble() / sWidth.toDouble() * desiredWidth).toInt()
            } else if (resizeWidth) {
                desiredWidth = (sWidth.toDouble() / sHeight.toDouble() * desiredHeight).toInt()
            }
        }
        desiredWidth = desiredWidth.coerceAtLeast(suggestedMinimumWidth)
        desiredHeight = desiredHeight.coerceAtLeast(suggestedMinimumHeight)
        // A page is never taller than the viewport - it scrolls internally instead - but only cap when
        // the viewport height is actually known. parentHeight() is 0 whenever this view is measured
        // without a RecyclerView above it (while detached, or before being attached), and capping to
        // that collapses the page to zero height, which reads as two pages running into each other.
        val viewportHeight = parentHeight()
        if (viewportHeight > 0) {
            desiredHeight = desiredHeight.coerceAtMost(viewportHeight)
        }
        setMeasuredDimension(desiredWidth, desiredHeight)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        // Apply any scroll deferred by scrollToAfterLayout(). This handles the race where
        // adjustScale() → requestLayout() → onSizeChanged() overwrites the pendingCenter
        // that scrollToInternal() had just set via setScaleAndCenter().
        val pending = pendingScrollPos
        if (pending >= 0) {
            pendingScrollPos = -1
            scrollToInternal(pending.coerceIn(0, getScrollRange()))
        }
    }

    override fun onDownSamplingChanged() {
        super.onDownSamplingChanged()
        if (isReady) {
            adjustScale()
            onImageEventListener.onReady()
        }
    }

    override fun onReady() {
        super.onReady()
        adjustScale()
    }

    private fun scrollToInternal(pos: Int) {
        if (!canScale()) {
            scrollPos = 0
            return
        }
        minScale = width / sWidth.toFloat()
        maxScale = minScale
        scrollPos = pos
        ct.set(sWidth / 2f, (height / 2f + pos.toFloat()) / minScale)
        setScaleAndCenter(minScale, ct)
    }

    private fun adjustScale() {
        if (!canScale()) {
            return
        }
        minScale = width / sWidth.toFloat()
        maxScale = minScale
        minimumScaleType = SCALE_TYPE_CUSTOM
        requestLayout()
    }

    /**
     * Defers a scroll to [pos] until after the next layout pass.
     * Use instead of [scrollTo] when called from [onReady], because [adjustScale] triggers
     * [requestLayout] which causes [onSizeChanged] to overwrite the pendingCenter set by
     * [scrollToInternal], resulting in the wrong position being shown until the user scrolls.
     */
    fun scrollToAfterLayout(pos: Int) {
        pendingScrollPos = pos
        if (!isLayoutRequested) {
            requestLayout()
        }
    }

    private fun parentHeight(): Int = host?.height ?: findHost()?.height ?: 0

    private fun drawDebug(canvas: Canvas) {
        val paint = debugPaint ?: Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.RED
            strokeWidth = context.resources.resolveDp(2f)
            textAlign = Paint.Align.LEFT
            textSize = context.resources.resolveDp(14f)
            debugPaint = this
        }
        paint.style = Paint.Style.STROKE
        canvas.drawRect(1f, 1f, width.toFloat() - 1f, height.toFloat() - 1f, paint)
        paint.style = Paint.Style.FILL
        canvas.drawText("${getScroll()} / ${getScrollRange()}", 100f, 100f, paint)
    }
}
