package org.koitharu.kotatsu.settings.work

import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.util.ext.processLifecycleScope
import org.koitharu.kotatsu.suggestions.ui.SuggestionsWorker
import org.koitharu.kotatsu.sync.domain.SyncController
import org.koitharu.kotatsu.tracker.domain.TrackerUnstuckMigrationUseCase
import org.koitharu.kotatsu.tracker.work.TrackWorker
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton

@Singleton
class WorkScheduleManager @Inject constructor(
    private val settings: AppSettings,
    private val suggestionScheduler: SuggestionsWorker.Scheduler,
    private val trackerScheduler: TrackWorker.Scheduler,
    private val trackerUnstuckMigrationProvider: Provider<TrackerUnstuckMigrationUseCase>,
    private val syncController: SyncController,
) : SharedPreferences.OnSharedPreferenceChangeListener {

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        when (key) {
            AppSettings.KEY_TRACKER_ENABLED,
            AppSettings.KEY_TRACKER_FREQUENCY,
            AppSettings.KEY_TRACKER_WIFI_ONLY,
            -> updateWorker(
                scheduler = trackerScheduler,
                isEnabled = settings.isTrackerEnabled,
                force = key != AppSettings.KEY_TRACKER_ENABLED,
            )

            AppSettings.KEY_SUGGESTIONS,
            AppSettings.KEY_SUGGESTIONS_WIFI_ONLY,
            -> updateWorker(
                scheduler = suggestionScheduler,
                isEnabled = settings.isSuggestionsEnabled,
                force = key != AppSettings.KEY_SUGGESTIONS,
            )

            AppSettings.KEY_SYNC_PERIOD -> syncController.updateSyncSchedule()
        }
    }

    fun init() {
        settings.subscribe(this)
        processLifecycleScope.launch(Dispatchers.Default) {
            updateWorkerImpl(trackerScheduler, settings.isTrackerEnabled, true) // always force due to adaptive interval
            updateWorkerImpl(suggestionScheduler, settings.isSuggestionsEnabled, false)
        }
        processLifecycleScope.launch(Dispatchers.Default) {
            // Recovery for tracks bugged by the previous reader-side use case.
            // Runs at most once per install (gated by a settings flag).
            trackerUnstuckMigrationProvider.get().runIfNeeded()
        }
        processLifecycleScope.launch(Dispatchers.Default) {
            // Periodic syncs are registered with the system rather than WorkManager, so they have to be
            // re-asserted here for accounts added before this setting existed.
            syncController.updateSyncSchedule()
        }
    }

    private fun updateWorker(scheduler: PeriodicWorkScheduler, isEnabled: Boolean, force: Boolean) {
        processLifecycleScope.launch(Dispatchers.Default) {
            updateWorkerImpl(scheduler, isEnabled, force)
        }
    }

    private suspend fun updateWorkerImpl(scheduler: PeriodicWorkScheduler, isEnabled: Boolean, force: Boolean) {
        if (force || scheduler.isScheduled() != isEnabled) {
            if (isEnabled) {
                scheduler.schedule()
            } else {
                scheduler.unschedule()
            }
        }
    }
}
