package org.koitharu.kotatsu.core

import android.app.Application
import android.content.Context
import android.os.Build
import android.provider.SearchRecentSuggestions
import android.text.Html
import androidx.collection.arraySetOf
import androidx.core.content.ContextCompat
import androidx.room.InvalidationTracker
import androidx.work.WorkManager
import coil3.ImageLoader
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.gif.AnimatedImageDecoder
import coil3.gif.GifDecoder
import coil3.memory.MemoryCache
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import coil3.request.allowRgb565
import coil3.svg.SvgDecoder
import coil3.util.DebugLogger
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.ElementsIntoSet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.OkHttpClient
import org.koitharu.kotatsu.BuildConfig
import org.koitharu.kotatsu.backups.domain.BackupObserver
import org.koitharu.kotatsu.core.db.MangaDatabase
import org.koitharu.kotatsu.core.exceptions.resolve.CaptchaHandler
import org.koitharu.kotatsu.core.image.AnimationGatedDecoderFactory
import org.koitharu.kotatsu.core.image.AvifImageDecoder
import org.koitharu.kotatsu.core.image.CbzFetcher
import org.koitharu.kotatsu.core.image.MangaSourceHeaderInterceptor
import org.koitharu.kotatsu.core.image.codecs.NativeAnimatedDecoder
import org.koitharu.kotatsu.core.image.codecs.NativeStillDecoder
import org.koitharu.kotatsu.core.network.MangaHttpClient
import org.koitharu.kotatsu.core.network.imageproxy.ImageProxyInterceptor
import org.koitharu.kotatsu.core.os.AppShortcutManager
import org.koitharu.kotatsu.core.os.NetworkState
import org.koitharu.kotatsu.core.parser.MangaLoaderContextImpl
import org.koitharu.kotatsu.core.parser.favicon.FaviconFetcher
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.ui.image.CoilImageGetter
import org.koitharu.kotatsu.core.ui.util.ActivityRecreationHandle
import org.koitharu.kotatsu.core.ui.util.ForegroundActivityHolder
import org.koitharu.kotatsu.core.util.AcraScreenLogger
import org.koitharu.kotatsu.core.util.FileSize
import org.koitharu.kotatsu.core.util.ext.connectivityManager
import org.koitharu.kotatsu.core.util.ext.isLowRamDevice
import org.koitharu.kotatsu.core.util.ext.isMemoryConstrained
import org.koitharu.kotatsu.details.ui.pager.pages.MangaPageFetcher
import org.koitharu.kotatsu.details.ui.pager.pages.MangaPageKeyer
import org.koitharu.kotatsu.local.data.CacheDir
import org.koitharu.kotatsu.local.data.FaviconCache
import org.koitharu.kotatsu.local.data.LocalStorageCache
import org.koitharu.kotatsu.local.data.LocalStorageChanges
import org.koitharu.kotatsu.local.data.PageCache
import org.koitharu.kotatsu.local.domain.model.LocalManga
import org.koitharu.kotatsu.main.domain.CoverRestoreInterceptor
import org.koitharu.kotatsu.main.ui.protect.AppProtectHelper
import org.koitharu.kotatsu.main.ui.protect.ScreenshotPolicyHelper
import org.koitharu.kotatsu.parsers.MangaLoaderContext
import org.koitharu.kotatsu.search.ui.MangaSuggestionsProvider
import org.koitharu.kotatsu.sync.domain.SyncController
import org.koitharu.kotatsu.widget.WidgetUpdater
import javax.inject.Provider
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
interface AppModule {

    @Binds
    fun bindMangaLoaderContext(mangaLoaderContextImpl: MangaLoaderContextImpl): MangaLoaderContext

    @Binds
    fun bindImageGetter(coilImageGetter: CoilImageGetter): Html.ImageGetter

    companion object {

        @Provides
        @LocalizedAppContext
        fun provideLocalizedContext(
            @ApplicationContext context: Context,
        ): Context = ContextCompat.getContextForLanguage(context)

        @Provides
        @Singleton
        fun provideNetworkState(
            @ApplicationContext context: Context,
            settings: AppSettings,
        ) = NetworkState(context.connectivityManager, settings)

        @Provides
        @Singleton
        fun provideMangaDatabase(
            @ApplicationContext context: Context,
        ): MangaDatabase = MangaDatabase(context)

        @Provides
        @Singleton
        fun provideCoil(
            @LocalizedAppContext context: Context,
            @MangaHttpClient okHttpClientProvider: Provider<OkHttpClient>,
            faviconFetcherFactory: FaviconFetcher.Factory,
            imageProxyInterceptor: ImageProxyInterceptor,
            pageFetcherFactory: MangaPageFetcher.Factory,
            coverRestoreInterceptor: CoverRestoreInterceptor,
            networkStateProvider: Provider<NetworkState>,
            captchaHandler: CaptchaHandler,
            settings: AppSettings,
        ): ImageLoader {
            val diskCacheFactory = {
                val rootDir = context.externalCacheDir ?: context.cacheDir
                DiskCache.Builder()
                    .directory(rootDir.resolve(CacheDir.THUMBS.dir))
                    .build()
            }
            val okHttpClientLazy = lazy {
                okHttpClientProvider.get().newBuilder().cache(null).build()
            }
            return ImageLoader.Builder(context)
                .interceptorCoroutineContext(Dispatchers.Default)
                .diskCache(diskCacheFactory)
                .logger(if (BuildConfig.DEBUG) DebugLogger() else null)
                .allowRgb565(context.isLowRamDevice())
                .apply {
                    // Coil's default budget (25% of the heap) competes with the reader's tile bitmaps; use
                    // its low-RAM budget (15%) on small devices. Coil trims it itself on onTrimMemory.
                    if (context.isMemoryConstrained()) {
                        memoryCache { MemoryCache.Builder().maxSizePercent(context, 0.15).build() }
                    }
                }
                .eventListener(captchaHandler)
                .components {
                    add(
                        OkHttpNetworkFetcherFactory(
                            callFactory = okHttpClientLazy::value,
                            connectivityChecker = { networkStateProvider.get() },
                        ),
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        add(AnimationGatedDecoderFactory(AnimatedImageDecoder.Factory()))
                    } else {
                        add(AnimationGatedDecoderFactory(GifDecoder.Factory()))
                    }
                    add(AnimationGatedDecoderFactory(NativeAnimatedDecoder.Factory { settings.isMemorySaverEnabled }))
                    add(NativeStillDecoder.Factory())
                    add(SvgDecoder.Factory())
                    add(CbzFetcher.Factory())
                    add(AvifImageDecoder.Factory())
                    add(faviconFetcherFactory)
                    add(MangaPageKeyer())
                    add(pageFetcherFactory)
                    add(imageProxyInterceptor)
                    add(coverRestoreInterceptor)
                    add(MangaSourceHeaderInterceptor())
                }.build()
        }

        @Provides
        fun provideSearchSuggestions(
            @ApplicationContext context: Context,
        ): SearchRecentSuggestions = MangaSuggestionsProvider.createSuggestions(context)

        @Provides
        @ElementsIntoSet
        fun provideDatabaseObservers(
            widgetUpdater: WidgetUpdater,
            appShortcutManager: AppShortcutManager,
            backupObserver: BackupObserver,
            syncController: SyncController,
        ): Set<@JvmSuppressWildcards InvalidationTracker.Observer> = arraySetOf(
            widgetUpdater,
            appShortcutManager,
            backupObserver,
            syncController,
        )

        @Provides
        @ElementsIntoSet
        fun provideActivityLifecycleCallbacks(
            appProtectHelper: AppProtectHelper,
            activityRecreationHandle: ActivityRecreationHandle,
            acraScreenLogger: AcraScreenLogger,
            screenshotPolicyHelper: ScreenshotPolicyHelper,
            foregroundActivityHolder: ForegroundActivityHolder,
        ): Set<@JvmSuppressWildcards Application.ActivityLifecycleCallbacks> = arraySetOf(
            appProtectHelper,
            activityRecreationHandle,
            acraScreenLogger,
            screenshotPolicyHelper,
            foregroundActivityHolder,
        )

        @Provides
        @Singleton
        @LocalStorageChanges
        fun provideMutableLocalStorageChangesFlow(): MutableSharedFlow<LocalManga?> = MutableSharedFlow()

        @Provides
        @LocalStorageChanges
        fun provideLocalStorageChangesFlow(
            @LocalStorageChanges flow: MutableSharedFlow<LocalManga?>,
        ): SharedFlow<LocalManga?> = flow.asSharedFlow()

        @Provides
        fun provideWorkManager(
            @ApplicationContext context: Context,
        ): WorkManager = WorkManager.getInstance(context)

        @Provides
        @Singleton
        @PageCache
        fun providePageCache(
            @ApplicationContext context: Context,
        ) = LocalStorageCache(
            context = context,
            dir = CacheDir.PAGES,
            defaultSize = FileSize.MEGABYTES.convert(200, FileSize.BYTES),
            minSize = FileSize.MEGABYTES.convert(20, FileSize.BYTES),
        )

        @Provides
        @Singleton
        @FaviconCache
        fun provideFaviconCache(
            @ApplicationContext context: Context,
        ) = LocalStorageCache(
            context = context,
            dir = CacheDir.FAVICONS,
            defaultSize = FileSize.MEGABYTES.convert(8, FileSize.BYTES),
            minSize = FileSize.MEGABYTES.convert(2, FileSize.BYTES),
        )
    }
}
