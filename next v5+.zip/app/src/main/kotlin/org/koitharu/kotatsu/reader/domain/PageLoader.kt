package org.koitharu.kotatsu.reader.domain

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Rect
import android.net.Uri
import androidx.annotation.AnyThread
import androidx.annotation.CheckResult
import androidx.collection.LongSparseArray
import androidx.collection.set
import androidx.core.net.toFile
import androidx.core.net.toUri
import coil3.BitmapImage
import coil3.Image
import coil3.ImageLoader
import coil3.request.ImageRequest
import coil3.request.transformations
import coil3.toBitmap
import com.davemorrissey.labs.subscaleview.ImageSource
import dagger.hilt.android.ActivityRetainedLifecycle
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.use
import org.jetbrains.annotations.Blocking
import org.koitharu.kotatsu.core.LocalizedAppContext
import org.koitharu.kotatsu.core.image.BitmapDecoderCompat
import org.koitharu.kotatsu.core.network.CommonHeaders
import org.koitharu.kotatsu.core.network.MangaHttpClient
import org.koitharu.kotatsu.core.network.imageproxy.ImageProxyInterceptor
import org.koitharu.kotatsu.core.os.NetworkState
import org.koitharu.kotatsu.core.parser.CachingMangaRepository
import org.koitharu.kotatsu.core.parser.MangaRepository
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.ui.image.TrimTransformation
import org.koitharu.kotatsu.core.util.FileSize
import org.koitharu.kotatsu.core.util.MimeTypes
import org.koitharu.kotatsu.core.util.ext.URI_SCHEME_ZIP
import org.koitharu.kotatsu.core.util.ext.cancelChildrenAndJoin
import org.koitharu.kotatsu.core.util.ext.compressToPNG
import org.koitharu.kotatsu.core.util.ext.ensureRamAtLeast
import org.koitharu.kotatsu.core.util.ext.ensureSuccess
import org.koitharu.kotatsu.core.util.ext.getCompletionResultOrNull
import org.koitharu.kotatsu.core.util.ext.isFileUri
import org.koitharu.kotatsu.core.util.ext.isNotEmpty
import org.koitharu.kotatsu.core.util.ext.isPowerSaveMode
import org.koitharu.kotatsu.core.util.ext.isZipUri
import org.koitharu.kotatsu.core.util.ext.lifecycleScope
import org.koitharu.kotatsu.core.util.ext.mangaSourceExtra
import org.koitharu.kotatsu.core.util.ext.printStackTraceDebug
import org.koitharu.kotatsu.core.util.ext.ramAvailable
import org.koitharu.kotatsu.core.util.ext.toMimeType
import org.koitharu.kotatsu.core.util.ext.use
import org.koitharu.kotatsu.core.util.ext.withProgress
import org.koitharu.kotatsu.core.util.progress.ProgressDeferred
import org.koitharu.kotatsu.download.ui.worker.DownloadSlowdownDispatcher
import org.koitharu.kotatsu.local.data.LocalStorageCache
import org.koitharu.kotatsu.local.data.PageCache
import org.koitharu.kotatsu.parsers.model.MangaPage
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.util.requireBody
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import org.koitharu.kotatsu.reader.ui.pager.ReaderPage
import java.io.File
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipFile
import javax.inject.Inject
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext

@ActivityRetainedScoped
class PageLoader
@Inject
constructor(
    @LocalizedAppContext private val context: Context,
    lifecycle: ActivityRetainedLifecycle,
    @MangaHttpClient private val okHttp: OkHttpClient,
    @PageCache private val cache: LocalStorageCache,
    private val coil: ImageLoader,
    private val settings: AppSettings,
    private val mangaRepositoryFactory: MangaRepository.Factory,
    private val imageProxyInterceptor: ImageProxyInterceptor,
    private val downloadSlowdownDispatcher: DownloadSlowdownDispatcher,
    private val networkState: NetworkState,
) {
    val loaderScope = lifecycle.lifecycleScope + InternalErrorHandler() + Dispatchers.Default

    private val tasks = LongSparseArray<ProgressDeferred<Uri, Float>>()

    // BUG 1 / PERF FIX: increased from 3 to 5 concurrent page downloads.
    // With 3 permits, rapid chapter switches could saturate all permits with prefetch
    // jobs, causing the user-triggered load to wait. 5 permits maintain throughput
    // while still protecting against runaway parallel requests on slow connections.
    // Dynamic concurrency: fewer parallel transfers (each buffers and decodes) on small devices, and
    // background prefetch can never take every permit, so a page the user is waiting for always has one.
    private val isConstrained = settings.isMemorySaverEnabled
    private val semaphore = Semaphore(if (isConstrained) PERMITS_CONSTRAINED else PERMITS_DEFAULT)
    private val prefetchGate = Semaphore(if (isConstrained) PREFETCH_PERMITS_CONSTRAINED else PREFETCH_PERMITS_DEFAULT)

    // BUG 1 FIX: replaced single shared Mutex with a per-URI deduplication map.
    // The original `convertLock = Mutex()` serialized ALL bitmap conversions globally:
    // if page 1 was converting (WEBP→PNG, could take 2-3 seconds), page 2 would wait
    // even though they're completely independent operations.
    // ConcurrentHashMap<uriKey, Deferred<Uri>> deduplicates only same-URI calls
    // (preventing double-conversion of the same file) while allowing different
    // pages to convert concurrently.
    private val conversionJobs = ConcurrentHashMap<String, Deferred<Uri>>()

    private val prefetchLock = Mutex()

    @Volatile
    private var repository: MangaRepository? = null
    private val prefetchQueue = ArrayDeque<MangaPage>()
    private val counter = AtomicInteger(0)

    // On constrained devices (≤2GB RAM) cap prefetch to 2 pages and require
    // ≥200MB free RAM instead of the default 6 pages / 80MB. This prevents
    // prefetch from filling RAM just before a high-res tile decode burst.
    private var prefetchQueueLimit =
        if (isConstrained) {
            PREFETCH_LIMIT_CONSTRAINED
        } else {
            PREFETCH_LIMIT_DEFAULT
        }
    private val edgeDetector = EdgeDetector(context)

    // Under memory pressure stop queueing speculative downloads; they are re-requested on demand.
    private val trimCallbacks =
        object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
                    loaderScope.launch { prefetchLock.withLock { prefetchQueue.clear() } }
                }
            }

            override fun onConfigurationChanged(newConfig: Configuration) = Unit

            @Deprecated("Deprecated in Java")
            override fun onLowMemory() = onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL)
        }

    init {
        context.registerComponentCallbacks(trimCallbacks)
        lifecycle.addOnClearedListener { context.unregisterComponentCallbacks(trimCallbacks) }
    }

    fun isPrefetchApplicable(): Boolean {
        val minRamMb = if (isConstrained) PREFETCH_MIN_RAM_MB_CONSTRAINED else PREFETCH_MIN_RAM_MB
        return repository is CachingMangaRepository &&
            settings.isPagesPreloadEnabled &&
            !context.isPowerSaveMode() &&
            !networkState.isRestricted() &&
            context.ramAvailable > FileSize.MEGABYTES.convert(minRamMb, FileSize.BYTES)
    }

    @AnyThread
    fun prefetch(pages: List<ReaderPage>) = loaderScope.launch {
        prefetchLock.withLock {
            for (page in pages.asReversed()) {
                if (synchronized(tasks) { tasks.containsKey(page.id) }) {
                    continue
                }
                prefetchQueue.offerFirst(page.toMangaPage())
                if (prefetchQueue.size > prefetchQueueLimit) {
                    prefetchQueue.pollLast()
                }
            }
        }
        if (counter.get() == 0) {
            onIdle()
        }
    }

    suspend fun loadPreview(page: MangaPage): ImageSource? {
        val preview = page.preview
        if (preview.isNullOrEmpty()) {
            return null
        }
        val request =
            ImageRequest
                .Builder(context)
                .data(preview)
                .mangaSourceExtra(page.source)
                .transformations(TrimTransformation())
                .build()
        return coil.execute(request).image?.toImageSource()
    }

    fun loadPageAsync(
        page: MangaPage,
        force: Boolean,
    ): ProgressDeferred<Uri, Float> {
        var task = synchronized(tasks) { tasks[page.id] }?.takeIf { it.isValid() }
        if (force) {
            task?.cancel()
        } else if (task?.isCancelled == false) {
            return task
        }
        task = loadPageAsyncImpl(page, skipCache = force, isPrefetch = false)
        synchronized(tasks) {
            tasks[page.id] = task
        }
        return task
    }

    suspend fun loadPage(
        page: MangaPage,
        force: Boolean,
    ): Uri = loadPageAsync(page, force).await()

    // BUG 1 FIX: renamed from convertBimap (typo) to convertBitmap.
    // Also switched from a global Mutex to a per-URI ConcurrentHashMap deduplication
    // so that different pages can convert concurrently.
    @CheckResult
    suspend fun convertBitmap(uri: Uri): Uri {
        val key = uri.toString()
        // If an identical conversion is already in-flight (e.g., two holders requesting
        // the same page), reuse the existing Deferred instead of starting a second one.
        // The job is created lazily and published atomically (putIfAbsent), so concurrent callers can
        // never start two conversions of the same file; the loser's job is never started.
        val candidate = loaderScope.async(start = CoroutineStart.LAZY) { doConvertBitmap(uri) }
        val existing = conversionJobs.putIfAbsent(key, candidate)
        if (existing != null) {
            candidate.cancel()
            return existing.await()
        }
        candidate.invokeOnCompletion { conversionJobs.remove(key, candidate) }
        return candidate.await()
    }

    // BUG 1 FIX: kept the old name as a deprecated alias so that any callers using the
    // original typo still compile without changes. They should migrate to convertBitmap.
    @Deprecated("Typo in original name — use convertBitmap()", ReplaceWith("convertBitmap(uri)"))
    @CheckResult
    suspend fun convertBimap(uri: Uri): Uri = convertBitmap(uri)

    private suspend fun doConvertBitmap(uri: Uri): Uri = if (uri.isZipUri()) {
        runInterruptible(Dispatchers.IO) {
            ZipFile(uri.schemeSpecificPart).use { zip ->
                val entry = zip.getEntry(uri.fragment)
                context.ensureRamAtLeast(entry.size * 2)
                zip.getInputStream(entry).use {
                    BitmapDecoderCompat.decode(it, MimeTypes.getMimeTypeFromExtension(entry.name))
                }
            }
        }.use { image ->
            cache.set(uri.toString(), image).toUri()
        }
    } else {
        val file = uri.toFile()
        runInterruptible(Dispatchers.IO) {
            context.ensureRamAtLeast(file.length() * 2)
            BitmapDecoderCompat.decode(file)
        }.use { image ->
            image.compressToPNG(file)
        }
        uri
    }

    suspend fun getTrimmedBounds(uri: Uri): Rect? = runCatchingCancellable {
        edgeDetector.getBounds(ImageSource.uri(uri))
    }.onFailure { error ->
        error.printStackTraceDebug()
    }.getOrNull()

    suspend fun getPageUrl(page: MangaPage): String = getRepository(page.source).getPageUrl(page)

    suspend fun invalidate(clearCache: Boolean) {
        synchronized(tasks) { tasks.clear() }
        prefetchLock.withLock { prefetchQueue.clear() }
        loaderScope.cancelChildrenAndJoin()
        if (clearCache) {
            cache.clear()
        }
    }

    private fun onIdle() = loaderScope.launch {
        prefetchLock.withLock {
            while (prefetchQueue.isNotEmpty()) {
                val page = prefetchQueue.pollFirst() ?: return@launch
                synchronized(tasks) {
                    // A task (user-initiated or already prefetched) must not be replaced and orphaned.
                    if (tasks[page.id]?.isValid() != true) {
                        tasks[page.id] = loadPageAsyncImpl(page, skipCache = false, isPrefetch = true)
                    }
                }
            }
        }
    }

    private fun loadPageAsyncImpl(
        page: MangaPage,
        skipCache: Boolean,
        isPrefetch: Boolean,
    ): ProgressDeferred<Uri, Float> {
        val progress = MutableStateFlow(PROGRESS_UNDEFINED)
        val deferred =
            loaderScope.async {
                counter.incrementAndGet()
                try {
                    val load =
                        suspend {
                            loadPageImpl(
                                page = page,
                                progress = progress,
                                isPrefetch = isPrefetch,
                                skipCache = skipCache,
                            )
                        }
                    if (isPrefetch) prefetchGate.withPermit { load() } else load()
                } finally {
                    if (counter.decrementAndGet() == 0) {
                        onIdle()
                    }
                }
            }
        return ProgressDeferred(deferred, progress)
    }

    @Synchronized
    private fun getRepository(source: MangaSource): MangaRepository {
        val result = repository
        return if (result != null && result.source == source) {
            result
        } else {
            mangaRepositoryFactory.create(source).also { repository = it }
        }
    }

    private suspend fun loadPageImpl(
        page: MangaPage,
        progress: MutableStateFlow<Float>,
        isPrefetch: Boolean,
        skipCache: Boolean,
    ): Uri = semaphore.withPermit {
        val pageUrl = getPageUrl(page)
        check(pageUrl.isNotBlank()) { "Cannot obtain full image url for $page" }
        if (!skipCache) {
            cache.get(pageUrl)?.let { return it.toUri() }
        }
        val uri = pageUrl.toUri()
        return when {
            uri.isZipUri() -> {
                if (uri.scheme == URI_SCHEME_ZIP) {
                    uri
                } else { // legacy uri
                    uri.buildUpon().scheme(URI_SCHEME_ZIP).build()
                }
            }

            uri.isFileUri() -> {
                uri
            }

            else -> {
                if (isPrefetch) {
                    downloadSlowdownDispatcher.delay(page.source)
                }
                val request = createPageRequest(pageUrl, page.source)
                imageProxyInterceptor
                    .interceptPageRequest(request, okHttp)
                    .ensureSuccess()
                    .use { response ->
                        response.requireBody().withProgress(progress).use {
                            cache.set(pageUrl, it.source(), it.contentType()?.toMimeType())
                        }
                    }.toUri()
            }
        }
    }

    private fun Image.toImageSource(): ImageSource = if (this is BitmapImage) {
        ImageSource.cachedBitmap(toBitmap())
    } else {
        ImageSource.bitmap(toBitmap())
    }

    private fun Deferred<Uri>.isValid(): Boolean = getCompletionResultOrNull()
        ?.map { uri ->
            uri.exists() && uri.isTargetNotEmpty()
        }?.getOrDefault(false) != false

    private class InternalErrorHandler :
        AbstractCoroutineContextElement(CoroutineExceptionHandler),
        CoroutineExceptionHandler {
        override fun handleException(
            context: CoroutineContext,
            exception: Throwable,
        ) {
            exception.printStackTraceDebug()
        }
    }

    companion object {
        private const val PROGRESS_UNDEFINED = -1f
        private const val PERMITS_DEFAULT = 5
        private const val PERMITS_CONSTRAINED = 3
        private const val PREFETCH_PERMITS_DEFAULT = 3
        private const val PREFETCH_PERMITS_CONSTRAINED = 2
        private const val PREFETCH_LIMIT_DEFAULT = 6
        private const val PREFETCH_LIMIT_CONSTRAINED = 2
        private const val PREFETCH_MIN_RAM_MB = 80L
        private const val PREFETCH_MIN_RAM_MB_CONSTRAINED = 200L

        fun createPageRequest(
            pageUrl: String,
            mangaSource: MangaSource,
        ) = Request
            .Builder()
            .url(pageUrl)
            .get()
            .header(CommonHeaders.ACCEPT, "image/webp,image/png;q=0.9,image/jpeg,*/*;q=0.8")
            .cacheControl(CommonHeaders.CACHE_CONTROL_NO_STORE)
            .tag(MangaSource::class.java, mangaSource)
            .build()

        @Blocking
        private fun Uri.exists(): Boolean = when {
            isFileUri() -> {
                toFile().exists()
            }

            isZipUri() -> {
                val file = File(requireNotNull(schemeSpecificPart))
                file.exists() && ZipFile(file).use { it.getEntry(fragment) != null }
            }

            else -> {
                false
            }
        }

        @Blocking
        private fun Uri.isTargetNotEmpty(): Boolean = when {
            isFileUri() -> {
                toFile().isNotEmpty()
            }

            isZipUri() -> {
                val file = File(requireNotNull(schemeSpecificPart))
                file.exists() && ZipFile(file).use { (it.getEntry(fragment)?.size ?: 0L) != 0L }
            }

            else -> {
                false
            }
        }
    }
}
