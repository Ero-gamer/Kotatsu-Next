<div align="center">
  <a href="https://github.com/Ero-gamer/support-palestine-banner/blob/master/Markdown-pages/Support.md">
    <img src="https://raw.githubusercontent.com/Ero-gamer/support-palestine-banner/master/banner-project.svg" alt="Support Palestine" width="100%" />
  </a>
</div>

<br>

<div align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=28&pause=1000&color=C792EA&center=true&vCenter=true&width=600&lines=Kotatsu+Next;Your+manga+universe%2C+FOSS+%26+free;11200%2B+sources+%7C+No+ads+%7C+Material+You" alt="Typing SVG" />
</div>

<br>

<div align="center">

[![Android](https://img.shields.io/badge/Android-6.0+-3DDC84?style=for-the-badge&logo=android&logoColor=white)](https://github.com/Ero-gamer/Kotatsu-Next)
[![License](https://img.shields.io/github/license/KotatsuApp/Kotatsu?style=for-the-badge&color=blue)](https://github.com/KotatsuApp/Kotatsu/blob/devel/LICENSE)
[![FOSS](https://img.shields.io/badge/FOSS-100%25-success?style=for-the-badge)](https://github.com/Ero-gamer/Kotatsu-Next)
[![Stars](https://img.shields.io/github/stars/Ero-gamer/Kotatsu-Next?style=for-the-badge&color=yellow)](https://github.com/Ero-gamer/Kotatsu-Next/stargazers)
[![Forks](https://img.shields.io/github/forks/Ero-gamer/Kotatsu-Next?style=for-the-badge&color=orange)](https://github.com/Ero-gamer/Kotatsu-Next/network)
[![Total Downloads](https://img.shields.io/github/downloads/Ero-gamer/Kotatsu-Next/total?style=for-the-badge&color=blue&label=Downloads)](https://github.com/Ero-gamer/Kotatsu-Next/releases)
[![Latest Release](https://img.shields.io/github/v/release/Ero-gamer/Kotatsu-Next?style=for-the-badge&color=green&label=Latest)](https://github.com/Ero-gamer/Kotatsu-Next/releases/latest)

</div>

<br>

<div align="center">

> **Kotatsu Next** is a free, open-source manga · webtoon · manhua reader for Android,
> forked from [Kotatsu Redo](https://github.com/Kotatsu-Redo/Kotatsu-redo) with 1200+ built-in sources.
> The goal: preserve everything upstream does well, then make it better.

</div>

---

## ✨ Features at a Glance

<div align="center">

| 📚 Content | 🎨 Experience | 🔧 Utility |
|:---:|:---:|:---:|
| 1200+ manga sources | Material You UI | Cross-device sync |
| Search by name & genre | Standard + Webtoon reader | Password / fingerprint lock |
| Favorites & categories | Gesture controls | Offline downloads + CBZ |
| Reading history | Tablet & desktop optimized | Android 6.0+ support |
| Incognito mode | New chapter notifications | Tracker integrations |

</div>

<details>
<summary>📋 Kotatsu Next exclusive features</summary>
<br>

**°Vibrance and Sharpening image filters** - Vibrance restore full washed out colors and pop them out while preserving natural colors, perfect for manhua, webtoons and colored manga, while sharpening filter make blurry, bad scans look crisp and detailed (use with caution, still experimental and it's resources intensive)

**°Optimized & Increased Max zoom by 100% (2x) and implemented 3 double clicks Zoom cycle** Perfect for high resolution Manhua, webtoons and scans, now you can zoom and see fine details in highest clarity/visibility on your big screen.

**°Vertical Slider as extra customization**

**°Replaced default jpeg image decoder with JPEG Turbo lib** Best optimized jpeg image decoder for errors-free decoding even for large long strip images (bigger than 10000x5000 res Images that get decoded with visible bad tints in default jpeg decoder) and 2x to 6x faster than other jpeg decoders while using same resources overhead and even lower in certain cases.

**°Optimized Backup & Restore feature**

**°Implemented global setting for disabling auto CF captcha solver for all sources**

**°Native image pipeline** libjpeg-turbo tiled JPEG decoding plus optional Rust JPEG XL / animated PNG decoders (with automatic Skia fallback), wide-gamut JXL converted to sRGB, and smarter tile prefetch that skips formats without cheap region decoding (WebP/PNG/AVIF/GIF) to save RAM on low-end phones.

All other differences from upstream: [CHANGES.md](CHANGES.md). Docs: [docs/](docs/DOCUMENTATION.md) · Third-party licenses: [CREDITS.md](CREDITS.md)

</details>

<details>
<summary>📋 Full feature list</summary>
<br>

- 📚 **1200+ manga sources** — online catalogues with search by name, genre and more
- ⭐ **Favorites & history** — user-defined categories, bookmarks and incognito mode
- 📥 **Offline reading** — download manga; CBZ archives supported
- 🎨 **Material You UI** — optimized for phones, tablets and desktop
- 📖 **Customizable reader** — standard & webtoon modes with full gesture support
- 🔔 **Notifications** — new chapter alerts, updates feed and filtered recommendations
- 🔗 **Tracker integration** — Shikimori, AniList, MyAnimeList, Kitsu
- 🔒 **Privacy** — password / fingerprint protection
- 🔄 **Cross-device sync** — automatic sync across devices on the same account
- 📱 **Legacy support** — Android 6.0+

</details>

---

## 📸 Screenshots

<details>
<summary>Click to show/hide screenshots</summary>

<div align="center">

### 📱 Phone

<img src="./metadata/en-US/images/phoneScreenshots/1.png" alt="Phone 1" width="240"/>
<img src="./metadata/en-US/images/phoneScreenshots/2.png" alt="Phone 2" width="240"/>

### 🖥️ Tablet

<img src="./metadata/en-US/images/tenInchScreenshots/1.png" alt="Tablet 1" width="380"/>
<img src="./metadata/en-US/images/tenInchScreenshots/2.png" alt="Tablet 2" width="380"/>

</div>

</details>

---

## ☕ Support the Project

<div align="center">

*Kotatsu Next is and always will be 100% free.*
*If you'd like to fuel development, any donation is deeply appreciated* 🙏

</div>

<br>

![Bitcoin](https://img.shields.io/badge/Bitcoin-EAB300?style=for-the-badge&logo=Bitcoin%20SV&logoColor=white)
```
19Zks5VmhPtPPiZNHQUv71vfLyEeCtec2T
```

![Tether](https://img.shields.io/badge/USDT%20(TRC20)-168363?style=for-the-badge&logo=tether&logoColor=white)
```
TAxmtUbhiWEgY9bDQbgaaTPcmoS8EfJkKR
```

![Ethereum](https://img.shields.io/badge/Ethereum-3C3C3D?style=for-the-badge&logo=ethereum&logoColor=white)
```
0x7f92c4a838286a48f007419c9707f9096dc6675d
```

![Solana](https://img.shields.io/badge/Solana-9945FF?style=for-the-badge&logo=solana&logoColor=white)
```
5KCKZtKtYd9J5UB4VW3HJny4cBWKAJktmGUkfxsdsh9S
```

![TON](https://img.shields.io/badge/TON-0098EA?style=for-the-badge&logo=telegram&logoColor=white)
```
UQAN5OUU7YjxFPEPP0-LC62lWL_CF_LqgVhz9qjbvzLhb74F
```

![Binance](https://img.shields.io/badge/Binance%20ID%20(UID)-F0B90B?style=for-the-badge&logo=binance&logoColor=white)
```
583622748
```

---

> [!CAUTION]
> **Free and Open-Source Android is under threat.** Google will turn Android into a locked-down platform, restricting your freedom to install apps of your choice.
> Make your voice heard → [keepandroidopen.org](https://keepandroidopen.org/)

---

## 🤝 Contributing

<div align="center">

[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen?style=for-the-badge&logo=github)](https://github.com/Ero-gamer/Kotatsu-Next/blob/devel/CONTRIBUTING.md)

</div>

Have an idea or a fix? Pull requests are welcome!
Please read [CONTRIBUTING.md](https://github.com/Ero-gamer/Kotatsu-Next/blob/devel/CONTRIBUTING.md) before submitting.

---

## 📄 License

<div align="center">

[![GNU GPLv3](https://www.gnu.org/graphics/gplv3-127x51.png)](http://www.gnu.org/licenses/gpl-3.0.en.html)

</div>

You may copy, distribute and modify this software as long as you track changes/dates in source files. Any modifications to or software including (via compiler) GPL-licensed code must also be made available under the GPL along with build & install instructions.

---

<details>
<summary>⚠️ DMCA Disclaimer</summary>
<br>

The developers of this application have no affiliation with the content available in the app and do not store or distribute any content. This application should be considered a web browser — all content accessible through it is freely available on the Internet. All DMCA takedown requests should be sent to the owners of the website where the content is hosted.

</details>

---

## 🙏 Acknowledgments

Full list of open-source libraries (app and SSIV) with sources and licenses: [CREDITS.md](CREDITS.md).

<div align="center">

*Kotatsu Next stands on the shoulders of giants.*

</div>

Kotatsu Next is built upon the exceptional work of the [Kotatsu](https://github.com/KotatsuApp/Kotatsu) project — this fork wouldn't exist without it. Huge thanks to:

| Who | Why |
|---|---|
| [Kotatsu developers](https://github.com/KotatsuApp/Kotatsu) | For the outstanding open-source manga reader foundation |
| Kotatsu community | Contributions, testing and ongoing support |
| [Weblate translators](https://hosted.weblate.org/engage/kotatsu/) | Localizing Kotatsu for the world |
| [Kotatsu-Redo](https://github.com/Kotatsu-Redo/kotatsu-parsers-redo) | Continued parser development and maintenance |

<br>

<div align="center">

<img src="https://raw.githubusercontent.com/catppuccin/catppuccin/main/assets/footers/gray0_ctp_on_line.svg?sanitize=true" width="100%" alt="footer"/>

</div>
