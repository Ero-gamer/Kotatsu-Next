package org.koitharu.kotatsu.reader.ui

import android.app.assist.AssistContent
import android.content.DialogInterface
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.graphics.Insets
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.withResumed
import androidx.transition.Fade
import androidx.transition.Slide
import androidx.transition.TransitionManager
import androidx.transition.TransitionSet
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.exceptions.resolve.DialogErrorObserver
import org.koitharu.kotatsu.core.exceptions.resolve.SnackbarErrorObserver
import org.koitharu.kotatsu.core.model.ReaderTint
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.ReaderMode
import org.koitharu.kotatsu.core.ui.BaseFullscreenActivity
import org.koitharu.kotatsu.core.ui.dialog.buildAlertDialog
import org.koitharu.kotatsu.core.ui.dialog.setCheckbox
import org.koitharu.kotatsu.core.ui.util.MenuInvalidator
import org.koitharu.kotatsu.core.ui.widgets.ZoomControl
import org.koitharu.kotatsu.core.util.IdlingDetector
import org.koitharu.kotatsu.core.util.ext.getThemeDimensionPixelOffset
import org.koitharu.kotatsu.core.util.ext.hasGlobalPoint
import org.koitharu.kotatsu.core.util.ext.isAnimationsEnabled
import org.koitharu.kotatsu.core.util.ext.observe
import org.koitharu.kotatsu.core.util.ext.observeEvent
import org.koitharu.kotatsu.core.util.ext.postDelayed
import org.koitharu.kotatsu.core.util.ext.resolveDp
import org.koitharu.kotatsu.core.util.ext.setThumbVisible
import org.koitharu.kotatsu.core.util.ext.setValueRounded
import org.koitharu.kotatsu.core.util.ext.toUriOrNull
import org.koitharu.kotatsu.core.util.ext.zipWithPrevious
import org.koitharu.kotatsu.databinding.ActivityReaderBinding
import org.koitharu.kotatsu.details.ui.pager.pages.PagesSavedObserver
import org.koitharu.kotatsu.parsers.model.MangaChapter
import org.koitharu.kotatsu.reader.data.TapGridSettings
import org.koitharu.kotatsu.reader.domain.TapGridArea
import org.koitharu.kotatsu.reader.domain.erase.ImageHider
import org.koitharu.kotatsu.reader.domain.indexOfPosition
import org.koitharu.kotatsu.reader.domain.formatChapterNumber
import org.koitharu.kotatsu.reader.domain.missingChaptersBetween
import org.koitharu.kotatsu.reader.ui.config.CropMenu
import org.koitharu.kotatsu.reader.ui.config.ReaderConfigSheet
import org.koitharu.kotatsu.reader.ui.erase.EraseController
import org.koitharu.kotatsu.reader.ui.erase.ErasePageTarget
import org.koitharu.kotatsu.reader.ui.pager.ReaderPage
import org.koitharu.kotatsu.reader.ui.pager.ReaderUiState
import org.koitharu.kotatsu.reader.ui.tapgrid.TapGridDispatcher
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import javax.inject.Inject
import androidx.appcompat.R as appcompatR

@AndroidEntryPoint
class ReaderActivity :
    BaseFullscreenActivity<ActivityReaderBinding>(),
    TapGridDispatcher.OnGridTouchListener,
    ReaderConfigSheet.Callback,
    ReaderControlDelegate.OnInteractionListener,
    ReaderNavigationCallback,
    IdlingDetector.Callback,
    ZoomControl.ZoomControlListener,
    View.OnClickListener,
    ScrollTimerControlView.OnVisibilityChangeListener {

    @Inject
    lateinit var imageHider: ImageHider

    @Inject
    lateinit var settings: AppSettings

    @Inject
    lateinit var tapGridSettings: TapGridSettings

    @Inject
    lateinit var pageSaveHelperFactory: PageSaveHelper.Factory

    @Inject
    lateinit var scrollTimerFactory: ScrollTimer.Factory

    @Inject
    lateinit var screenOrientationHelper: ScreenOrientationHelper

    private val idlingDetector = IdlingDetector(TimeUnit.SECONDS.toMillis(10), this)

    private val viewModel: ReaderViewModel by viewModels()

    override val readerMode: ReaderMode?
        get() = readerManager.currentMode

    private lateinit var scrollTimer: ScrollTimer
    private lateinit var pageSaveHelper: PageSaveHelper
    private lateinit var touchHelper: TapGridDispatcher
    private var isTouchSuppressed = false
    private var isSuppressCancelSent = false
    private lateinit var eraseController: EraseController
    private var isVerticalSliderTracking = false
    private var isVerticalSliderChanged = false
    private lateinit var controlDelegate: ReaderControlDelegate
    private var gestureInsets: Insets = Insets.NONE
    private lateinit var readerManager: ReaderManager
    private val hideUiRunnable = Runnable { setUiIsVisible(false) }
    private var scrolledSinceUiShown = 0
    private var hideThresholdPx = 0 // refreshed in onResume: the setting changes only on the settings screen
    private val hideEInkFlashRunnable = Runnable { einkFlashView.isVisible = false }
    private lateinit var einkFlashView: View
    private var eInkFlashCounter = 0

    // Tracks whether the foldable device is in an unfolded state (half-opened or flat)
    private var isFoldUnfolded: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ActivityReaderBinding.inflate(layoutInflater))
        readerManager = ReaderManager(supportFragmentManager, viewBinding.container, settings)
        einkFlashView = createEInkFlashView()
        setDisplayHomeAsUp(isEnabled = true, showUpAsClose = false)
        touchHelper = TapGridDispatcher(viewBinding.root, this)
        scrollTimer = scrollTimerFactory.create(resources, this, this)
        pageSaveHelper = pageSaveHelperFactory.create(this)
        controlDelegate = ReaderControlDelegate(resources, settings, tapGridSettings, this)
        eraseController = EraseController(viewBinding.eraseOverlay, imageHider, lifecycleScope, EraseHost())
        val eraseBackCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() = eraseController.onBackPressed()
        }
        onBackPressedDispatcher.addCallback(this, eraseBackCallback)
        viewBinding.eraseOverlay.onActiveChanged = { eraseBackCallback.isEnabled = it }
        offerEraseTutorial()
        viewBinding.zoomControl.listener = this
        viewBinding.actionsView.listener = this
        viewBinding.actionsView.isVerticalSliderActive = isVerticalSliderUsable()
        viewBinding.buttonTimer?.setOnClickListener(this)
        idlingDetector.bindToLifecycle(this)
        screenOrientationHelper.applySettings()

        // Vertical page-switch slider
        // Mirrors the horizontal slider (ReaderActionsView): while dragging only the label follows
        // the thumb, the page is switched once on release.
        viewBinding.sliderVertical?.apply {
            addOnChangeListener { slider, value, fromUser ->
                if (!fromUser) return@addOnChangeListener
                val newPage = value.toInt()
                viewBinding.textViewCurrentPageVertical?.text = (newPage + 1).toString()
                slider.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                if (isVerticalSliderTracking) {
                    isVerticalSliderChanged = true
                } else {
                    switchPageTo(newPage)
                }
            }
            addOnSliderTouchListener(
                object : Slider.OnSliderTouchListener {
                    override fun onStartTrackingTouch(slider: Slider) {
                        // Material reports a tap as start-start-stop (the tap handler starts tracking a second
                        // time on ACTION_UP). Resetting the changed flag on that second start made every tap
                        // look like "nothing changed" and the page was never switched.
                        if (!isVerticalSliderTracking) {
                            isVerticalSliderChanged = false
                            isVerticalSliderTracking = true
                        }
                    }

                    override fun onStopTrackingTouch(slider: Slider) {
                        isVerticalSliderTracking = false
                        if (isVerticalSliderChanged) {
                            switchPageTo(slider.value.toInt())
                        }
                    }
                },
            )
        }
        viewBinding.buttonPrevVertical?.setOnClickListener { switchChapterBy(-1) }
        viewBinding.buttonNextVertical?.setOnClickListener { switchChapterBy(1) }
        viewModel.isBookmarkAdded.observe(this) { viewBinding.actionsView.isBookmarkAdded = it }
        viewModel.isColorFilterDisabled.observe(this) { viewBinding.actionsView.isColorFilterEnabled = !it }
        scrollTimer.isActive.observe(this) {
            updateScrollTimerButton()
            viewBinding.actionsView.setTimerActive(it)
        }
        viewBinding.timerControl.onVisibilityChangeListener = this
        viewBinding.timerControl.attach(scrollTimer, this)
        if (resources.getBoolean(R.bool.is_tablet)) {
            viewBinding.timerControl.updateLayoutParams<CoordinatorLayout.LayoutParams> {
                topMargin = marginEnd + getThemeDimensionPixelOffset(appcompatR.attr.actionBarSize)
            }
        }

        viewModel.onLoadingError.observeEvent(
            this,
            DialogErrorObserver(
                host = viewBinding.container,
                fragment = null,
                resolver = exceptionResolver,
                onResolved = { isResolved ->
                    if (isResolved) {
                        viewModel.reload()
                    } else if (viewModel.content.value.pages.isEmpty()) {
                        dispatchNavigateUp()
                    }
                },
            ),
        )
        viewModel.onError.observeEvent(
            this,
            SnackbarErrorObserver(
                host = viewBinding.container,
                fragment = null,
                resolver = exceptionResolver,
                onResolved = null,
            ),
        )
        viewModel.readerMode.observe(this, Lifecycle.State.STARTED, this::onInitReader)
        viewModel.onPageSaved.observeEvent(this, PagesSavedObserver(viewBinding.container))
        viewModel.uiState.zipWithPrevious().observe(this, this::onUiStateChanged)
        combine(
            viewModel.isLoading,
            viewModel.content.map { it.pages.isNotEmpty() }.distinctUntilChanged(),
            ::Pair,
        ).flowOn(Dispatchers.Default)
            .observe(this, this::onLoadingStateChanged)
        viewModel.isKeepScreenOnEnabled.observe(this, this::setKeepScreenOn)
        viewModel.isInfoBarTransparent.observe(this) { viewBinding.infoBar.drawBackground = !it }
        viewModel.isInfoBarEnabled.observe(this, ::onReaderBarChanged)
        viewModel.isBookmarkAdded.observe(this, MenuInvalidator(this))
        viewModel.onAskNsfwIncognito.observeEvent(this) { askForIncognitoMode() }
        viewModel.onShowToast.observeEvent(this) { msgId ->
            Snackbar.make(viewBinding.container, msgId, Snackbar.LENGTH_SHORT)
                .setAnchorView(viewBinding.toolbarDocked)
                .show()
        }
        viewModel.readerSettingsProducer.observe(this) {
            viewBinding.infoBar.applyColorScheme(isBlackOnWhite = it.background.isLight(this))
        }
        viewModel.isZoomControlsEnabled.observe(this) {
            viewBinding.zoomControl.isVisible = it
        }
        addMenuProvider(ReaderMenuProvider(viewModel) { router.openHiddenImages() })

        observeWindowLayout()

        // Apply initial double-mode considering foldable setting
        applyDoubleModeAuto()
    }

    override fun getParentActivityIntent(): Intent? {
        val manga = viewModel.getMangaOrNull() ?: return null
        return AppRouter.detailsIntent(this, manga)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (!viewBinding.timerControl.isVisible) {
            scrollTimer.onUserInteraction()
        }
        idlingDetector.onUserInteraction()
    }

    override fun onResume() {
        super.onResume()
        applyScreenOverlay()
        hideThresholdPx = resources.resolveDp(settings.readerHideThreshold.dp)
    }

    override fun onPause() {
        super.onPause()
        viewModel.onPause()
    }

    override fun onStop() {
        super.onStop()
        viewModel.onStop()
    }

    override fun onProvideAssistContent(outContent: AssistContent) {
        super.onProvideAssistContent(outContent)
        viewModel.getMangaOrNull()?.publicUrl?.toUriOrNull()?.let { outContent.webUri = it }
    }

    override fun isNsfwContent(): Flow<Boolean> = viewModel.isMangaNsfw

    override fun onIdle() {
        viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
        viewModel.onIdle()
    }

    override fun onVisibilityChanged(v: View, visibility: Int) {
        updateScrollTimerButton()
    }

    override fun onZoomIn() {
        readerManager.currentReader?.onZoomIn()
    }

    override fun onZoomOut() {
        readerManager.currentReader?.onZoomOut()
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.button_timer -> onScrollTimerClick(isLongClick = false)
        }
    }

    /** Once, the first time a chapter is on screen in webtoon mode. Leaving halfway offers it again next time. */
    private fun offerEraseTutorial() {
        if (!settings.isReaderEraseGestureEnabled || !settings.isTipEnabled(AppSettings.TIP_ERASE_TUTORIAL)) {
            return
        }
        lifecycleScope.launch {
            combine(viewModel.readerMode, viewModel.content) { mode, content ->
                mode == ReaderMode.WEBTOON && content.pages.isNotEmpty()
            }.first { it }
            // The first page needs a moment to be there to practise on
            delay(ERASE_TUTORIAL_DELAY_MS)
            withResumed { startEraseTutorial() }
        }
    }

    private fun startEraseTutorial() {
        val tutorial = viewBinding.eraseTutorial
        tutorial.onFinished = {
            eraseController.practice = null
            viewBinding.eraseOverlay.cancel()
            settings.closeTip(AppSettings.TIP_ERASE_TUTORIAL)
        }
        eraseController.practice = tutorial
        tutorial.start()
    }

    private fun onInitReader(mode: ReaderMode?) {
        if (mode == null) {
            return
        }
        if (mode != ReaderMode.WEBTOON && eraseController.practice != null) {
            eraseController.practice = null
            viewBinding.eraseTutorial.stop()
        }
        if (readerManager.currentMode != mode) {
            readerManager.replace(mode)
        }
        if (viewBinding.appbarTop.isVisible) {
            lifecycle.postDelayed(TimeUnit.SECONDS.toMillis(1), hideUiRunnable)
        }
        viewBinding.actionsView.setSliderReversed(mode == ReaderMode.REVERSED)
        viewBinding.timerControl.onReaderModeChanged(mode)
    }

    private fun onLoadingStateChanged(value: Pair<Boolean, Boolean>) {
        val (isLoading, hasPages) = value
        val showLoadingLayout = isLoading && !hasPages
        if (viewBinding.layoutLoading.isVisible != showLoadingLayout) {
            val transition = Fade().addTarget(viewBinding.layoutLoading)
            TransitionManager.beginDelayedTransition(viewBinding.root, transition)
            viewBinding.layoutLoading.isVisible = showLoadingLayout
        }
        if (isLoading && hasPages) {
            viewBinding.toastView.show(R.string.loading_)
        } else {
            viewBinding.toastView.hide()
        }
        invalidateOptionsMenu()
    }

    override fun onGridTouch(area: TapGridArea): Boolean = isReaderResumed() && controlDelegate.onGridTouch(area)

    override fun onGridLongTouch(area: TapGridArea) {
        if (isReaderResumed() && controlDelegate.onGridLongTouch(area)) {
            // DS-6: the finger is still down; the rest of this touch must not drift the pages
            isTouchSuppressed = true
            isSuppressCancelSent = false
        }
    }

    override fun onProcessTouch(rawX: Int, rawY: Int): Boolean = if (
        rawX <= gestureInsets.left ||
        rawY <= gestureInsets.top ||
        rawX >= viewBinding.root.width - gestureInsets.right ||
        rawY >= viewBinding.root.height - gestureInsets.bottom ||
        viewBinding.appbarTop.hasGlobalPoint(rawX, rawY) ||
        viewBinding.toolbarDocked?.hasGlobalPoint(rawX, rawY) == true
    ) {
        false
    } else {
        val touchables = window.peekDecorView()?.touchables
        touchables?.none { it.hasGlobalPoint(rawX, rawY) } != false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (isTouchSuppressed) {
            val action = ev.actionMasked
            if (action == MotionEvent.ACTION_DOWN) {
                isTouchSuppressed = false
            } else {
                touchHelper.dispatchTouchEvent(ev) // keeps the detector's state clean
                // Children get one ACTION_CANCEL, the rest of the gesture is swallowed until the finger is up
                if (!isSuppressCancelSent) {
                    isSuppressCancelSent = true
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                }
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    isTouchSuppressed = false
                }
                return true
            }
        }
        when (eraseController.onTouchEvent(ev)) {
            EraseController.TouchResult.NOT_CLAIMED -> Unit
            EraseController.TouchResult.CONSUMED -> return true
            EraseController.TouchResult.TO_OVERLAY -> return super.dispatchTouchEvent(ev)
        }
        touchHelper.dispatchTouchEvent(ev)
        if (!viewBinding.timerControl.hasGlobalPoint(ev.rawX.toInt(), ev.rawY.toInt())) {
            scrollTimer.onTouchEvent(ev)
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = controlDelegate.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event)

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean = controlDelegate.onKeyUp(keyCode, event) || super.onKeyUp(keyCode, event)

    override fun onChapterSelected(chapter: MangaChapter): Boolean {
        viewModel.switchChapter(chapter.id, 0)
        return true
    }

    override fun onPageSelected(page: ReaderPage): Boolean {
        lifecycleScope.launch(Dispatchers.Default) {
            val pages = viewModel.content.value.pages
            var index = pages.indexOfFirst { it.chapterId == page.chapterId && it.id == page.id }
            if (index == -1) {
                // The page slider counts every page of the chapter, including those since hidden
                index = pages.indexOfPosition(page.chapterId, page.index) ?: -1
            }
            if (index != -1) {
                withContext(Dispatchers.Main) {
                    readerManager.currentReader?.switchPageTo(index, true)
                }
            } else {
                viewModel.switchChapter(page.chapterId, page.index)
            }
        }
        return true
    }

    override fun onReaderModeChanged(mode: ReaderMode) {
        viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
        viewModel.switchMode(mode)
        viewBinding.timerControl.onReaderModeChanged(mode)
        viewBinding.toastView.showTemporary(
            getString(
                when (mode) {
                    ReaderMode.STANDARD -> R.string.standard
                    ReaderMode.REVERSED -> R.string.right_to_left
                    ReaderMode.VERTICAL -> R.string.vertical
                    ReaderMode.BOTTOM_TO_TOP -> R.string.bottom_to_top
                    ReaderMode.WEBTOON -> R.string.webtoon
                },
            ),
            TOAST_DURATION,
        )
    }

    override fun onDoubleModeChanged(isEnabled: Boolean) {
        // Combine manual toggle with foldable auto setting
        applyDoubleModeAuto(isEnabled)
    }

    override fun onVerticalSliderChanged(isEnabled: Boolean) {
        val usable = isEnabled && viewBinding.containerSliderVertical != null
        viewBinding.actionsView.isVerticalSliderActive = usable
        viewBinding.actionsView.isSliderEnabled = !usable && (viewModel.uiState.value?.isSliderAvailable() == true)
        val sliderAvailable = viewModel.uiState.value?.isSliderAvailable() == true
        if (usable && sliderAvailable) {
            setUiIsVisible(true)
        } else {
            setVerticalSliderVisible(false)
            if (viewBinding.appbarTop.isVisible) setUiIsVisible(false)
        }
    }

    private fun applyDoubleModeAuto(manualEnabled: Boolean? = null) {
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        // Auto double-page on foldable when device is unfolded (half-opened or flat)
        val autoFoldable = settings.isReaderDoubleOnFoldable && isFoldUnfolded
        val manualLandscape = (manualEnabled ?: settings.isReaderDoubleOnLandscape) && isLandscape
        val autoEnabled = autoFoldable || manualLandscape
        readerManager.setDoubleReaderMode(autoEnabled)
    }

    /** Window brightness, color overlay and dim layer from the reader settings (re-read on every resume). */
    // Last applied values: onResume repeats this, and a window-attributes write is an IPC + relayout.
    private var appliedBrightness = Int.MIN_VALUE
    private var appliedDim = Int.MIN_VALUE
    private var appliedTint: ReaderTint? = null
    private var appliedTintStrength = Int.MIN_VALUE

    private fun applyScreenOverlay() {
        val brightness = settings.readerBrightness
        if (brightness != appliedBrightness) {
            appliedBrightness = brightness
            window.attributes = window.attributes.also {
                it.screenBrightness = if (brightness > 0) {
                    (brightness / 100f).coerceAtLeast(MIN_WINDOW_BRIGHTNESS)
                } else {
                    WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                }
            }
        }
        val dim = settings.readerDim
        if (dim != appliedDim) {
            appliedDim = dim
            viewBinding.overlayDim?.isVisible = dim > 0
            viewBinding.overlayDim?.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        }
        val tint = settings.readerTint
        val strength = settings.readerTintStrength
        if (tint != appliedTint || strength != appliedTintStrength) {
            appliedTint = tint
            appliedTintStrength = strength
            viewBinding.overlayTint?.isVisible = tint != ReaderTint.OFF && strength > 0
            viewBinding.overlayTint?.setBackgroundColor((strength * 255 / 100 shl 24) or tint.rgb)
        }
    }

    private fun setKeepScreenOn(isKeep: Boolean) {
        if (isKeep) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private inner class EraseHost : EraseController.Host {

        override val isEraseGestureEnabled: Boolean
            get() = settings.isReaderEraseGestureEnabled

        override val mangaTitle: String?
            get() = viewModel.getMangaOrNull()?.title

        override val pageBackgroundColor: Int
            get() = if (viewModel.readerSettingsProducer.value.background.isLight(this@ReaderActivity)) {
                Color.WHITE
            } else {
                Color.BLACK
            }

        override fun canStartEraseAt(rawX: Int, rawY: Int): Boolean = onProcessTouch(rawX, rawY)

        override fun findEraseTarget(rawX: Float, rawY: Float): ErasePageTarget? =
            readerManager.currentReader?.findPageHolderAt(rawX.toInt(), rawY.toInt())?.createEraseTarget()

        override suspend fun findNeighbourImages(page: ReaderPage): List<Uri> = viewModel.loadNeighbourImages(page)

        override fun cancelTouchFor(event: MotionEvent) {
            val cancel = MotionEvent.obtain(event)
            cancel.action = MotionEvent.ACTION_CANCEL
            touchHelper.dispatchTouchEvent(cancel)
            scrollTimer.onTouchEvent(cancel)
            super@ReaderActivity.dispatchTouchEvent(cancel)
            cancel.recycle()
        }

        override fun onEraseGestureRecognized() = setUiIsVisible(false)

        override fun onImageErased(ruleIds: List<Long>) {
            Snackbar.make(viewBinding.container, R.string.erase_done, Snackbar.LENGTH_LONG)
                .setAnchorView(viewBinding.toolbarDocked)
                .setAction(R.string.undo) {
                    lifecycleScope.launch { ruleIds.forEach { imageHider.forget(it) } }
                }
                .show()
        }

        override fun showEraseMessage(message: Int) {
            Snackbar.make(viewBinding.container, message, Snackbar.LENGTH_SHORT)
                .setAnchorView(viewBinding.toolbarDocked)
                .show()
        }
    }

    private fun setUiIsVisible(isUiVisible: Boolean) {
        if (viewBinding.appbarTop.isVisible != isUiVisible) {
            if (isAnimationsEnabled) {
                val transition = TransitionSet()
                    .setOrdering(TransitionSet.ORDERING_TOGETHER)
                    .addTransition(Slide(Gravity.TOP).addTarget(viewBinding.appbarTop))
                    .addTransition(Fade().addTarget(viewBinding.infoBar))
                viewBinding.toolbarDocked?.let {
                    transition.addTransition(Slide(Gravity.BOTTOM).addTarget(it))
                }
                viewBinding.containerSliderVertical?.let {
                    transition.addTransition(Slide(Gravity.END).addTarget(it))
                }
                TransitionManager.beginDelayedTransition(viewBinding.root, transition)
            }
            val isFullscreen = settings.isReaderFullscreenEnabled
            viewBinding.appbarTop.isVisible = isUiVisible
            viewBinding.toolbarDocked?.isVisible = isUiVisible
            setVerticalSliderVisible(
                isUiVisible && isVerticalSliderUsable() && (viewModel.uiState.value?.isSliderAvailable() == true),
            )
            viewBinding.infoBar.isGone = isUiVisible || (!viewModel.isInfoBarEnabled.value)
            viewBinding.infoBar.isTimeVisible = isFullscreen
            updateScrollTimerButton()
            systemUiController.setSystemUiVisible(isUiVisible || !isFullscreen)
            viewBinding.root.requestApplyInsets()
        }
    }

    override fun onApplyWindowInsets(v: View, insets: WindowInsetsCompat): WindowInsetsCompat {
        gestureInsets = insets.getInsets(WindowInsetsCompat.Type.systemGestures())
        val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        viewBinding.toolbar.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            topMargin = systemBars.top
            rightMargin = systemBars.right
            leftMargin = systemBars.left
        }
        if (viewBinding.toolbarDocked != null) {
            viewBinding.actionsView.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                bottomMargin = systemBars.bottom
                rightMargin = systemBars.right
                leftMargin = systemBars.left
            }
        }
        viewBinding.infoBar.updatePadding(
            top = systemBars.top,
        )
        val innerInsets = Insets.of(
            systemBars.left,
            if (viewBinding.appbarTop.isVisible) viewBinding.appbarTop.height else systemBars.top,
            systemBars.right,
            viewBinding.toolbarDocked?.takeIf { it.isVisible }?.height ?: systemBars.bottom,
        )
        return WindowInsetsCompat.Builder(insets)
            .setInsets(WindowInsetsCompat.Type.systemBars(), innerInsets)
            .build()
    }

    override fun switchPageBy(delta: Int) {
        readerManager.currentReader?.switchPageBy(delta)
    }

    override fun switchChapterBy(delta: Int) {
        viewModel.switchChapterBy(delta)
    }

    override fun openMenu() {
        viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
        val currentMode = readerManager.currentMode ?: return
        router.showReaderConfigSheet(currentMode)
    }

    override fun scrollBy(delta: Int, smooth: Boolean): Boolean = readerManager.currentReader?.scrollBy(delta, smooth) == true

    override fun toggleUiVisibility() {
        setUiIsVisible(!viewBinding.appbarTop.isVisible)
    }

    override fun onReaderScrolled(dy: Int) {
        val threshold = hideThresholdPx
        if (threshold == 0 || !viewBinding.appbarTop.isVisible) {
            scrolledSinceUiShown = 0
            return
        }
        scrolledSinceUiShown += abs(dy)
        if (scrolledSinceUiShown >= threshold) {
            scrolledSinceUiShown = 0
            setUiIsVisible(false)
        }
    }

    override fun isReaderResumed(): Boolean {
        val reader = readerManager.currentReader ?: return false
        return reader.isResumed && supportFragmentManager.fragments.lastOrNull() === reader
    }

    override fun onBookmarkClick() {
        viewModel.toggleBookmark()
    }

    override fun onColorFilterToggle(isEnabled: Boolean) {
        viewModel.setColorFilterEnabled(isEnabled)
    }

    override fun onCropClick(anchor: View) {
        CropMenu.show(anchor, viewModel)
    }

    override fun openColorFilterConfig() {
        val manga = viewModel.getMangaOrNull() ?: return
        val page = viewModel.getCurrentPage() ?: return
        router.openColorFilterConfig(manga, page)
    }

    override fun onSavePageClick() {
        viewModel.saveCurrentPage(pageSaveHelper)
    }

    override fun onSaveFrameClick(frame: Bitmap) {
        viewModel.saveCurrentFrame(pageSaveHelper, frame)
    }

    override fun onScrollTimerClick(isLongClick: Boolean) {
        if (isLongClick) {
            scrollTimer.setActive(!scrollTimer.isActive.value)
        } else {
            viewBinding.timerControl.showOrHide()
        }
    }

    override fun toggleScreenOrientation() {
        if (screenOrientationHelper.toggleScreenOrientation()) {
            Snackbar.make(
                viewBinding.container,
                if (screenOrientationHelper.isLocked) {
                    R.string.screen_rotation_locked
                } else {
                    R.string.screen_rotation_unlocked
                },
                Snackbar.LENGTH_SHORT,
            ).setAnchorView(viewBinding.toolbarDocked)
                .show()
        }
    }

    override fun switchPageTo(index: Int) {
        val pages = viewModel.getCurrentChapterPages()
        val page = pages?.getOrNull(index) ?: return
        val chapterId = viewModel.getCurrentState()?.chapterId ?: return
        onPageSelected(ReaderPage(page, index, chapterId))
    }

    private fun onReaderBarChanged(isBarEnabled: Boolean) {
        viewBinding.infoBar.isVisible = isBarEnabled && viewBinding.appbarTop.isGone
    }

    private fun onUiStateChanged(pair: Pair<ReaderUiState?, ReaderUiState?>) {
        val (previous: ReaderUiState?, uiState: ReaderUiState?) = pair
        title = uiState?.mangaName ?: getString(R.string.loading_)
        viewBinding.infoBar.update(uiState)
        if (uiState == null) {
            supportActionBar?.subtitle = null
            viewBinding.actionsView.setSliderValue(0, 1)
            viewBinding.actionsView.isSliderEnabled = false
            viewBinding.actionsView.isVerticalSliderActive = isVerticalSliderUsable()
            viewBinding.sliderVertical?.let { updateVerticalSlider(it, 0, 1, isAvailable = false) }
            return
        }
        val chapterTitle = uiState.getChapterTitle(resources)
        supportActionBar?.subtitle = when {
            uiState.incognito -> getString(R.string.incognito_mode)
            else -> chapterTitle
        }
        if (
            settings.isReaderChapterToastEnabled &&
            chapterTitle != previous?.getChapterTitle(resources) &&
            chapterTitle.isNotEmpty()
        ) {
            val missing = missingChaptersNotice(previous, uiState)
            viewBinding.toastView.showTemporary(
                if (missing == null) chapterTitle else chapterTitle + "\n" + missing,
                if (missing == null) TOAST_DURATION else TOAST_DURATION * 2,
            )
        } else if (settings.isMissingChapterWarningEnabled) {
            missingChaptersNotice(previous, uiState)?.let {
                viewBinding.toastView.showTemporary(it, TOAST_DURATION * 2)
            }
        }
        flashOnPageChanged(previous, uiState)
        if (uiState.isSliderAvailable()) {
            viewBinding.actionsView.setSliderValue(
                value = uiState.currentPage,
                max = uiState.totalPages - 1,
            )
            viewBinding.sliderVertical?.let {
                updateVerticalSlider(it, uiState.currentPage, uiState.totalPages - 1, isAvailable = true)
            }
        } else {
            viewBinding.actionsView.setSliderValue(0, 1)
            viewBinding.sliderVertical?.let { updateVerticalSlider(it, 0, 1, isAvailable = false) }
        }
        if (!isVerticalSliderTracking) {
            viewBinding.textViewCurrentPageVertical?.text = (uiState.currentPage + 1).toString()
        }
        viewBinding.textViewTotalPagesVertical?.text = uiState.totalPages.toString()
        val useVertical = isVerticalSliderUsable()
        viewBinding.actionsView.isSliderEnabled = uiState.isSliderAvailable() && !useVertical
        viewBinding.actionsView.isVerticalSliderActive = useVertical
        viewBinding.actionsView.isNextEnabled = uiState.hasNextChapter()
        viewBinding.actionsView.isPrevEnabled = uiState.hasPreviousChapter()
        viewBinding.buttonPrevVertical?.isEnabled = uiState.hasPreviousChapter()
        viewBinding.buttonNextVertical?.isEnabled = uiState.hasNextChapter()
        setVerticalSliderVisible(viewBinding.appbarTop.isVisible && useVertical && uiState.isSliderAvailable())
    }

    /** Notice for a numbering gap when the reader moved to the neighbouring chapter; null otherwise. */
    private fun missingChaptersNotice(previous: ReaderUiState?, current: ReaderUiState): String? {
        if (previous == null || !settings.isMissingChapterWarningEnabled) return null
        if (previous.chapter.id == current.chapter.id || abs(previous.chapterIndex - current.chapterIndex) != 1) return null
        val gap = missingChaptersBetween(previous.chapter, current.chapter)
        if (gap <= 0) return null
        return getString(
            R.string.missing_chapters_between,
            gap,
            formatChapterNumber(minOf(previous.chapter.number, current.chapter.number)),
            formatChapterNumber(maxOf(previous.chapter.number, current.chapter.number)),
        )
    }

    private fun setVerticalSliderVisible(visible: Boolean) {
        viewBinding.containerSliderVertical?.isVisible = visible
        if (!visible) {
            // A hidden slider never delivers the stop-tracking event; a stale "tracking" flag would
            // freeze the thumb (it is not written back to the current page while tracking).
            isVerticalSliderTracking = false
            isVerticalSliderChanged = false
        }
    }

    /** The vertical slider only exists in some layouts (not on wide landscape screens). */
    private fun isVerticalSliderUsable() = settings.isVerticalSliderEnabled && viewBinding.containerSliderVertical != null

    private fun updateVerticalSlider(
        slider: Slider,
        page: Int,
        max: Int,
        isAvailable: Boolean,
    ) {
        slider.valueTo = max.toFloat()
        // A thumb being dragged is owned by the user; writing the (stale) page back would fight it.
        slider.setValueRounded(if (isVerticalSliderTracking) slider.value else page.toFloat())
        slider.isEnabled = isAvailable
        slider.setThumbVisible(isAvailable)
    }

    private fun createEInkFlashView(): View = View(this).apply {
        isVisible = false
        isClickable = false
        isFocusable = false
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        viewBinding.root.addView(
            this,
            CoordinatorLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
    }

    @androidx.annotation.MainThread
    private fun flashOnPageChanged(previous: ReaderUiState?, uiState: ReaderUiState) {
        if (previous == null) {
            return
        }
        if (previous.chapter.id == uiState.chapter.id && previous.currentPage == uiState.currentPage) {
            return
        }
        if (!settings.isEInkFlashEnabled) {
            eInkFlashCounter = 0
            return
        }
        eInkFlashCounter++
        if (eInkFlashCounter % settings.eInkFlashEvery == 0) {
            showEInkFlash()
        }
    }

    private fun showEInkFlash() {
        einkFlashView.removeCallbacks(hideEInkFlashRunnable)
        einkFlashView.animate().cancel()
        einkFlashView.setBackgroundColor(settings.eInkFlashColor.colorInt)
        einkFlashView.bringToFront()
        einkFlashView.isVisible = true
        einkFlashView.postDelayed(hideEInkFlashRunnable, settings.eInkFlashDuration.toLong())
    }

    private fun updateScrollTimerButton() {
        val button = viewBinding.buttonTimer ?: return
        val isButtonVisible = scrollTimer.isActive.value &&
            settings.isReaderAutoscrollFabVisible &&
            !viewBinding.appbarTop.isVisible &&
            !viewBinding.timerControl.isVisible
        if (button.isVisible != isButtonVisible) {
            val transition = Fade().addTarget(button)
            TransitionManager.beginDelayedTransition(viewBinding.root, transition)
            button.isVisible = isButtonVisible
        }
    }

    // Observe foldable window layout to auto-enable double-page if configured
    private fun observeWindowLayout() {
        WindowInfoTracker.getOrCreate(this)
            .windowLayoutInfo(this)
            .onEach { info ->
                val fold = info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()
                val unfolded = when (fold?.state) {
                    FoldingFeature.State.HALF_OPENED, FoldingFeature.State.FLAT -> true
                    else -> false
                }
                if (unfolded != isFoldUnfolded) {
                    isFoldUnfolded = unfolded
                    applyDoubleModeAuto()
                }
            }
            .launchIn(lifecycleScope)
    }

    private fun askForIncognitoMode() {
        buildAlertDialog(this, isCentered = true) {
            var dontAskAgain = false
            val listener = DialogInterface.OnClickListener { _, which ->
                if (which == DialogInterface.BUTTON_NEUTRAL) {
                    finishAfterTransition()
                } else {
                    viewModel.setIncognitoMode(which == DialogInterface.BUTTON_POSITIVE, dontAskAgain)
                }
            }
            setCheckbox(R.string.dont_ask_again, dontAskAgain) { _, isChecked ->
                dontAskAgain = isChecked
            }
            setIcon(R.drawable.ic_incognito)
            setTitle(R.string.incognito_mode)
            setMessage(R.string.incognito_mode_hint_nsfw)
            setPositiveButton(R.string.incognito, listener)
            setNegativeButton(R.string.disable, listener)
            setNeutralButton(android.R.string.cancel, listener)
            setOnCancelListener { finishAfterTransition() }
            setCancelable(true)
        }.show()
    }

    companion object {

        private const val TOAST_DURATION = 2000L

        private const val ERASE_TUTORIAL_DELAY_MS = 1_200L

        /** 0 would switch the panel off on some devices; the lowest usable window brightness instead. */
        private const val MIN_WINDOW_BRIGHTNESS = 0.01f
    }
}
