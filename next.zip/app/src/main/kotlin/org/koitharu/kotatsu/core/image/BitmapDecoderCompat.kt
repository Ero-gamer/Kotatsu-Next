package org.koitharu.kotatsu.core.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.ImageDecoder
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.graphics.createBitmap
import com.davemorrissey.labs.subscaleview.decoder.ImageDecodeException
import okio.IOException
import okio.buffer
import okio.source
import org.aomedia.avif.android.AvifDecoder
import org.aomedia.avif.android.AvifDecoder.Info
import org.jetbrains.annotations.Blocking
import org.koitharu.kotatsu.core.util.MimeTypes
import org.koitharu.kotatsu.core.util.ext.MimeType
import org.koitharu.kotatsu.core.util.ext.printStackTraceDebug
import org.koitharu.kotatsu.core.util.ext.readByteBuffer
import org.koitharu.kotatsu.core.util.ext.toByteBuffer
import org.koitharu.kotatsu.core.util.ext.toMimeTypeOrNull
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer

object BitmapDecoderCompat {

    private const val FORMAT_AVIF = "avif"

    @Blocking
    fun decode(file: File, isMutable: Boolean = false): Bitmap = when (val format = probeMimeType(file)?.subtype) {
        FORMAT_AVIF -> {
            val mapped = file.mapReadOnlyOrNull()
            try {
                decodeAvif(mapped ?: file.source().buffer().use { it.readByteBuffer() })
            } finally {
                mapped?.capacity() // keeps the mapping reachable until native code is done
            }
        }

        else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // isMutable=true forces ALLOCATOR_SOFTWARE (hardware bitmaps can't be mutable),
            // avoiding a GPU-backed Config.HARDWARE bitmap — critical for callers that need
            // getPixels()/setPixels() (e.g. ImageFiltersTransformation), since HARDWARE bitmaps
            // can't be read on the CPU and add GPU memory pressure on low-RAM devices.
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(file), DecoderConfigListener(isMutable))
        } else {
            val opts = BitmapFactory.Options().apply { inMutable = isMutable }
            checkBitmapNotNull(BitmapFactory.decodeFile(file.absolutePath, opts), format)
        }
    }

    @Blocking
    fun decode(stream: InputStream, type: MimeType?, isMutable: Boolean = false): Bitmap {
        val format = type?.subtype
        if (format == FORMAT_AVIF) {
            return decodeAvif(stream.toByteBuffer())
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            val opts = BitmapFactory.Options()
            opts.inMutable = isMutable
            return checkBitmapNotNull(BitmapFactory.decodeStream(stream, null, opts), format)
        }
        val byteBuffer = stream.toByteBuffer()
        return if (AvifDecoder.isAvifImage(byteBuffer)) {
            decodeAvif(byteBuffer)
        } else {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(byteBuffer), DecoderConfigListener(isMutable))
        }
    }

    @Blocking
    fun createRegionDecoder(inoutStream: InputStream): BitmapRegionDecoder? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            BitmapRegionDecoder.newInstance(inoutStream)
        } else {
            @Suppress("DEPRECATION")
            BitmapRegionDecoder.newInstance(inoutStream, false)
        }
    } catch (e: IOException) {
        e.printStackTraceDebug()
        null
    }

    /**
     * A region decoder for the file at [path]. The one-argument overload of [BitmapRegionDecoder.newInstance] only
     * exists from Android 12 (calling it earlier throws NoSuchMethodError, which no `catch (Exception)` sees).
     * Throws [IOException] like the platform method.
     */
    @Blocking
    @Suppress("DEPRECATION")
    @Throws(IOException::class)
    fun createRegionDecoder(path: String): BitmapRegionDecoder? = BitmapRegionDecoder.newInstance(path, false)

    @Blocking
    fun probeMimeType(file: File): MimeType? = ImageFormatProbe.probe(file).format.mimeType?.toMimeTypeOrNull()
        ?: MimeTypes.probeMimeType(file)
        ?: detectBitmapType(file)

    @Blocking
    private fun detectBitmapType(file: File): MimeType? = runCatchingCancellable {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(file.path, options)?.recycle()
        options.outMimeType?.toMimeTypeOrNull()
    }.getOrNull()

    private fun checkBitmapNotNull(bitmap: Bitmap?, format: String?): Bitmap = bitmap ?: throw ImageDecodeException(null, format)

    private fun decodeAvif(bytes: ByteBuffer): Bitmap {
        val info = Info()
        if (!AvifDecoder.getInfo(bytes, bytes.remaining(), info)) {
            throw ImageDecodeException(
                null,
                FORMAT_AVIF,
                "Requested to decode byte buffer which cannot be handled by AvifDecoder",
            )
        }
        // Always 8 bits per channel. 10/12-bit AVIFs used to land in RGB_565 (5-6-5 bits): banded gradients, tinted
        // grays, and nothing left for the sharpen / denoise / deband filters to work with.
        val config = Bitmap.Config.ARGB_8888
        val bitmap = createBitmap(info.width, info.height, config)
        if (!AvifDecoder.decode(bytes, bytes.remaining(), bitmap)) {
            bitmap.recycle()
            throw ImageDecodeException(null, FORMAT_AVIF)
        }
        return bitmap
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private class DecoderConfigListener(
        private val isMutable: Boolean,
    ) : ImageDecoder.OnHeaderDecodedListener {

        override fun onHeaderDecoded(
            decoder: ImageDecoder,
            info: ImageDecoder.ImageInfo,
            source: ImageDecoder.Source,
        ) {
            decoder.isMutableRequired = isMutable
        }
    }
}
