package org.koitharu.kotatsu.details.ui.related

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.plus
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.parcelable.ParcelableManga
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.parser.MangaDataRepository
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.util.ext.call
import org.koitharu.kotatsu.core.util.ext.printStackTraceDebug
import org.koitharu.kotatsu.core.util.ext.require
import org.koitharu.kotatsu.details.domain.RelatedMangaUseCase
import org.koitharu.kotatsu.list.domain.MangaListMapper
import org.koitharu.kotatsu.list.ui.MangaListViewModel
import org.koitharu.kotatsu.list.ui.model.EmptyState
import org.koitharu.kotatsu.list.ui.model.LoadingState
import org.koitharu.kotatsu.list.ui.model.toErrorState
import org.koitharu.kotatsu.local.data.LocalStorageChanges
import org.koitharu.kotatsu.local.domain.model.LocalManga
import org.koitharu.kotatsu.parsers.model.Manga
import javax.inject.Inject

@HiltViewModel
class RelatedListViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    settings: AppSettings,
    private val relatedMangaUseCase: RelatedMangaUseCase,
    private val mangaListMapper: MangaListMapper,
    mangaDataRepository: MangaDataRepository,
    @LocalStorageChanges localStorageChanges: SharedFlow<LocalManga?>,
) : MangaListViewModel(settings, mangaDataRepository, localStorageChanges) {

    private val seed = savedStateHandle.require<ParcelableManga>(AppRouter.KEY_MANGA).manga
    private val mangaList = MutableStateFlow<List<Manga>?>(null)
    private val listError = MutableStateFlow<Throwable?>(null)
    private var loadingJob: Job? = null

    override val content = combine(
        mangaList,
        observeListModeWithTriggers(),
        listError,
    ) { list, mode, error ->
        when {
            list.isNullOrEmpty() && error != null -> listOf(error.toErrorState(canRetry = true))
            list == null -> listOf(LoadingState())
            list.isEmpty() -> listOf(createEmptyState())
            else -> mangaListMapper.toListModelList(list, mode)
        }
    }.stateIn(viewModelScope + Dispatchers.Default, SharingStarted.Eagerly, listOf(LoadingState()))

    init {
        loadList()
    }

    override fun onRefresh() {
        loadList()
    }

    override fun onRetry() {
        loadList()
    }

    private fun loadList(): Job {
        loadingJob?.let {
            if (it.isActive) return it
        }
        return launchLoadingJob(Dispatchers.Default) {
            try {
                listError.value = null
                // same path as the details screen row: the source's own list, then tag-based fill
                mangaList.value = relatedMangaUseCase(seed).orEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                e.printStackTraceDebug()
                listError.value = e
                if (!mangaList.value.isNullOrEmpty()) {
                    errorEvent.call(e)
                }
            }
        }.also { loadingJob = it }
    }

    private fun createEmptyState() = EmptyState(
        icon = R.drawable.ic_empty_common,
        textPrimary = R.string.nothing_found,
        textSecondary = 0,
        actionStringRes = 0,
    )
}
