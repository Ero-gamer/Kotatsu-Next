package org.koitharu.kotatsu.settings

import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import com.davemorrissey.labs.subscaleview.ImageDownscaler
import com.davemorrissey.labs.subscaleview.ImageScaler
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.ReaderHideThreshold
import org.koitharu.kotatsu.core.model.ReaderTint
import org.koitharu.kotatsu.core.model.ZoomMode
import org.koitharu.kotatsu.core.model.ZoomStart
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.EInkFlashColor
import org.koitharu.kotatsu.core.prefs.ReaderAnimation
import org.koitharu.kotatsu.core.prefs.ReaderBackground
import org.koitharu.kotatsu.core.prefs.ReaderControl
import org.koitharu.kotatsu.core.prefs.ReaderMode
import org.koitharu.kotatsu.core.ui.BasePreferenceFragment
import org.koitharu.kotatsu.core.util.ext.getQuantityStringSafe
import org.koitharu.kotatsu.core.util.ext.setDefaultValueCompat
import org.koitharu.kotatsu.parsers.util.mapToSet
import org.koitharu.kotatsu.parsers.util.names
import org.koitharu.kotatsu.settings.utils.MultiSummaryProvider
import org.koitharu.kotatsu.settings.utils.PercentSummaryProvider
import org.koitharu.kotatsu.settings.utils.SliderPreference

@AndroidEntryPoint
class ReaderSettingsFragment :
    BasePreferenceFragment(R.string.reader_settings),
    SharedPreferences.OnSharedPreferenceChangeListener {
    override fun onCreatePreferences(
        savedInstanceState: Bundle?,
        rootKey: String?,
    ) {
        addPreferencesFromResource(R.xml.pref_reader)
        findPreference<ListPreference>(AppSettings.KEY_READER_MODE)?.run {
            entryValues = ReaderMode.entries.names()
            setDefaultValueCompat(ReaderMode.STANDARD.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_ORIENTATION)?.run {
            entryValues =
                arrayOf(
                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED.toString(),
                    ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR.toString(),
                    ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT.toString(),
                    ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE.toString(),
                )
            setDefaultValueCompat(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED.toString())
        }
        findPreference<MultiSelectListPreference>(AppSettings.KEY_READER_CONTROLS)?.run {
            entryValues = ReaderControl.entries.names()
            setDefaultValueCompat(ReaderControl.DEFAULT.mapToSet { it.name })
            summaryProvider = MultiSummaryProvider(R.string.none)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_BACKGROUND)?.run {
            entryValues = ReaderBackground.entries.names()
            setDefaultValueCompat(ReaderBackground.DEFAULT.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_ANIMATION)?.run {
            entryValues = ReaderAnimation.entries.names()
            setDefaultValueCompat(ReaderAnimation.DEFAULT.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_SCALER)?.run {
            entryValues = ImageScaler.entries.names()
            setDefaultValueCompat(ImageScaler.DEFAULT.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_DOWNSCALER)?.run {
            entryValues = ImageDownscaler.entries.names()
            setDefaultValueCompat(ImageDownscaler.DEFAULT.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_ZOOM_MODE)?.run {
            entryValues = ZoomMode.entries.names()
            setDefaultValueCompat(ZoomMode.FIT_CENTER.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_HIDE_THRESHOLD)?.run {
            entryValues = ReaderHideThreshold.entries.names()
            setDefaultValueCompat(ReaderHideThreshold.OFF.name)
        }
        findPreference<ListPreference>(AppSettings.KEY_READER_TINT)?.run {
            entryValues = ReaderTint.entries.names()
            setDefaultValueCompat(ReaderTint.OFF.name)
        }
        findPreference<SliderPreference>(AppSettings.KEY_READER_TINT_STRENGTH)?.summaryProvider = PercentSummaryProvider()
        findPreference<SliderPreference>(AppSettings.KEY_READER_DIM)?.summaryProvider = PercentSummaryProvider()
        findPreference<SliderPreference>(AppSettings.KEY_WEBTOON_SIDE_PADDING)?.summaryProvider = PercentSummaryProvider()
        findPreference<SliderPreference>(AppSettings.KEY_DOUBLE_PAGE_GAP)?.summaryProvider = PercentSummaryProvider()
        findPreference<SliderPreference>(AppSettings.KEY_READER_BRIGHTNESS)?.summaryProvider = BrightnessSummaryProvider
        findPreference<ListPreference>(AppSettings.KEY_ZOOM_START)?.run {
            entryValues = ZoomStart.entries.names()
            setDefaultValueCompat(ZoomStart.AUTO.name)
        }
        findPreference<MultiSelectListPreference>(AppSettings.KEY_READER_CROP)?.run {
            summaryProvider = MultiSummaryProvider(R.string.disabled)
        }
        findPreference<SliderPreference>(AppSettings.KEY_WEBTOON_ZOOM_OUT)?.summaryProvider = PercentSummaryProvider()
        findPreference<SliderPreference>(AppSettings.KEY_EINK_FLASH_DURATION)?.summaryProvider =
            FlashDurationSummaryProvider
        findPreference<SliderPreference>(AppSettings.KEY_EINK_FLASH_EVERY)?.summaryProvider =
            FlashEverySummaryProvider
        findPreference<ListPreference>(AppSettings.KEY_EINK_FLASH_COLOR)?.run {
            entries =
                arrayOf(
                    getString(R.string.color_white),
                    getString(R.string.color_black),
                )
            entryValues = EInkFlashColor.entries.names()
            setDefaultValueCompat(EInkFlashColor.WHITE.name)
        }
        updateReaderModeDependency()
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)
        settings.subscribe(this)
    }

    override fun onDestroyView() {
        settings.unsubscribe(this)
        super.onDestroyView()
    }

    override fun onPreferenceTreeClick(preference: Preference): Boolean = when (preference.key) {
        AppSettings.KEY_READER_TAP_ACTIONS -> {
            router.openReaderTapGridSettings()
            true
        }

        AppSettings.KEY_ERASE_TUTORIAL -> {
            settings.reopenTip(AppSettings.TIP_ERASE_TUTORIAL)
            Snackbar.make(listView, R.string.erase_tutorial_again_done, Snackbar.LENGTH_SHORT).show()
            true
        }

        else -> {
            super.onPreferenceTreeClick(preference)
        }
    }

    override fun onSharedPreferenceChanged(
        sharedPreferences: SharedPreferences?,
        key: String?,
    ) {
        when (key) {
            AppSettings.KEY_READER_MODE -> updateReaderModeDependency()
        }
    }

    private fun updateReaderModeDependency() {
        findPreference<Preference>(AppSettings.KEY_READER_MODE_DETECT)?.run {
            isEnabled = settings.defaultReaderMode != ReaderMode.WEBTOON
        }
    }

    private object BrightnessSummaryProvider : Preference.SummaryProvider<SliderPreference> {
        override fun provideSummary(preference: SliderPreference): CharSequence = if (preference.value <= 0) {
            preference.context.getString(R.string.system_default)
        } else {
            preference.context.getString(R.string.percent_string_pattern, preference.value.toString())
        }
    }

    private object FlashDurationSummaryProvider : Preference.SummaryProvider<SliderPreference> {
        override fun provideSummary(preference: SliderPreference): CharSequence = preference.context.getString(R.string.milliseconds_pattern, preference.value)
    }

    private object FlashEverySummaryProvider : Preference.SummaryProvider<SliderPreference> {
        override fun provideSummary(preference: SliderPreference): CharSequence {
            val value = preference.value
            return preference.context.resources.getQuantityStringSafe(R.plurals.pages, value, value)
        }
    }
}
