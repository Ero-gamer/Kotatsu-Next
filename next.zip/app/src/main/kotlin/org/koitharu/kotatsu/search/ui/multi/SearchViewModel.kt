package org.koitharu.kotatsu.search.ui.multi

import androidx.collection.ArraySet
import androidx.collection.LongSet
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.dropWhile
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.LocalMangaSource
import org.koitharu.kotatsu.core.model.UnknownMangaSource
import org.koitharu.kotatsu.core.model.isNsfw
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.ListMode
import org.koitharu.kotatsu.core.ui.BaseViewModel
import org.koitharu.kotatsu.core.util.ext.append
import org.koitharu.kotatsu.core.util.ext.printStackTraceDebug
import org.koitharu.kotatsu.core.util.ext.toLocale
import org.koitharu.kotatsu.explore.data.MangaSourcesRepository
import org.koitharu.kotatsu.explore.data.SourcePresetsRepository
import org.koitharu.kotatsu.favourites.domain.FavouritesRepository
import org.koitharu.kotatsu.history.data.HistoryRepository
import org.koitharu.kotatsu.list.domain.MangaListMapper
import org.koitharu.kotatsu.list.ui.model.ButtonFooter
import org.koitharu.kotatsu.list.ui.model.EmptyState
import org.koitharu.kotatsu.list.ui.model.ListModel
import org.koitharu.kotatsu.list.ui.model.LoadingFooter
import org.koitharu.kotatsu.list.ui.model.LoadingState
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.ParserMangaSource
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import org.koitharu.kotatsu.search.domain.SearchKind
import org.koitharu.kotatsu.search.domain.SearchV2Helper
import java.util.Locale
import javax.inject.Inject

private const val MAX_PARALLELISM = 4

@HiltViewModel
class SearchViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val mangaListMapper: MangaListMapper,
    private val searchHelperFactory: SearchV2Helper.Factory,
    private val sourcesRepository: MangaSourcesRepository,
    private val historyRepository: HistoryRepository,
    private val favouritesRepository: FavouritesRepository,
    private val settings: AppSettings,
    private val presetsRepository: SourcePresetsRepository,
) : BaseViewModel() {

    val query = savedStateHandle.get<String>(AppRouter.KEY_QUERY).orEmpty()
    val kind = savedStateHandle.get<SearchKind>(AppRouter.KEY_KIND) ?: SearchKind.SIMPLE

    private var includeDisabledSources = MutableStateFlow(false)
    private var pinnedOnly = MutableStateFlow(false)
    private var hideEmpty = MutableStateFlow(false)
    private val results = MutableStateFlow<List<SearchResultsListModel>>(emptyList())

    private var searchJob: Job? = null

    val list: StateFlow<List<ListModel>> = combine(
        results,
        isLoading.dropWhile { !it },
        includeDisabledSources,
        hideEmpty,
    ) { list, loading, includeDisabled, hideEmptyVal ->
        val filteredList = if (hideEmptyVal) {
            list.filter { it.list.isNotEmpty() }
        } else {
            list
        }
        when {
            filteredList.isEmpty() -> listOf(
                when {
                    loading -> LoadingState()

                    else -> EmptyState(
                        icon = R.drawable.ic_empty_common,
                        textPrimary = R.string.nothing_found,
                        textSecondary = R.string.text_search_holder_secondary,
                        actionStringRes = 0,
                    )
                },
            )

            loading -> filteredList + LoadingFooter()

            includeDisabled -> filteredList

            else -> filteredList + ButtonFooter(R.string.search_disabled_sources)
        }
    }.stateIn(viewModelScope + Dispatchers.Default, SharingStarted.Eagerly, listOf(LoadingState()))

    init {
        doSearch()
    }

    fun getItems(ids: LongSet): Set<Manga> {
        val snapshot = results.value
        val result = ArraySet<Manga>(ids.size)
        snapshot.forEach { x ->
            for (item in x.list) {
                if (item.id in ids) {
                    result.add(item.manga)
                }
            }
        }
        return result
    }

    fun retry() {
        searchJob?.cancel()
        results.value = emptyList()
        includeDisabledSources.value = false
        doSearch()
    }

    fun setPinnedOnly(value: Boolean) {
        if (pinnedOnly.value != value) {
            pinnedOnly.value = value
            retry()
        }
    }

    fun setHideEmpty(value: Boolean) {
        hideEmpty.value = value
    }

    fun continueSearch() {
        if (includeDisabledSources.value) {
            return
        }
        val prevJob = searchJob
        searchJob = launchLoadingJob(Dispatchers.Default) {
            includeDisabledSources.value = true
            prevJob?.join()
            val sources = if (pinnedOnly.value) {
                emptyList()
            } else {
                sourcesRepository.getDisabledSources()
                    .sortedByDescending { it.priority() }
            }
            val semaphore = Semaphore(MAX_PARALLELISM)
            sources.map { source ->
                launch {
                    semaphore.withPermit {
                        appendResult(searchSource(source))
                    }
                }
            }.joinAll()
        }
    }

    private fun doSearch() {
        val prevJob = searchJob
        searchJob = launchLoadingJob(Dispatchers.Default) {
            prevJob?.cancelAndJoin()
            appendResult(searchHistory())
            appendResult(searchFavorites())
            appendResult(searchLocal())
            val sources = getPresetSourcesOrDefault()
            val semaphore = Semaphore(MAX_PARALLELISM)
            sources.map { source ->
                launch {
                    semaphore.withPermit {
                        appendResult(searchSource(source))
                    }
                }
            }.joinAll()
        }
    }

    // impl

    private suspend fun searchSource(source: MangaSource): SearchResultsListModel? = runCatchingCancellable {
        val searchHelper = searchHelperFactory.create(source)
        searchHelper(query, kind)
    }.fold(
        onSuccess = { result ->
            if (result == null || result.manga.isEmpty()) {
                null
            } else {
                val list = mangaListMapper.toListModelList(
                    manga = result.manga,
                    mode = ListMode.GRID,
                )
                SearchResultsListModel(
                    titleResId = 0,
                    source = source,
                    list = list,
                    error = null,
                    listFilter = result.listFilter,
                    sortOrder = result.sortOrder,
                )
            }
        },
        onFailure = { error ->
            error.printStackTraceDebug()
            if (source is ParserMangaSource && source.isBroken) {
                null
            } else {
                SearchResultsListModel(0, source, null, null, emptyList(), error)
            }
        },
    )

    private suspend fun searchHistory(): SearchResultsListModel? = runCatchingCancellable {
        historyRepository.search(query, kind, Int.MAX_VALUE)
    }.fold(
        onSuccess = { result ->
            if (result.isNotEmpty()) {
                SearchResultsListModel(
                    titleResId = R.string.history,
                    source = UnknownMangaSource,
                    list = mangaListMapper.toListModelList(manga = result, mode = ListMode.GRID),
                    error = null,
                    listFilter = null,
                    sortOrder = null,
                )
            } else {
                null
            }
        },
        onFailure = { error ->
            SearchResultsListModel(
                titleResId = R.string.history,
                source = UnknownMangaSource,
                list = emptyList(),
                error = error,
                listFilter = null,
                sortOrder = null,
            )
        },
    )

    private suspend fun searchFavorites(): SearchResultsListModel? = runCatchingCancellable {
        favouritesRepository.search(query, kind, Int.MAX_VALUE)
    }.fold(
        onSuccess = { result ->
            if (result.isNotEmpty()) {
                SearchResultsListModel(
                    titleResId = R.string.favourites,
                    source = UnknownMangaSource,
                    list = mangaListMapper.toListModelList(
                        manga = result,
                        mode = ListMode.GRID,
                        flags = MangaListMapper.NO_FAVORITE,
                    ),
                    error = null,
                    listFilter = null,
                    sortOrder = null,
                )
            } else {
                null
            }
        },
        onFailure = { error ->
            SearchResultsListModel(
                titleResId = R.string.favourites,
                source = UnknownMangaSource,
                list = emptyList(),
                error = error,
                listFilter = null,
                sortOrder = null,
            )
        },
    )

    private suspend fun searchLocal(): SearchResultsListModel? = runCatchingCancellable {
        searchHelperFactory.create(LocalMangaSource).invoke(query, kind)
    }.fold(
        onSuccess = { result ->
            if (!result?.manga.isNullOrEmpty()) {
                SearchResultsListModel(
                    titleResId = 0,
                    source = LocalMangaSource,
                    list = mangaListMapper.toListModelList(
                        manga = result.manga,
                        mode = ListMode.GRID,
                        flags = MangaListMapper.NO_SAVED,
                    ),
                    error = null,
                    listFilter = result.listFilter,
                    sortOrder = result.sortOrder,
                )
            } else {
                null
            }
        },
        onFailure = { error ->
            SearchResultsListModel(
                titleResId = 0,
                source = LocalMangaSource,
                list = emptyList(),
                error = error,
                listFilter = null,
                sortOrder = null,
            )
        },
    )

    private fun appendResult(item: SearchResultsListModel?) {
        if (item != null) {
            results.append(item)
        }
    }

    private fun MangaSource.priority(): Int {
        var res = 0
        if (this is ParserMangaSource) {
            if (locale.toLocale() == Locale.getDefault()) res += 2
        }
        return res
    }

    private suspend fun getPresetSourcesOrDefault(): List<MangaSource> {
        val presetId = settings.activeSourcePresetId
        if (presetId != 0L) {
            val preset = presetsRepository.getById(presetId)
            if (preset != null) {
                if (preset.sources.isEmpty()) return emptyList()
                val skipNsfw = settings.isNsfwContentDisabled
                return sourcesRepository.allMangaSources.filter { source ->
                    source.name in preset.sources && (!skipNsfw || !source.isNsfw())
                }
            }
        }
        return if (pinnedOnly.value) {
            sourcesRepository.getPinnedSources().toList()
        } else {
            sourcesRepository.getEnabledSources()
        }
    }
}
