package org.koitharu.kotatsu.details.ui.pager.pages

import androidx.core.net.toUri
import coil3.ImageLoader
import coil3.decode.DataSource
import coil3.decode.ImageSource
import coil3.fetch.FetchResult
import coil3.fetch.Fetcher
import coil3.fetch.SourceFetchResult
import coil3.network.HttpException
import coil3.network.NetworkHeaders
import coil3.network.NetworkResponse
import coil3.network.NetworkResponseBody
import coil3.request.Options
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Response
import okio.FileSystem
import okio.Path.Companion.toOkioPath
import org.koitharu.kotatsu.core.image.ImageFormatProbe
import org.koitharu.kotatsu.core.image.PageFormatRegistry
import org.koitharu.kotatsu.core.network.MangaHttpClient
import org.koitharu.kotatsu.core.network.imageproxy.ImageProxyInterceptor
import org.koitharu.kotatsu.core.parser.MangaRepository
import org.koitharu.kotatsu.core.util.MimeTypes
import org.koitharu.kotatsu.core.util.ext.fetch
import org.koitharu.kotatsu.core.util.ext.isFileUri
import org.koitharu.kotatsu.core.util.ext.isNetworkUri
import org.koitharu.kotatsu.core.util.ext.isZipUri
import org.koitharu.kotatsu.core.util.ext.toMimeTypeOrNull
import org.koitharu.kotatsu.local.data.LocalStorageCache
import org.koitharu.kotatsu.local.data.PageCache
import org.koitharu.kotatsu.parsers.model.MangaPage
import org.koitharu.kotatsu.parsers.util.mimeType
import org.koitharu.kotatsu.parsers.util.requireBody
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import org.koitharu.kotatsu.reader.domain.PageLoader
import java.io.File
import java.util.zip.ZipFile
import javax.inject.Inject

private const val THUMBNAIL_PERMITS = 4

class MangaPageFetcher(
    private val okHttpClient: OkHttpClient,
    private val pagesCache: LocalStorageCache,
    private val options: Options,
    private val page: MangaPage,
    private val mangaRepositoryFactory: MangaRepository.Factory,
    private val imageProxyInterceptor: ImageProxyInterceptor,
    private val imageLoader: ImageLoader,
) : Fetcher {

    override suspend fun fetch(): FetchResult? = gate.withPermit { fetchImpl() }

    private suspend fun fetchImpl(): FetchResult? {
        if (!page.preview.isNullOrEmpty()) {
            runCatchingCancellable {
                imageLoader.fetch(checkNotNull(page.preview), options)
            }.onSuccess {
                noteCachedFormat()
                return it
            }
        }
        val repo = mangaRepositoryFactory.create(page.source)
        val pageUrl = repo.getPageUrl(page)
        if (options.diskCachePolicy.readEnabled) {
            pagesCache[pageUrl]?.let { file ->
                return SourceFetchResult(
                    source = ImageSource(file.toOkioPath(), options.fileSystem),
                    mimeType = MimeTypes.getMimeTypeFromExtension(file.name)?.toString(),
                    dataSource = DataSource.DISK,
                ).also(::noteFormat)
            }
        }
        return loadPage(pageUrl)?.also(::noteFormat)
    }

    private suspend fun loadPage(pageUrl: String): FetchResult? = if (pageUrl.toUri().isNetworkUri()) {
        fetchPage(pageUrl)
    } else {
        imageLoader.fetch(pageUrl, options)
    }

    private suspend fun fetchPage(pageUrl: String): FetchResult {
        val request = PageLoader.createPageRequest(pageUrl, page.source)
        return imageProxyInterceptor.interceptPageRequest(request, okHttpClient).use { response ->
            if (!response.isSuccessful) {
                throw HttpException(response.toNetworkResponse())
            }
            val mimeType = response.mimeType?.toMimeTypeOrNull()
            val file = response.requireBody().use {
                pagesCache.set(pageUrl, it.source(), mimeType)
            }
            SourceFetchResult(
                source = ImageSource(file.toOkioPath(), FileSystem.SYSTEM),
                mimeType = mimeType?.toString(),
                dataSource = DataSource.NETWORK,
            )
        }
    }

    /**
     * A preview is only the thumbnail, so its format says nothing about the page. When the page itself is already
     * on disk (a local file or archive entry, or a cached download) its header is probed instead. Never fetches.
     */
    private suspend fun noteCachedFormat() {
        try {
            val uri = page.url.toUri()
            val info = when {
                uri.isZipUri() -> ZipFile(uri.schemeSpecificPart).use { zip ->
                    val entry = zip.getEntry(uri.fragment ?: return) ?: return
                    val head = ByteArray(PROBE_HEAD_BYTES.toInt())
                    val n = zip.getInputStream(entry).use { it.read(head).coerceAtLeast(0) }
                    ImageFormatProbe.probe(head, n, truncated = entry.size > n)
                }

                uri.isFileUri() -> uri.path?.let { ImageFormatProbe.probe(File(it)) }
                else -> pagesCache[page.url]?.let { ImageFormatProbe.probe(it) }
            }
            if (info != null) PageFormatRegistry.record(page.id, info)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Badges are cosmetic: a failed probe must never affect loading.
        }
    }

    /** Records the real format of what was fetched (page grids show it as a badge). Never throws. */
    private fun noteFormat(result: FetchResult) {
        try {
            val source = (result as? SourceFetchResult)?.source ?: return
            val info = source.fileOrNull()?.let { ImageFormatProbe.probe(it.toFile()) }
                ?: source.sourceOrNull()?.peek()?.let { peek ->
                    val available = if (peek.request(PROBE_HEAD_BYTES)) PROBE_HEAD_BYTES else peek.buffer.size
                    if (available <= 0L) return
                    val head = peek.readByteArray(available)
                    ImageFormatProbe.probe(head, head.size, truncated = true)
                }
            if (info != null) PageFormatRegistry.record(page.id, info)
        } catch (_: Exception) {
            // Badges are cosmetic: a failed probe must never affect loading.
        }
    }

    private fun Response.toNetworkResponse() = NetworkResponse(
        code = code,
        requestMillis = sentRequestAtMillis,
        responseMillis = receivedResponseAtMillis,
        headers = headers.toNetworkHeaders(),
        body = body?.source()?.let(::NetworkResponseBody),
        delegate = this,
    )

    private fun Headers.toNetworkHeaders(): NetworkHeaders {
        val headers = NetworkHeaders.Builder()
        for ((key, values) in this) {
            headers.add(key, values)
        }
        return headers.build()
    }

    private companion object {

        /** Bounds concurrent thumbnail fetches/decodes while a grid of pages is scrolled quickly. */
        val gate = Semaphore(THUMBNAIL_PERMITS)

        const val PROBE_HEAD_BYTES = 32L * 1024
    }

    class Factory @Inject constructor(
        @MangaHttpClient private val okHttpClient: OkHttpClient,
        @PageCache private val pagesCache: LocalStorageCache,
        private val mangaRepositoryFactory: MangaRepository.Factory,
        private val imageProxyInterceptor: ImageProxyInterceptor,
    ) : Fetcher.Factory<MangaPage> {

        override fun create(data: MangaPage, options: Options, imageLoader: ImageLoader) = MangaPageFetcher(
            okHttpClient = okHttpClient,
            pagesCache = pagesCache,
            options = options,
            page = data,
            mangaRepositoryFactory = mangaRepositoryFactory,
            imageProxyInterceptor = imageProxyInterceptor,
            imageLoader = imageLoader,
        )
    }
}
