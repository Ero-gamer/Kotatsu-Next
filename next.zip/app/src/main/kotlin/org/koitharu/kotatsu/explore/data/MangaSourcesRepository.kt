package org.koitharu.kotatsu.explore.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.room.withTransaction
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import org.koitharu.kotatsu.BuildConfig
import org.koitharu.kotatsu.core.LocalizedAppContext
import org.koitharu.kotatsu.core.db.MangaDatabase
import org.koitharu.kotatsu.core.db.dao.MangaSourcesDao
import org.koitharu.kotatsu.core.db.entity.MangaSourceEntity
import org.koitharu.kotatsu.core.model.MangaSourceInfo
import org.koitharu.kotatsu.core.model.getTitle
import org.koitharu.kotatsu.core.model.isNsfw
import org.koitharu.kotatsu.core.parser.external.ExternalMangaSource
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.observeAsFlow
import org.koitharu.kotatsu.core.ui.util.ReversibleHandle
import org.koitharu.kotatsu.core.util.ext.flattenLatest
import org.koitharu.kotatsu.parsers.model.ContentType
import org.koitharu.kotatsu.parsers.model.ParserMangaSource
import org.koitharu.kotatsu.core.parser.bundle.ActiveParsers
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.network.CloudFlareHelper
import org.koitharu.kotatsu.parsers.util.mapNotNullToSet
import org.koitharu.kotatsu.parsers.util.mapToSet
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MangaSourcesRepository
@Inject
constructor(
    @LocalizedAppContext private val context: Context,
    private val db: MangaDatabase,
    private val settings: AppSettings,
) {
    /** The [ActiveParsers.generation] whose sources the table has been brought up to. */
    private val assimilatedGeneration = AtomicInteger(-1)
    private val dao: MangaSourcesDao
        get() = db.getSourcesDao()

    /** The sources of the parsers in use. Not a list to keep: newer parsers can come with others, at any time. */
    val allMangaSources: Set<ParserMangaSource>
        get() = ActiveParsers.workingSources

    suspend fun getEnabledSources(): List<MangaSource> {
        assimilateNewSources()
        val order = settings.sourcesSortOrder
        return dao
            .findAll(!settings.isAllSourcesEnabled, order)
            .toSources(settings.isNsfwContentDisabled, order)
            .let { enabled ->
                val external = getExternalSources()
                val list = ArrayList<MangaSourceInfo>(enabled.size + external.size)
                external.mapTo(list) { MangaSourceInfo(it, isEnabled = true, isPinned = true) }
                list.addAll(enabled)
                list
            }
    }

    suspend fun getPinnedSources(): Set<MangaSource> {
        assimilateNewSources()
        val skipNsfw = settings.isNsfwContentDisabled
        return dao.findAllPinned().mapNotNullToSet {
            it.source.toMangaSourceOrNull()?.takeUnless { x -> skipNsfw && x.isNsfw() }
        }
    }

    suspend fun getTopSources(limit: Int): List<MangaSource> {
        assimilateNewSources()
        return dao.findLastUsed(limit).toSources(settings.isNsfwContentDisabled, null)
    }

    suspend fun getDisabledSources(): Set<MangaSource> {
        assimilateNewSources()
        if (settings.isAllSourcesEnabled) {
            return emptySet()
        }
        val result = LinkedHashSet<MangaSource>(allMangaSources)
        val enabled = dao.findAllEnabledNames()
        for (name in enabled) {
            val source = name.toMangaSourceOrNull() ?: continue
            result.remove(source)
        }
        return result
    }

    suspend fun queryParserSources(
        isDisabledOnly: Boolean,
        isNewOnly: Boolean,
        excludeBroken: Boolean,
        types: Set<ContentType>,
        query: String?,
        locale: String?,
        sortOrder: SourcesSortOrder?,
    ): List<ParserMangaSource> {
        assimilateNewSources()
        val entities = dao.findAll().toMutableList()
        if (isDisabledOnly && !settings.isAllSourcesEnabled) {
            entities.removeAll { it.isEnabled }
        }
        if (isNewOnly) {
            entities.retainAll { it.addedIn == BuildConfig.VERSION_CODE }
        }
        val sources =
            entities
                .toSources(
                    skipNsfwSources = settings.isNsfwContentDisabled,
                    sortOrder = sortOrder,
                ).run {
                    mapNotNullTo(ArrayList(size)) { it.mangaSource as? ParserMangaSource }
                }
        if (locale != null) {
            sources.retainAll { it.locale == locale }
        }
        if (excludeBroken) {
            sources.removeAll { it.isBroken }
        }
        if (types.isNotEmpty()) {
            sources.retainAll { it.contentType in types }
        }
        if (!query.isNullOrEmpty()) {
            sources.retainAll {
                it.getTitle(context).contains(query, ignoreCase = true) ||
                    it.name.contains(query, ignoreCase = true)
            }
        }
        return sources
    }

    fun observeIsEnabled(source: MangaSource): Flow<Boolean> = dao.observeIsEnabled(source.name).onStart {
        assimilateNewSources()
    }

    fun observeEnabledSourcesCount(): Flow<Int> = combine(
        observeIsNsfwDisabled(),
        observeAllEnabled().flatMapLatest { isAllSourcesEnabled ->
            dao.observeAll(!isAllSourcesEnabled, SourcesSortOrder.MANUAL)
        },
        observeParsers(),
    ) { skipNsfw, sources, _ ->
        sources.count {
            it.source.toMangaSourceOrNull()?.let { s -> !skipNsfw || !s.isNsfw() } == true
        }
    }.distinctUntilChanged().onStart { assimilateNewSources() }

    fun observeAvailableSourcesCount(): Flow<Int> = combine(
        observeIsNsfwDisabled(),
        observeAllEnabled().flatMapLatest { isAllSourcesEnabled ->
            dao.observeAll(!isAllSourcesEnabled, SourcesSortOrder.MANUAL)
        },
        observeParsers(),
    ) { skipNsfw, enabledSources, _ ->
        val enabled = enabledSources.mapToSet { it.source }
        allMangaSources.count { x ->
            x.name !in enabled && (!skipNsfw || !x.isNsfw())
        }
    }.distinctUntilChanged().onStart { assimilateNewSources() }

    fun observeEnabledSources(): Flow<List<MangaSourceInfo>> = combine(
        observeIsNsfwDisabled(),
        observeAllEnabled(),
        observeSortOrder(),
        observeParsers(),
    ) { skipNsfw, allEnabled, order, _ ->
        dao.observeAll(!allEnabled, order).map {
            it.toSources(skipNsfw, order)
        }
    }.flattenLatest()
        .onStart { assimilateNewSources() }
        .combine(observeExternalSources()) { enabled, external ->
            val list = ArrayList<MangaSourceInfo>(enabled.size + external.size)
            external.mapTo(list) { MangaSourceInfo(it, isEnabled = true, isPinned = true) }
            list.addAll(enabled)
            list
        }

    fun observeAll(): Flow<List<Pair<MangaSource, Boolean>>> = combine(dao.observeAll(), observeParsers()) { entities, _ -> entities }
        .map { entities ->
            val result = ArrayList<Pair<MangaSource, Boolean>>(entities.size)
            for (entity in entities) {
                val source = entity.source.toMangaSourceOrNull() ?: continue
                if (source in allMangaSources) {
                    result.add(source to entity.isEnabled)
                }
            }
            result
        }.onStart { assimilateNewSources() }

    suspend fun setSourcesEnabled(
        sources: Collection<MangaSource>,
        isEnabled: Boolean,
    ): ReversibleHandle {
        setSourcesEnabledImpl(sources, isEnabled)
        return ReversibleHandle {
            setSourcesEnabledImpl(sources, !isEnabled)
        }
    }

    suspend fun setSourcesEnabledExclusive(sources: Set<MangaSource>) {
        db.withTransaction {
            assimilateNewSources()
            for (s in allMangaSources) {
                dao.setEnabled(s.name, s in sources)
            }
        }
    }

    suspend fun disableAllSources() {
        db.withTransaction {
            assimilateNewSources()
            dao.disableAllSources()
        }
    }

    suspend fun setPositions(sources: List<MangaSource>) {
        db.withTransaction {
            for ((index, item) in sources.withIndex()) {
                dao.setSortKey(item.name, index)
            }
        }
    }

    fun observeHasNewSources(): Flow<Boolean> = combine(observeIsNsfwDisabled(), observeParsers()) { skipNsfw, _ -> skipNsfw }
        .map { skipNsfw ->
            val sources = dao.findAllFromVersion(BuildConfig.VERSION_CODE).toSources(skipNsfw, null)
            sources.isNotEmpty() && sources.size != allMangaSources.size
        }.onStart { assimilateNewSources() }

    fun observeHasNewSourcesForBadge(): Flow<Boolean> = combine(
        settings.observeAsFlow(AppSettings.KEY_SOURCES_VERSION) { sourcesVersion },
        observeIsNsfwDisabled(),
        settings.observeAsFlow(AppSettings.KEY_SOURCES_NEW_DOWNLOADED) { hasNewDownloadedSources },
        observeParsers(),
    ) { version, skipNsfw, hasDownloaded, _ ->
        if (version < BuildConfig.VERSION_CODE) {
            val sources = dao.findAllFromVersion(version).toSources(skipNsfw, null)
            sources.isNotEmpty()
        } else {
            hasDownloaded
        }
    }.onStart { assimilateNewSources() }

    fun clearNewSourcesBadge() {
        settings.sourcesVersion = BuildConfig.VERSION_CODE
        settings.hasNewDownloadedSources = false
    }

    /**
     * The parsers in use, once the sources they came with are in the table: something to put next to whatever lists
     * sources, so that it is listed again when newer parsers are downloaded.
     */
    private fun observeParsers(): Flow<Int> = ActiveParsers.observe().onEach { assimilateNewSources() }

    private suspend fun assimilateNewSources(): Boolean {
        val generation = ActiveParsers.generation
        if (assimilatedGeneration.get() == generation) {
            return false
        }
        // Nothing is held while this is done: two callers at once do the same thing twice, rows going in only where there are none
        val isChanged = insertNewSources()
        // Only now: a failure above leaves it to be done by whoever asks next
        assimilatedGeneration.set(generation)
        return isChanged
    }

    private suspend fun insertNewSources(): Boolean {
        val new = getNewSources()
        if (new.isEmpty()) {
            return false
        }
        if (!ActiveParsers.isBuiltIn && settings.sourcesVersion >= BuildConfig.VERSION_CODE) {
            // Sources that came with no update of the app, after the ones of this version were looked at
            settings.hasNewDownloadedSources = true
        }
        var maxSortKey = dao.getMaxSortKey()
        val isAllEnabled = settings.isAllSourcesEnabled
        val entities = new.map { x ->
            MangaSourceEntity(
                source = x.name,
                isEnabled = isAllEnabled,
                sortKey = ++maxSortKey,
                addedIn = BuildConfig.VERSION_CODE,
                lastUsedAt = 0,
                isPinned = false,
                cfState = CloudFlareHelper.PROTECTION_NOT_DETECTED,
            )
        }
        dao.insertIfAbsent(entities)
        return true
    }

    suspend fun isSetupRequired(): Boolean = settings.sourcesVersion == 0 && dao.findAllEnabledNames().isEmpty()

    suspend fun setIsPinned(
        sources: Collection<MangaSource>,
        isPinned: Boolean,
    ): ReversibleHandle {
        setSourcesPinnedImpl(sources, isPinned)
        return ReversibleHandle {
            setSourcesPinnedImpl(sources, !isPinned)
        }
    }

    suspend fun trackUsage(source: MangaSource) {
        if (!settings.isIncognitoModeEnabled(source.isNsfw())) {
            dao.setLastUsed(source.name, System.currentTimeMillis())
        }
    }

    private suspend fun setSourcesEnabledImpl(
        sources: Collection<MangaSource>,
        isEnabled: Boolean,
    ) {
        if (sources.size == 1) { // fast path
            dao.setEnabled(sources.first().name, isEnabled)
            return
        }
        db.withTransaction {
            for (source in sources) {
                dao.setEnabled(source.name, isEnabled)
            }
        }
    }

    private suspend fun getNewSources(): MutableSet<out MangaSource> {
        val entities = dao.findAll()
        val result = LinkedHashSet<MangaSource>(allMangaSources)
        for (e in entities) {
            result.remove(e.source.toMangaSourceOrNull() ?: continue)
        }
        return result
    }

    private suspend fun setSourcesPinnedImpl(
        sources: Collection<MangaSource>,
        isPinned: Boolean,
    ) {
        if (sources.size == 1) { // fast path
            dao.setPinned(sources.first().name, isPinned)
            return
        }
        db.withTransaction {
            for (source in sources) {
                dao.setPinned(source.name, isPinned)
            }
        }
    }

    private fun observeExternalSources(): Flow<List<ExternalMangaSource>> = callbackFlow {
        val receiver =
            object : BroadcastReceiver() {
                override fun onReceive(
                    context: Context?,
                    intent: Intent?,
                ) {
                    trySendBlocking(intent)
                }
            }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_VERIFIED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_FULLY_REMOVED)
                addDataScheme("package")
            },
            ContextCompat.RECEIVER_EXPORTED,
        )
        awaitClose { context.unregisterReceiver(receiver) }
    }.onStart {
        emit(null)
    }.map {
        getExternalSources()
    }.distinctUntilChanged()
        .conflate()

    fun getExternalSources(): List<ExternalMangaSource> = context.packageManager
        .queryIntentContentProviders(
            Intent("app.kotatsu.parser.PROVIDE_MANGA"),
            0,
        ).map { resolveInfo ->
            ExternalMangaSource(
                packageName = resolveInfo.providerInfo.packageName,
                authority = resolveInfo.providerInfo.authority,
            )
        }

    private fun List<MangaSourceEntity>.toSources(
        skipNsfwSources: Boolean,
        sortOrder: SourcesSortOrder?,
    ): MutableList<MangaSourceInfo> {
        val isAllEnabled = settings.isAllSourcesEnabled
        val result = ArrayList<MangaSourceInfo>(size)
        for (entity in this) {
            val source = entity.source.toMangaSourceOrNull() ?: continue
            if (skipNsfwSources && source.isNsfw()) {
                continue
            }
            if (source in allMangaSources) {
                result.add(
                    MangaSourceInfo(
                        mangaSource = source,
                        isEnabled = entity.isEnabled || isAllEnabled,
                        isPinned = entity.isPinned,
                    ),
                )
            }
        }
        if (sortOrder == SourcesSortOrder.ALPHABETIC) {
            result.sortWith(compareBy<MangaSourceInfo> { !it.isPinned }.thenBy { it.getTitle(context) })
        }
        return result
    }

    private fun observeIsNsfwDisabled() = settings.observeAsFlow(AppSettings.KEY_DISABLE_NSFW) {
        isNsfwContentDisabled
    }

    private fun observeSortOrder() = settings.observeAsFlow(AppSettings.KEY_SOURCES_ORDER) {
        sourcesSortOrder
    }

    private fun observeAllEnabled() = settings.observeAsFlow(AppSettings.KEY_SOURCES_ENABLED_ALL) {
        isAllSourcesEnabled
    }

    private fun String.toMangaSourceOrNull(): ParserMangaSource? = ActiveParsers.findSource(this)
}
