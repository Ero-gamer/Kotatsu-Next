package org.koitharu.kotatsu.core.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.annotation.XmlRes
import androidx.core.content.ContextCompat
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceGroup
import androidx.recyclerview.widget.RecyclerView
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.EntryPointAccessors
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.exceptions.resolve.ExceptionResolver
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.ui.util.RecyclerViewOwner
import org.koitharu.kotatsu.core.util.ext.consumeAllSystemBarsInsets
import org.koitharu.kotatsu.core.util.ext.container
import org.koitharu.kotatsu.core.util.ext.end
import org.koitharu.kotatsu.core.util.ext.getThemeColor
import org.koitharu.kotatsu.core.util.ext.getThemeDrawable
import org.koitharu.kotatsu.core.util.ext.parentView
import org.koitharu.kotatsu.core.util.ext.start
import org.koitharu.kotatsu.core.util.ext.systemBarsInsets
import org.koitharu.kotatsu.settings.SettingsActivity
import javax.inject.Inject
import com.google.android.material.R as materialR

@AndroidEntryPoint
abstract class BasePreferenceFragment(
    @StringRes private val titleId: Int,
) : PreferenceFragmentCompat(),
    OnApplyWindowInsetsListener,
    RecyclerViewOwner {
    protected lateinit var exceptionResolver: ExceptionResolver
        private set

    @Inject
    lateinit var settings: AppSettings

    override val recyclerView: RecyclerView?
        get() = listView

    /**
     * Whether this screen's preferences live in the app-wide settings (MMKV-backed). Screens with a
     * store of their own (per-source settings) return `false` and keep the manager's file.
     */
    protected open val usesAppSettingsStore: Boolean
        get() = true

    override fun addPreferencesFromResource(
        @XmlRes preferencesResId: Int,
    ) {
        // Must happen before inflation: Preferences bind to the data store when they are attached.
        if (usesAppSettingsStore && preferenceManager.preferenceDataStore == null) {
            preferenceManager.preferenceDataStore = settings.preferenceDataStore
        }
        super.addPreferencesFromResource(preferencesResId)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        val entryPoint = EntryPointAccessors.fromApplication<BaseActivityEntryPoint>(context)
        exceptionResolver = entryPoint.exceptionResolverFactory.create(this)
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)
        ViewCompat.setOnApplyWindowInsetsListener(view, this)
        val themedContext = (view.parentView ?: view).context
        view.setBackgroundColor(themedContext.getThemeColor(android.R.attr.colorBackground))
        listView.clipToPadding = false
    }

    override fun onApplyWindowInsets(
        v: View,
        insets: WindowInsetsCompat,
    ): WindowInsetsCompat {
        val barsInsets = insets.systemBarsInsets
        val isTablet = !resources.getBoolean(R.bool.is_tablet)
        val isMaster = container?.id == R.id.container_master
        listView.setPaddingRelative(
            if (isTablet && !isMaster) 0 else barsInsets.start(v),
            0,
            if (isTablet && isMaster) 0 else barsInsets.end(v),
            barsInsets.bottom,
        )
        return insets.consumeAllSystemBarsInsets()
    }

    override fun onResume() {
        super.onResume()
        setTitle(if (titleId != 0) getString(titleId) else null)
        arguments?.getString(SettingsActivity.ARG_PREF_KEY)?.let {
            focusPreference(it)
            arguments?.remove(SettingsActivity.ARG_PREF_KEY)
        }
    }

    protected open fun setTitle(title: CharSequence?) {
        (activity as? SettingsActivity)?.setSectionTitle(title)
    }

    protected fun getWarningIcon(): Drawable? = context?.let { ctx ->
        ContextCompat.getDrawable(ctx, R.drawable.ic_alert_outline)?.also {
            it.setTint(ContextCompat.getColor(ctx, R.color.warning))
        }
    }

    private fun focusPreference(key: String) {
        val pref = findPreference<Preference>(key)
        if (pref == null) {
            scrollToPreference(key)
            return
        }
        scrollToPreference(pref)
        // Through the adapter: most settings sit inside a category, which a position on the screen's own list misses
        listView.post {
            val positions = listView.adapter as? PreferenceGroup.PreferencePositionCallback ?: return@post
            val position = positions.getPreferenceAdapterPosition(pref)
            if (position == RecyclerView.NO_POSITION) return@post
            val view = listView.findViewHolderForAdapterPosition(position)?.itemView ?: return@post
            view.context.getThemeDrawable(materialR.attr.colorTertiaryContainer)?.let {
                view.background = it
            }
        }
    }
}
