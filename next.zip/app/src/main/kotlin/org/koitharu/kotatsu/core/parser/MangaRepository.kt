package org.koitharu.kotatsu.core.parser

import android.content.Context
import androidx.annotation.AnyThread
import androidx.collection.ArrayMap
import dagger.hilt.android.qualifiers.ApplicationContext
import org.koitharu.kotatsu.core.cache.MemoryContentCache
import org.koitharu.kotatsu.core.model.LocalMangaSource
import org.koitharu.kotatsu.core.model.MangaSourceInfo
import org.koitharu.kotatsu.core.model.TestMangaSource
import org.koitharu.kotatsu.core.model.UnknownMangaSource
import org.koitharu.kotatsu.core.parser.bundle.ActiveParsers
import org.koitharu.kotatsu.core.parser.bundle.LiveMangaParser
import org.koitharu.kotatsu.core.parser.bundle.ParsersUpdater
import org.koitharu.kotatsu.core.parser.external.ExternalMangaRepository
import org.koitharu.kotatsu.core.parser.external.ExternalMangaSource
import org.koitharu.kotatsu.local.data.LocalMangaRepository
import org.koitharu.kotatsu.parsers.MangaLoaderContext
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.MangaChapter
import org.koitharu.kotatsu.parsers.model.MangaListFilter
import org.koitharu.kotatsu.parsers.model.MangaListFilterCapabilities
import org.koitharu.kotatsu.parsers.model.MangaListFilterOptions
import org.koitharu.kotatsu.parsers.model.MangaPage
import org.koitharu.kotatsu.parsers.model.ParserMangaSource
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.model.SortOrder
import java.lang.ref.WeakReference
import javax.inject.Inject
import javax.inject.Singleton

interface MangaRepository {

    val source: MangaSource

    val sortOrders: Set<SortOrder>

    var defaultSortOrder: SortOrder

    val filterCapabilities: MangaListFilterCapabilities

    suspend fun getList(offset: Int, order: SortOrder?, filter: MangaListFilter?): List<Manga>

    suspend fun getDetails(manga: Manga): Manga

    suspend fun getPages(chapter: MangaChapter): List<MangaPage>

    suspend fun getPageUrl(page: MangaPage): String

    suspend fun getFilterOptions(): MangaListFilterOptions

    suspend fun getRelated(seed: Manga): List<Manga>

    suspend fun find(manga: Manga): Manga? {
        val list = getList(0, SortOrder.RELEVANCE, MangaListFilter(query = manga.title))
        return list.find { x -> x.id == manga.id }
    }

    @Singleton
    class Factory @Inject constructor(
        @ApplicationContext private val context: Context,
        private val localMangaRepository: LocalMangaRepository,
        private val loaderContext: MangaLoaderContext,
        private val contentCache: MemoryContentCache,
        private val mirrorSwitcher: MirrorSwitcher,
        private val parsersUpdater: ParsersUpdater,
    ) {

        private val cache = ArrayMap<MangaSource, WeakReference<MangaRepository>>()

        /** The last few repositories are held strongly: a GC must not drop a parser (and its fetched filters) in use. */
        private val recent = object : LinkedHashMap<MangaSource, MangaRepository>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<MangaSource, MangaRepository>?) =
                size > RECENT_LIMIT
        }

        @AnyThread
        fun create(source: MangaSource): MangaRepository {
            when (source) {
                is MangaSourceInfo -> return create(source.mangaSource)
                LocalMangaSource -> return localMangaRepository
                UnknownMangaSource -> return EmptyMangaRepository(source)
            }
            // ArrayMap and LinkedHashMap are not thread-safe: every access happens under the lock.
            return synchronized(cache) {
                cache[source]?.get()?.let {
                    recent[source] = it
                    return it
                }
                val repository = createRepository(source)
                if (repository != null) {
                    cache[source] = WeakReference(repository)
                    recent[source] = repository
                    repository
                } else {
                    EmptyMangaRepository(source)
                }
            }
        }

        private fun createRepository(source: MangaSource): MangaRepository? = when (source) {
            is ParserMangaSource -> if (ActiveParsers.findSource(source.name) != null) {
                ParserMangaRepository(
                    parser = LiveMangaParser(source.name, loaderContext, parsersUpdater),
                    cache = contentCache,
                    mirrorSwitcher = mirrorSwitcher,
                )
            } else {
                // A source of parsers that are not in use any more, held on to by whoever asks. Not kept: the next
                // parsers may have it again
                null
            }

            TestMangaSource -> TestMangaRepository(
                loaderContext = loaderContext,
                cache = contentCache,
            )

            is ExternalMangaSource -> if (source.isAvailable(context)) {
                ExternalMangaRepository(
                    contentResolver = context.contentResolver,
                    source = source,
                    cache = contentCache,
                )
            } else {
                EmptyMangaRepository(source)
            }

            else -> null
        }

        private companion object {
            const val RECENT_LIMIT = 8
        }
    }
}
