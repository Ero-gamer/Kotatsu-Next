package org.koitharu.kotatsu.core.prefs

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.annotation.FloatRange
import androidx.appcompat.app.AppCompatDelegate
import androidx.collection.ArraySet
import androidx.core.content.edit
import androidx.core.os.LocaleListCompat
import androidx.documentfile.provider.DocumentFile
import androidx.preference.PreferenceDataStore
import com.davemorrissey.labs.subscaleview.ImageDownscaler
import com.davemorrissey.labs.subscaleview.ImageScaler
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.ReaderHideThreshold
import org.koitharu.kotatsu.core.model.ZoomMode
import org.koitharu.kotatsu.core.model.ReaderTint
import org.koitharu.kotatsu.core.model.ZoomStart
import org.koitharu.kotatsu.core.network.DoHProvider
import org.koitharu.kotatsu.core.prefs.mmkv.MmkvPreferences
import org.koitharu.kotatsu.core.prefs.mmkv.SharedPreferencesDataStore
import org.koitharu.kotatsu.core.util.ext.connectivityManager
import org.koitharu.kotatsu.core.util.ext.getEnumValue
import org.koitharu.kotatsu.core.util.ext.observeChanges
import org.koitharu.kotatsu.core.util.ext.putAll
import org.koitharu.kotatsu.core.util.ext.putEnumValue
import org.koitharu.kotatsu.core.util.ext.takeIfReadable
import org.koitharu.kotatsu.core.util.ext.toUriOrNull
import org.koitharu.kotatsu.explore.data.SourcesSortOrder
import org.koitharu.kotatsu.list.domain.ListSortOrder
import org.koitharu.kotatsu.parsers.model.SortOrder
import org.koitharu.kotatsu.parsers.util.find
import org.koitharu.kotatsu.parsers.util.mapNotNullToSet
import org.koitharu.kotatsu.parsers.util.mapToSet
import org.koitharu.kotatsu.parsers.util.nullIfEmpty
import org.koitharu.kotatsu.reader.domain.ReaderColorFilter
import java.io.File
import java.net.Proxy
import java.util.EnumSet
import java.util.HashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Suppress("LargeClass") // one flat facade over every preference key, by design
@Singleton
class AppSettings
@Inject
constructor(
    @ApplicationContext context: Context,
) {
    // MMKV-backed (with a verified one-time import of the old XML file; falls back to the legacy
    // SharedPreferences if MMKV cannot load). Same SharedPreferences contract either way.
    private val prefs: SharedPreferences = MmkvPreferences.openAppSettings(context)

    /** Lets `androidx.preference` screens read/write [prefs] (their own manager would use the XML file). */
    val preferenceDataStore: PreferenceDataStore by lazy(LazyThreadSafetyMode.PUBLICATION) {
        SharedPreferencesDataStore(prefs)
    }
    private val connectivityManager = context.connectivityManager
    private val mangaListBadgesDefault = ArraySet(context.resources.getStringArray(R.array.values_list_badges))

    var listMode: ListMode
        get() = prefs.getEnumValue(KEY_LIST_MODE, ListMode.GRID)
        set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE, value) }

    val theme: Int
        get() =
            prefs.getString(KEY_THEME, null)?.toIntOrNull()
                ?: AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM

    val colorScheme: ColorScheme
        get() = prefs.getEnumValue(KEY_COLOR_THEME, ColorScheme.default)

    val isAmoledTheme: Boolean
        get() = prefs.getBoolean(KEY_THEME_AMOLED, false)

    /**
     * The built-in AppFont entry for the current selection, or APP_DEFAULT if the user
     * has selected a device font (key starts with "system:").
     */
    val appFont: AppFont
        get() = AppFont.fromKey(prefs.getString(KEY_APP_FONT, null))

    /**
     * Whether the user prefers the "cover title" card style (title drawn over the artwork with a
     * gradient scrim) or the classic style (title below the cover).
     * Returns true for cover-title (Expressive look), false for classic (default).
     */
    val isCoverTitleCardStyle: Boolean
        get() = prefs.getBoolean(KEY_MANGA_CARD_STYLE, false)

    var mainNavItems: List<NavItem>
        get() {
            val raw = prefs.getString(KEY_NAV_MAIN, null)?.split(',')
            return if (raw.isNullOrEmpty()) {
                listOf(NavItem.HISTORY, NavItem.FAVORITES, NavItem.EXPLORE, NavItem.FEED)
            } else {
                raw.mapNotNull { x -> NavItem.entries.find(x) }.ifEmpty { listOf(NavItem.EXPLORE) }
            }
        }
        set(value) {
            prefs.edit {
                putString(KEY_NAV_MAIN, value.joinToString(",") { it.name })
            }
        }

    val isNavLabelsVisible: Boolean
        get() = prefs.getBoolean(KEY_NAV_LABELS, true)

    val isNavBarPinned: Boolean
        get() = prefs.getBoolean(KEY_NAV_PINNED, false)

    val isFloatingNavBar: Boolean
        get() =
            if (prefs.contains(KEY_FLOATING_NAV)) {
                prefs.getBoolean(KEY_FLOATING_NAV, false)
            } else {
                colorScheme == ColorScheme.EXPRESSIVE
            }

    val isMainFabEnabled: Boolean
        get() = prefs.getBoolean(KEY_MAIN_FAB, true)

    var gridSize: Int
        get() = prefs.getInt(KEY_GRID_SIZE, 100)
        set(value) = prefs.edit { putInt(KEY_GRID_SIZE, value) }

    var gridSizePages: Int
        get() = prefs.getInt(KEY_GRID_SIZE_PAGES, 100)
        set(value) = prefs.edit { putInt(KEY_GRID_SIZE_PAGES, value) }

    /** The covers of the Explore tab, set apart from the library's: its charts are laid out closer together. */
    var gridSizeDiscover: Int
        get() = prefs.getInt(KEY_GRID_SIZE_DISCOVER, 100)
        set(value) = prefs.edit { putInt(KEY_GRID_SIZE_DISCOVER, value) }

    val isQuickFilterEnabled: Boolean
        get() = prefs.getBoolean(KEY_QUICK_FILTER, true)

    val isDescriptionExpanded: Boolean
        get() = !prefs.getBoolean(KEY_COLLAPSE_DESCRIPTION, true)

    var historyListMode: ListMode
        get() = prefs.getEnumValue(KEY_LIST_MODE_HISTORY, listMode)
        set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_HISTORY, value) }

    var suggestionsListMode: ListMode
        get() = prefs.getEnumValue(KEY_LIST_MODE_SUGGESTIONS, listMode)
        set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_SUGGESTIONS, value) }

    var favoritesListMode: ListMode
        get() = prefs.getEnumValue(KEY_LIST_MODE_FAVORITES, listMode)
        set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_FAVORITES, value) }

    var isNsfwContentDisabled: Boolean
        get() = prefs.getBoolean(KEY_DISABLE_NSFW, false)
        set(value) = prefs.edit { putBoolean(KEY_DISABLE_NSFW, value) }

    var appLocales: LocaleListCompat
        get() {
            val raw = prefs.getString(KEY_APP_LOCALE, null)
            return LocaleListCompat.forLanguageTags(raw)
        }
        set(value) {
            prefs.edit {
                putString(KEY_APP_LOCALE, value.toLanguageTags())
            }
        }

    var isReaderDoubleOnLandscape: Boolean
        get() = prefs.getBoolean(KEY_READER_DOUBLE_PAGES, false)
        set(value) = prefs.edit { putBoolean(KEY_READER_DOUBLE_PAGES, value) }

    var isReaderDoubleOnFoldable: Boolean
        get() = prefs.getBoolean(KEY_READER_DOUBLE_FOLDABLE, false)
        set(value) = prefs.edit { putBoolean(KEY_READER_DOUBLE_FOLDABLE, value) }

    var isReaderDoubleCoverPage: Boolean
        get() = prefs.getBoolean(KEY_READER_DOUBLE_COVER_PAGE, false)
        set(value) = prefs.edit { putBoolean(KEY_READER_DOUBLE_COVER_PAGE, value) }

    @get:FloatRange(0.0, 1.0)
    var readerDoublePagesSensitivity: Float
        get() = getFloatCompat(KEY_READER_DOUBLE_PAGES_SENSITIVITY, 0.5f).coerceIn(0f, 1f)
        set(
            @FloatRange(0.0, 1.0) value,
        ) = prefs.edit { putFloat(KEY_READER_DOUBLE_PAGES_SENSITIVITY, value) }

    val readerScreenOrientation: Int
        get() =
            prefs.getString(KEY_READER_ORIENTATION, null)?.toIntOrNull()
                ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    val isReaderVolumeButtonsEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_VOLUME_BUTTONS, false)

    val isReaderZoomButtonsEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_ZOOM_BUTTONS, false)

    val isReaderControlAlwaysLTR: Boolean
        get() = prefs.getBoolean(KEY_READER_CONTROL_LTR, false)

    /** Tap grid mirroring: 0 none, 1 left-right, 2 top-bottom, 3 both. */
    val readerTapInversion: Int
        get() = prefs.getString(KEY_READER_TAP_INVERSION, null)?.toIntOrNull()?.coerceIn(0, 3) ?: 0

    val isReaderNavigationInverted: Boolean
        get() = prefs.getBoolean(KEY_READER_NAVIGATION_INVERTED, false)

    var isVerticalSliderEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_VERTICAL_SLIDER, false)
        set(value) = prefs.edit { putBoolean(KEY_READER_VERTICAL_SLIDER, value) }

    val isReaderFullscreenEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_FULLSCREEN, true)

    val isReaderOptimizationEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_OPTIMIZE, false)

    val isEInkFlashEnabled: Boolean
        get() = prefs.getBoolean(KEY_EINK_FLASH, false)

    val eInkFlashDuration: Int
        get() = prefs.getInt(KEY_EINK_FLASH_DURATION, 300).coerceIn(100, 1000)

    val eInkFlashEvery: Int
        get() = prefs.getInt(KEY_EINK_FLASH_EVERY, 1).coerceAtLeast(1)

    val eInkFlashColor: EInkFlashColor
        get() = prefs.getEnumValue(KEY_EINK_FLASH_COLOR, EInkFlashColor.WHITE)

    val readerControls: Set<ReaderControl>
        get() =
            prefs.getStringSet(KEY_READER_CONTROLS, null)?.mapNotNullTo(EnumSet.noneOf(ReaderControl::class.java)) {
                ReaderControl.entries.find(it)
            } ?: ReaderControl.DEFAULT

    val isOfflineCheckDisabled: Boolean
        get() = prefs.getBoolean(KEY_OFFLINE_DISABLED, false)

    var isAllFavouritesVisible: Boolean
        get() = prefs.getBoolean(KEY_ALL_FAVOURITES_VISIBLE, true)
        set(value) = prefs.edit { putBoolean(KEY_ALL_FAVOURITES_VISIBLE, value) }

    val isTrackerEnabled: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_ENABLED, true)

    val isTrackerWifiOnly: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_WIFI_ONLY, false)

    val trackerFrequencyFactor: Float
        get() = prefs.getString(KEY_TRACKER_FREQUENCY, null)?.toFloatOrNull() ?: 1f

    val isTrackerNotificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_NOTIFICATIONS, true)

    val isTrackerNsfwDisabled: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_NO_NSFW, false)

    val trackerDownloadStrategy: TrackerDownloadStrategy
        get() = prefs.getEnumValue(KEY_TRACKER_DOWNLOAD, TrackerDownloadStrategy.DISABLED)

    var isTrackerUnstuckMigrationDone: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_UNSTUCK_MIGRATION_V4, false)
        set(value) = prefs.edit { putBoolean(KEY_TRACKER_UNSTUCK_MIGRATION_V4, value) }

    var isTrackerProgressRefreshDone: Boolean
        get() = prefs.getBoolean(KEY_TRACKER_PROGRESS_REFRESH_V1, false)
        set(value) = prefs.edit { putBoolean(KEY_TRACKER_PROGRESS_REFRESH_V1, value) }

    var notificationSound: Uri
        get() =
            prefs.getString(KEY_NOTIFICATIONS_SOUND, null)?.toUriOrNull()
                ?: Settings.System.DEFAULT_NOTIFICATION_URI
        set(value) = prefs.edit { putString(KEY_NOTIFICATIONS_SOUND, value.toString()) }

    val notificationVibrate: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_VIBRATE, false)

    val notificationLight: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_LIGHT, true)

    val readerAnimation: ReaderAnimation
        get() = prefs.getEnumValue(KEY_READER_ANIMATION, ReaderAnimation.DEFAULT)

    val readerBackground: ReaderBackground
        get() = prefs.getEnumValue(KEY_READER_BACKGROUND, ReaderBackground.DEFAULT)

    /** Resampling used while zoomed in (draw time). Non-default values need Android 13+. */
    val readerScaler: ImageScaler
        get() {
            // The B-Spline scaler was removed: move its stored choice to the closest remaining one.
            if (prefs.getString(KEY_READER_SCALER, null) == LEGACY_SCALER_BSPLINE) {
                prefs.edit { putEnumValue(KEY_READER_SCALER, ImageScaler.ROBIDOUX) }
            }
            return prefs.getEnumValue(KEY_READER_SCALER, ImageScaler.DEFAULT)
        }

    /** Resampling used while zoomed out (draw time). Non-default values need OpenGL ES 3.0 (or Android 13+). */
    val readerDownscaler: ImageDownscaler
        get() = prefs.getEnumValue(KEY_READER_DOWNSCALER, ImageDownscaler.DEFAULT)

    /** Reduce sharpening on screentone pages (automatic detection). On by default. */
    val isSmartSharpenEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_SMART_SHARPEN, true)

    /** SSIV's minimum tile DPI: 180/240/320, lower = fewer tiles, less RAM, blurrier when zoomed. */
    val readerTileDpi: Int
        get() = prefs.getInt(KEY_READER_TILE_DPI, 320)

    val defaultReaderMode: ReaderMode
        get() = prefs.getEnumValue(KEY_READER_MODE, ReaderMode.STANDARD)

    val isReaderModeDetectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_MODE_DETECT, true)

    var isHistoryGroupingEnabled: Boolean
        get() = prefs.getBoolean(KEY_HISTORY_GROUPING, true)
        set(value) = prefs.edit { putBoolean(KEY_HISTORY_GROUPING, value) }

    var isUpdatedGroupingEnabled: Boolean
        get() = prefs.getBoolean(KEY_UPDATED_GROUPING, true)
        set(value) = prefs.edit { putBoolean(KEY_UPDATED_GROUPING, value) }

    var isFeedHeaderVisible: Boolean
        get() = prefs.getBoolean(KEY_FEED_HEADER, true)
        set(value) = prefs.edit { putBoolean(KEY_FEED_HEADER, value) }

    val progressIndicatorMode: ProgressIndicatorMode
        get() = prefs.getEnumValue(KEY_PROGRESS_INDICATORS, ProgressIndicatorMode.PERCENT_READ)

    var incognitoModeForNsfw: TriStateOption
        get() = prefs.getEnumValue(KEY_INCOGNITO_NSFW, TriStateOption.ASK)
        set(value) = prefs.edit { putEnumValue(KEY_INCOGNITO_NSFW, value) }

    var isIncognitoModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_INCOGNITO_MODE, false)
        set(value) = prefs.edit { putBoolean(KEY_INCOGNITO_MODE, value) }

    val isReaderMultiTaskEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_MULTITASK, false)

    var isChaptersReverse: Boolean
        get() = prefs.getBoolean(KEY_REVERSE_CHAPTERS, false)
        set(value) = prefs.edit { putBoolean(KEY_REVERSE_CHAPTERS, value) }

    var isChaptersGridView: Boolean
        get() = prefs.getBoolean(KEY_GRID_VIEW_CHAPTERS, false)
        set(value) = prefs.edit { putBoolean(KEY_GRID_VIEW_CHAPTERS, value) }

    val zoomMode: ZoomMode
        get() = prefs.getEnumValue(KEY_ZOOM_MODE, ZoomMode.FIT_CENTER)

    /** Wide page shown in a portrait view: after a short pause zoom to fit its height. */
    val isLandscapeAutoZoom: Boolean
        get() = prefs.getBoolean(KEY_LANDSCAPE_ZOOM, false)

    /** A page-turn tap first pans a zoomed page by one screen width, and only turns the page at its edge. */
    val isTapToPan: Boolean
        get() = prefs.getBoolean(KEY_TAP_TO_PAN, false)

    val readerHideThreshold: ReaderHideThreshold
        get() = prefs.getEnumValue(KEY_READER_HIDE_THRESHOLD, ReaderHideThreshold.OFF)

    val zoomStart: ZoomStart
        get() = prefs.getEnumValue(KEY_ZOOM_START, ZoomStart.AUTO)

    val isDoubleTapZoomEnabled: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_TAP_ZOOM, true)

    /** Double-tap zoom animation length in ms; 0 keeps the default. */
    val doubleTapZoomDuration: Int
        get() = prefs.getString(KEY_DOUBLE_TAP_SPEED, null)?.toIntOrNull()?.coerceIn(0, 2000) ?: 0

    /** Reader window brightness in percent; 0 follows the system. */
    val readerBrightness: Int
        get() = prefs.getInt(KEY_READER_BRIGHTNESS, 0).coerceIn(0, 100)

    /** Black overlay strength in percent. */
    val readerDim: Int
        get() = prefs.getInt(KEY_READER_DIM, 0).coerceIn(0, MAX_READER_DIM)

    val readerTint: ReaderTint
        get() = prefs.getEnumValue(KEY_READER_TINT, ReaderTint.OFF)

    /** Color overlay strength in percent. */
    val readerTintStrength: Int
        get() = prefs.getInt(KEY_READER_TINT_STRENGTH, DEFAULT_READER_TINT_STRENGTH).coerceIn(0, MAX_READER_TINT_STRENGTH)

    val trackSources: Set<String>
        get() = prefs.getStringSet(KEY_TRACK_SOURCES, null) ?: setOf(TRACK_FAVOURITES)

    var appPassword: String?
        get() = prefs.getString(KEY_APP_PASSWORD, null)
        set(value) =
            prefs.edit {
                if (value != null) putString(KEY_APP_PASSWORD, value) else remove(KEY_APP_PASSWORD)
            }

    var isAppPasswordNumeric: Boolean
        get() = prefs.getBoolean(KEY_APP_PASSWORD_NUMERIC, false)
        set(value) = prefs.edit { putBoolean(KEY_APP_PASSWORD_NUMERIC, value) }

    val searchSuggestionTypes: Set<SearchSuggestionType>
        get() =
            prefs.getStringSet(KEY_SEARCH_SUGGESTION_TYPES, null)?.let { stringSet ->
                stringSet.mapNotNullTo(EnumSet.noneOf(SearchSuggestionType::class.java)) { x ->
                    enumValueOf<SearchSuggestionType>(x)
                }
            } ?: EnumSet.allOf(SearchSuggestionType::class.java)

    var isBiometricProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_PROTECT_APP_BIOMETRIC, true)
        set(value) = prefs.edit { putBoolean(KEY_PROTECT_APP_BIOMETRIC, value) }

    val isMirrorSwitchingEnabled: Boolean
        get() = prefs.getBoolean(KEY_MIRROR_SWITCHING, false)

    val isExitConfirmationEnabled: Boolean
        get() = prefs.getBoolean(KEY_EXIT_CONFIRM, false)

    /**
     * How often to run a background sync, in hours, or `0` to only sync when local data changes.
     * Applied by SyncController.updateSyncSchedule.
     */
    val syncPeriodHours: Int
        get() = prefs.getString(KEY_SYNC_PERIOD, null)?.toIntOrNull() ?: SYNC_PERIOD_DEFAULT

    val isDynamicShortcutsEnabled: Boolean
        get() = prefs.getBoolean(KEY_SHORTCUTS, true)

    /**
     * Keep adult manga out of the launcher's long-press shortcuts.
     *
     * Defaults to `true`, unlike the other per-surface NSFW switches: the home screen is visible to
     * anyone holding the phone, not just to whoever opened the app.
     */
    val isShortcutsNsfwDisabled: Boolean
        get() = prefs.getBoolean(KEY_SHORTCUTS_NO_NSFW, true)

    val isUnstableUpdatesAllowed: Boolean
        get() = prefs.getBoolean(KEY_UPDATES_UNSTABLE, false)

    val isPageFormatBadgeEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAGE_FORMAT_BADGE, true)

    val isPageAnimatedBadgeEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAGE_ANIMATED_BADGE, true)

    val isPageBadgeHideCommon: Boolean
        get() = prefs.getBoolean(KEY_PAGE_BADGE_HIDE_COMMON, false)

    val isPagesTabEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAGES_TAB, true)

    val defaultDetailsTab: Int
        get() =
            if (isPagesTabEnabled) {
                val raw = prefs.getString(KEY_DETAILS_TAB, null)?.toIntOrNull() ?: -1
                if (raw == -1) {
                    lastDetailsTab
                } else {
                    raw
                }.coerceIn(0, 2)
            } else {
                0
            }

    var lastDetailsTab: Int
        get() = prefs.getInt(KEY_DETAILS_LAST_TAB, 0)
        set(value) = prefs.edit { putInt(KEY_DETAILS_LAST_TAB, value) }

    val isContentPrefetchEnabled: Boolean
        get() {
            if (isBackgroundNetworkRestricted()) {
                return false
            }
            val policy =
                NetworkPolicy.from(prefs.getString(KEY_PREFETCH_CONTENT, null), NetworkPolicy.NEVER)
            return policy.isNetworkAllowed(connectivityManager)
        }

    var sourcesSortOrder: SourcesSortOrder
        get() = prefs.getEnumValue(KEY_SOURCES_ORDER, SourcesSortOrder.MANUAL)
        set(value) = prefs.edit { putEnumValue(KEY_SOURCES_ORDER, value) }

    var isSourcesGridMode: Boolean
        get() = prefs.getBoolean(KEY_SOURCES_GRID, true)
        set(value) = prefs.edit { putBoolean(KEY_SOURCES_GRID, value) }

    var sourcesVersion: Int
        get() = prefs.getInt(KEY_SOURCES_VERSION, 0)
        set(value) = prefs.edit { putInt(KEY_SOURCES_VERSION, value) }

    /** Sources were added by parsers downloaded since the list of new ones was last looked at. */
    var hasNewDownloadedSources: Boolean
        get() = prefs.getBoolean(KEY_SOURCES_NEW_DOWNLOADED, false)
        set(value) = prefs.edit { putBoolean(KEY_SOURCES_NEW_DOWNLOADED, value) }

    /** Whether newer parsers than the app's own are looked for and taken in, see ParsersUpdater. */
    val isParsersAutoUpdateEnabled: Boolean
        get() = prefs.getBoolean(KEY_PARSERS_AUTO_UPDATE, true)

    var isAllSourcesEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOURCES_ENABLED_ALL, false)
        set(value) = prefs.edit { putBoolean(KEY_SOURCES_ENABLED_ALL, value) }

    var activeSourcePresetId: Long
        get() = getLongCompat(KEY_ACTIVE_SOURCE_PRESET, 0L)
        set(value) = prefs.edit { putLong(KEY_ACTIVE_SOURCE_PRESET, value) }

    val isPagesNumbersEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAGES_NUMBERS, false)

    val isAnimatedImagesEnabled: Boolean
        get() = prefs.getBoolean(KEY_ANIMATED_IMAGES, true)

    /** Animated covers play on the details screen (needs [isAnimatedImagesEnabled]; never in memory-saver mode). */
    val isDetailsCoverAnimated: Boolean
        get() = prefs.getBoolean(KEY_DETAILS_COVER_ANIMATED, false)

    val isAnimatedAutoplay: Boolean
        get() = prefs.getBoolean(KEY_ANIMATED_AUTOPLAY, true)

    val isAnimatedControls: Boolean
        get() = prefs.getBoolean(KEY_ANIMATED_CONTROLS, true)

    val isAnimatedAdvance: Boolean
        get() = prefs.getBoolean(KEY_ANIMATED_ADVANCE, false)

    /** Default animation speed multiplier. */
    val animatedSpeed: Float
        get() = prefs.getString(KEY_ANIMATED_SPEED, null)?.toFloatOrNull()?.coerceIn(0.25f, 4f) ?: 1f

    /** Loop override: -1 = as in the file, 0 = forever, N = N plays. */
    val animatedLoops: Int
        get() = prefs.getString(KEY_ANIMATED_LOOPS, null)?.toIntOrNull()?.coerceAtLeast(-1) ?: -1

    /** PNG page decoder: 0 = auto, 1 = system (Skia), 2 = native (Rust). */
    val pngDecoderMode: Int
        get() = prefs.getString(KEY_PNG_DECODER, null)?.toIntOrNull()?.coerceIn(0, 2) ?: 0

    val screenshotsPolicy: ScreenshotsPolicy
        get() = prefs.getEnumValue(KEY_SCREENSHOTS_POLICY, ScreenshotsPolicy.ALLOW)

    val isAdBlockEnabled: Boolean
        get() = prefs.getBoolean(KEY_ADBLOCK, false)

    var userSpecifiedMangaDirectories: Set<File>
        get() {
            val set = prefs.getStringSet(KEY_LOCAL_MANGA_DIRS, emptySet()).orEmpty()
            return set.mapNotNullToSet { File(it).takeIfReadable() }
        }
        set(value) {
            val set = value.mapToSet { it.absolutePath }
            prefs.edit { putStringSet(KEY_LOCAL_MANGA_DIRS, set) }
        }

    var mangaStorageDir: File?
        get() =
            prefs
                .getString(KEY_LOCAL_STORAGE, null)
                ?.let {
                    File(it)
                }?.takeIf { it.exists() && it in userSpecifiedMangaDirectories }
        set(value) =
            prefs.edit {
                if (value == null) {
                    remove(KEY_LOCAL_STORAGE)
                } else {
                    val userDirs = userSpecifiedMangaDirectories
                    if (value !in userDirs) {
                        userSpecifiedMangaDirectories = userDirs + value
                    }
                    putString(KEY_LOCAL_STORAGE, value.path)
                }
            }

    var allowDownloadOnMeteredNetwork: TriStateOption
        get() = prefs.getEnumValue(KEY_DOWNLOADS_METERED_NETWORK, TriStateOption.ASK)
        set(value) = prefs.edit { putEnumValue(KEY_DOWNLOADS_METERED_NETWORK, value) }

    /** How many chapters after the one being read are saved ahead of the reader (0 = off). */
    val downloadAheadCount: Int
        get() = prefs.getString(KEY_DOWNLOAD_AHEAD, null)?.toIntOrNull()?.coerceIn(0, 10) ?: 0

    val preferredDownloadFormat: DownloadFormat
        get() = prefs.getEnumValue(KEY_DOWNLOADS_FORMAT, DownloadFormat.AUTOMATIC)

    var isSuggestionsEnabled: Boolean
        get() = prefs.getBoolean(KEY_SUGGESTIONS, false)
        set(value) = prefs.edit { putBoolean(KEY_SUGGESTIONS, value) }

    val isSuggestionsWiFiOnly: Boolean
        get() = prefs.getBoolean(KEY_SUGGESTIONS_WIFI_ONLY, false)

    val isSuggestionsExcludeNsfw: Boolean
        get() = prefs.getBoolean(KEY_SUGGESTIONS_EXCLUDE_NSFW, false)

    val isSuggestionsIncludeDisabledSources: Boolean
        get() = prefs.getBoolean(KEY_SUGGESTIONS_DISABLED_SOURCES, false)

    val isSuggestionsNotificationAvailable: Boolean
        get() = prefs.getBoolean(KEY_SUGGESTIONS_NOTIFICATIONS, false)

    val suggestionsTagsBlacklist: Set<String>
        get() {
            val string = prefs.getString(KEY_SUGGESTIONS_EXCLUDE_TAGS, null)?.trimEnd(' ', ',')
            if (string.isNullOrEmpty()) {
                return emptySet()
            }
            return string.split(',').mapToSet { it.trim() }
        }

    val isReaderBarEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_BAR, true)

    val isReaderBarTransparent: Boolean
        get() = prefs.getBoolean(KEY_READER_BAR_TRANSPARENT, true)

    val isSkipDuplicateChapters: Boolean
        get() = prefs.getBoolean(KEY_READER_SKIP_DUPES, false)

    val isReaderChapterToastEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_CHAPTER_TOAST, true)

    val isMissingChapterWarningEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_MISSING_WARN, true)

    val isReaderKeepScreenOn: Boolean
        get() = prefs.getBoolean(KEY_READER_SCREEN_ON, true)

    var readerColorFilter: ReaderColorFilter?
        get() =
            runCatching {
                // Pre-split preferences stored one shared intensity (KEY_CF_SHARPENING) plus a mode
                // selector (KEY_CF_SHARPEN_MODE: 1 = RCAS + USM, 2 = Adaptive/smoothstep). Until the
                // user saves again, map those onto the per-filter keys so nothing is lost.
                val legacyMode = prefs.getInt(KEY_CF_SHARPEN_MODE, 0)
                val legacySharpening = getFloatCompat(KEY_CF_SHARPENING, 0f)
                // The mislabeled three-way split (RCAS+USM / Adaptive-smoothstep / Adaptive-sigmoid)
                // is superseded by two real filters (RCAS / Adaptive-Sharpen). Best-effort carry the
                // user's old slider positions forward: KEY_CF_RCAS_USM -> rcas directly, and
                // whichever of the two near-duplicate Adaptive intensities was larger -> adaptiveSharpen.
                val legacyRcasUsm = getFloatCompat(KEY_CF_RCAS_USM, 0f)
                val legacyAdaptive =
                    maxOf(
                        getFloatCompat(KEY_CF_ADAPTIVE_SMOOTHSTEP, 0f),
                        getFloatCompat(KEY_CF_ADAPTIVE_SIGMOID, 0f),
                    )
                ReaderColorFilter(
                    brightness = getFloatCompat(KEY_CF_BRIGHTNESS, ReaderColorFilter.EMPTY.brightness),
                    contrast = getFloatCompat(KEY_CF_CONTRAST, ReaderColorFilter.EMPTY.contrast),
                    saturation = getFloatCompat(KEY_CF_SATURATION, ReaderColorFilter.EMPTY.saturation),
                    vibrance = getFloatCompat(KEY_CF_VIBRANCE, ReaderColorFilter.EMPTY.vibrance),
                    denoise = getFloatCompat(KEY_CF_DENOISE, ReaderColorFilter.EMPTY.denoise),
                    rcas =
                    if (prefs.contains(KEY_CF_RCAS)) {
                        getFloatCompat(KEY_CF_RCAS, 0f)
                    } else if (legacyMode == 1) {
                        legacySharpening
                    } else {
                        legacyRcasUsm
                    },
                    adaptiveSharpen =
                    if (prefs.contains(KEY_CF_ADAPTIVE_SHARPEN)) {
                        getFloatCompat(KEY_CF_ADAPTIVE_SHARPEN, 0f)
                    } else if (legacyMode == 2) {
                        legacySharpening
                    } else {
                        legacyAdaptive
                    },
                    deband = getFloatCompat(KEY_CF_DEBAND, ReaderColorFilter.EMPTY.deband),
                    binarize = getFloatCompat(KEY_CF_BINARIZE, ReaderColorFilter.EMPTY.binarize),
                    isInverted = prefs.getBoolean(KEY_CF_INVERTED, ReaderColorFilter.EMPTY.isInverted),
                    isGrayscale = prefs.getBoolean(KEY_CF_GRAYSCALE, ReaderColorFilter.EMPTY.isGrayscale),
                    isBookBackground = prefs.getBoolean(KEY_CF_BOOK, ReaderColorFilter.EMPTY.isBookBackground),
                    isLineDarkenEnabled =
                    prefs.getBoolean(
                        KEY_CF_LINE_DARKEN,
                        ReaderColorFilter.EMPTY.isLineDarkenEnabled,
                    ),
                    isAutoContrast = prefs.getBoolean(KEY_CF_AUTO_CONTRAST, ReaderColorFilter.EMPTY.isAutoContrast),
                    isAutoBrightness = prefs.getBoolean(KEY_CF_AUTO_BRIGHTNESS, ReaderColorFilter.EMPTY.isAutoBrightness),
                    isAutoSaturation = prefs.getBoolean(KEY_CF_AUTO_SATURATION, ReaderColorFilter.EMPTY.isAutoSaturation),
                    overlayRed = getFloatCompat(KEY_CF_OVERLAY_R, ReaderColorFilter.EMPTY.overlayRed),
                    overlayGreen = getFloatCompat(KEY_CF_OVERLAY_G, ReaderColorFilter.EMPTY.overlayGreen),
                    overlayBlue = getFloatCompat(KEY_CF_OVERLAY_B, ReaderColorFilter.EMPTY.overlayBlue),
                    overlayAlpha = getFloatCompat(KEY_CF_OVERLAY_A, ReaderColorFilter.EMPTY.overlayAlpha),
                ).takeUnless { it.isEmpty }
            }.getOrNull()
        set(value) {
            prefs.edit {
                if (value != null) {
                    putFloat(KEY_CF_BRIGHTNESS, value.brightness)
                    putFloat(KEY_CF_CONTRAST, value.contrast)
                    putFloat(KEY_CF_SATURATION, value.saturation)
                    putFloat(KEY_CF_VIBRANCE, value.vibrance)
                    putFloat(KEY_CF_DENOISE, value.denoise)
                    putFloat(KEY_CF_RCAS, value.rcas)
                    putFloat(KEY_CF_ADAPTIVE_SHARPEN, value.adaptiveSharpen)
                    putFloat(KEY_CF_DEBAND, value.deband)
                    putFloat(KEY_CF_BINARIZE, value.binarize)
                    // Legacy keys are superseded; drop them so the read-side fallback ends.
                    remove(KEY_CF_SHARPENING)
                    remove(KEY_CF_SHARPEN_MODE)
                    remove(KEY_CF_RCAS_USM)
                    remove(KEY_CF_ADAPTIVE_SMOOTHSTEP)
                    remove(KEY_CF_ADAPTIVE_SIGMOID)
                    putBoolean(KEY_CF_INVERTED, value.isInverted)
                    putBoolean(KEY_CF_GRAYSCALE, value.isGrayscale)
                    putBoolean(KEY_CF_BOOK, value.isBookBackground)
                    putBoolean(KEY_CF_LINE_DARKEN, value.isLineDarkenEnabled)
                    putBoolean(KEY_CF_AUTO_CONTRAST, value.isAutoContrast)
                    putBoolean(KEY_CF_AUTO_BRIGHTNESS, value.isAutoBrightness)
                    putBoolean(KEY_CF_AUTO_SATURATION, value.isAutoSaturation)
                    putFloat(KEY_CF_OVERLAY_R, value.overlayRed)
                    putFloat(KEY_CF_OVERLAY_G, value.overlayGreen)
                    putFloat(KEY_CF_OVERLAY_B, value.overlayBlue)
                    putFloat(KEY_CF_OVERLAY_A, value.overlayAlpha)
                } else {
                    remove(KEY_CF_BRIGHTNESS)
                    remove(KEY_CF_CONTRAST)
                    remove(KEY_CF_SHARPENING)
                    remove(KEY_CF_SATURATION)
                    remove(KEY_CF_VIBRANCE)
                    remove(KEY_CF_DENOISE)
                    remove(KEY_CF_SHARPEN_MODE)
                    remove(KEY_CF_RCAS_USM)
                    remove(KEY_CF_ADAPTIVE_SMOOTHSTEP)
                    remove(KEY_CF_ADAPTIVE_SIGMOID)
                    remove(KEY_CF_RCAS)
                    remove(KEY_CF_ADAPTIVE_SHARPEN)
                    remove(KEY_CF_DEBAND)
                    remove(KEY_CF_BINARIZE)
                    // Keys of the removed decode-time resamplers (early builds only): clean up.
                    remove("cf_catmull_rom")
                    remove("cf_bspline")
                    remove(KEY_CF_INVERTED)
                    remove(KEY_CF_GRAYSCALE)
                    remove(KEY_CF_BOOK)
                    remove(KEY_CF_LINE_DARKEN)
                    remove(KEY_CF_AUTO_CONTRAST)
                    remove(KEY_CF_AUTO_BRIGHTNESS)
                    remove(KEY_CF_AUTO_SATURATION)
                    remove(KEY_CF_OVERLAY_R)
                    remove(KEY_CF_OVERLAY_G)
                    remove(KEY_CF_OVERLAY_B)
                    remove(KEY_CF_OVERLAY_A)
                }
            }
        }

    val imagesProxy: Int
        get() {
            val raw = prefs.getString(KEY_IMAGES_PROXY, null)?.toIntOrNull()
            return raw ?: if (prefs.getBoolean(KEY_IMAGES_PROXY_OLD, false)) 0 else -1
        }

    val dnsOverHttps: DoHProvider
        get() = prefs.getEnumValue(KEY_DOH, DoHProvider.NONE)

    var isSSLBypassEnabled: Boolean
        get() = prefs.getBoolean(KEY_SSL_BYPASS, false)
        set(value) = prefs.edit { putBoolean(KEY_SSL_BYPASS, value) }

    /** When true, CloudFlare challenges are never auto-solved in the background for any source. */
    val isCfAutoSolveDisabled: Boolean
        get() = prefs.getBoolean(KEY_CF_AUTO_SOLVE_DISABLED, false)

    val proxyType: Proxy.Type
        get() {
            val raw = prefs.getString(KEY_PROXY_TYPE, null) ?: return Proxy.Type.DIRECT
            return enumValues<Proxy.Type>().find { it.name == raw } ?: Proxy.Type.DIRECT
        }

    val proxyAddress: String?
        get() = prefs.getString(KEY_PROXY_ADDRESS, null)

    val proxyPort: Int
        get() = prefs.getString(KEY_PROXY_PORT, null)?.toIntOrNull() ?: 0

    val proxyLogin: String?
        get() = prefs.getString(KEY_PROXY_LOGIN, null)?.nullIfEmpty()

    val proxyPassword: String?
        get() = prefs.getString(KEY_PROXY_PASSWORD, null)?.nullIfEmpty()

    var localListOrder: SortOrder
        get() = prefs.getEnumValue(KEY_LOCAL_LIST_ORDER, SortOrder.NEWEST)
        set(value) = prefs.edit { putEnumValue(KEY_LOCAL_LIST_ORDER, value) }

    var historySortOrder: ListSortOrder
        get() = prefs.getEnumValue(KEY_HISTORY_ORDER, ListSortOrder.LAST_READ)
        set(value) = prefs.edit { putEnumValue(KEY_HISTORY_ORDER, value) }

    var allFavoritesSortOrder: ListSortOrder
        get() = prefs.getEnumValue(KEY_FAVORITES_ORDER, ListSortOrder.NEWEST)
        set(value) = prefs.edit { putEnumValue(KEY_FAVORITES_ORDER, value) }

    val isRelatedMangaEnabled: Boolean
        get() = prefs.getBoolean(KEY_RELATED_MANGA, true)

    val isWebtoonZoomEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEBTOON_ZOOM, true)

    var isWebtoonGapsEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEBTOON_GAPS, false)
        set(value) = prefs.edit { putBoolean(KEY_WEBTOON_GAPS, value) }

    /** Empty space left and right of a webtoon page, as a percentage of the display width per side. 0 = off. */
    val webtoonSidePadding: Int
        get() = prefs.getInt(KEY_WEBTOON_SIDE_PADDING, 0)

    /** Empty space between the two pages of a double-page spread, percentage of display width. */
    val doublePageGap: Int
        get() = prefs.getInt(KEY_DOUBLE_PAGE_GAP, 0).coerceIn(0, 10)

    /** Per-channel RGBA tolerance for "is this pixel white" during crop-borders edge detection. */
    val cropBordersTolerance: Int
        get() = prefs.getInt(KEY_READER_CROP_TOLERANCE, 16)

    var isWebtoonPullGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEBTOON_PULL_GESTURE, false)
        set(value) = prefs.edit { putBoolean(KEY_WEBTOON_PULL_GESTURE, value) }

    /**
     * Global opt-in "Memory Saver" for low-end devices (2 GB RAM or less). Off by default; when off every
     * reading mode keeps its standard memory behaviour. When on, pages are released as soon as they are
     * left and prefetch / tile limits are tightened.
     */
    val isMemorySaverEnabled: Boolean
        get() = prefs.getBoolean(KEY_MEMORY_SAVER, false)

    /**
     * When enabled, caps the number of fully-decoded webtoon pages kept in RAM during
     * scrolling to roughly 3 (previous + current + next), instead of the RecyclerView
     * default of holding extra off-screen views bound and prefetching ahead during fling.
     *
     * Off by default: it has no real benefit on standard-resolution pages and trades
     * away the smooth instant-scroll-back behavior the default cache provides. Intended
     * for extra-tall/high-resolution strip chapters on low-RAM devices where multiple
     * simultaneously-decoded pages risk OOM.
     */
    var isWebtoonMemorySaverEnabled: Boolean
        get() = prefs.getBoolean(KEY_WEBTOON_MEMORY_SAVER, false)
        set(value) = prefs.edit { putBoolean(KEY_WEBTOON_MEMORY_SAVER, value) }

    @get:FloatRange(from = 0.0, to = 0.5)
    val defaultWebtoonZoomOut: Float
        get() = prefs.getInt(KEY_WEBTOON_ZOOM_OUT, 0).coerceIn(0, 50) / 100f

    @get:FloatRange(from = 0.0, to = 1.0)
    var readerAutoscrollSpeed: Float
        get() = getFloatCompat(KEY_READER_AUTOSCROLL_SPEED, 0f)
        set(
            @FloatRange(from = 0.0, to = 1.0) value,
        ) =
            prefs.edit {
                putFloat(
                    KEY_READER_AUTOSCROLL_SPEED,
                    value,
                )
            }

    var isReaderAutoscrollFabVisible: Boolean
        get() = prefs.getBoolean(KEY_READER_AUTOSCROLL_FAB, true)
        set(value) = prefs.edit { putBoolean(KEY_READER_AUTOSCROLL_FAB, value) }

    val isPagesPreloadEnabled: Boolean
        get() {
            if (isBackgroundNetworkRestricted()) {
                return false
            }
            val policy =
                NetworkPolicy.from(
                    prefs.getString(KEY_PAGES_PRELOAD, null),
                    NetworkPolicy.NON_METERED,
                )
            return policy.isNetworkAllowed(connectivityManager)
        }

    val is32BitColorsEnabled: Boolean
        get() = prefs.getBoolean(KEY_32BIT_COLOR, false)

    val isDiscordRpcEnabled: Boolean
        get() = prefs.getBoolean(KEY_DISCORD_RPC, false)

    val isDiscordRpcSkipNsfw: Boolean
        get() = prefs.getBoolean(KEY_DISCORD_RPC_SKIP_NSFW, false)

    var discordToken: String?
        get() = prefs.getString(KEY_DISCORD_TOKEN, null)?.trim()?.nullIfEmpty()
        set(value) = prefs.edit { putString(KEY_DISCORD_TOKEN, value?.nullIfEmpty()) }

    val isPeriodicalBackupEnabled: Boolean
        get() = prefs.getBoolean(KEY_BACKUP_PERIODICAL_ENABLED, false)

    val periodicalBackupFrequency: Float
        get() = prefs.getString(KEY_BACKUP_PERIODICAL_FREQUENCY, null)?.toFloatOrNull() ?: 7f

    val periodicalBackupFrequencyMillis: Long
        get() = (TimeUnit.DAYS.toMillis(1) * periodicalBackupFrequency).toLong()

    val periodicalBackupMaxCount: Int
        get() =
            if (prefs.getBoolean(KEY_BACKUP_PERIODICAL_TRIM, true)) {
                prefs.getInt(KEY_BACKUP_PERIODICAL_COUNT, 10)
            } else {
                Int.MAX_VALUE
            }

    var periodicalBackupDirectory: Uri?
        get() = prefs.getString(KEY_BACKUP_PERIODICAL_OUTPUT, null)?.toUriOrNull()
        set(value) = prefs.edit { putString(KEY_BACKUP_PERIODICAL_OUTPUT, value?.toString()) }

    val isBackupTelegramUploadEnabled: Boolean
        get() = prefs.getBoolean(KEY_BACKUP_TG_ENABLED, false)

    val backupTelegramChatId: String?
        get() = prefs.getString(KEY_BACKUP_TG_CHAT, null)?.nullIfEmpty()

    val isReadingTimeEstimationEnabled: Boolean
        get() = prefs.getBoolean(KEY_READING_TIME, true)

    val isPagesSavingAskEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAGES_SAVE_ASK, true)

    val isStatsEnabled: Boolean
        get() = prefs.getBoolean(KEY_STATS_ENABLED, false)

    val isTallSplitEnabled: Boolean
        get() = prefs.getBoolean(KEY_TALL_SPLIT, false)

    /** Double-page spread split at download time: 0 off, 1 left half first, 2 right half first. */
    val dualPageSplit: Int
        get() = when (prefs.getString(KEY_DUAL_SPLIT, null)) {
            "ltr" -> DUAL_SPLIT_LTR
            "rtl" -> DUAL_SPLIT_RTL
            else -> DUAL_SPLIT_OFF
        }

    /** Re-encoded WebP pages follow the source quality (see WebpPolicy); off = fixed behaviour with [tallSplitQuality]. */
    val isWebpQualityAuto: Boolean
        get() = prefs.getBoolean(KEY_WEBP_QUALITY_AUTO, true)

    /** Re-encode every downloaded still page as WebP (same resolution). */
    val isConvertToWebpOnDownload: Boolean
        get() = prefs.getBoolean(KEY_CONVERT_WEBP_DOWNLOAD, false)

    val tallSplitQuality: Int
        get() = prefs.getInt(KEY_TALL_SPLIT_QUALITY, 95).coerceIn(50, 100)

    val isCbzAutoRepackEnabled: Boolean
        get() = prefs.getBoolean(KEY_CBZ_AUTO_REPACK, false)

    val isAutoLocalChaptersCleanupEnabled: Boolean
        get() = prefs.getBoolean(KEY_CHAPTERS_CLEAR_AUTO, false)

    fun isPagesCropEnabled(mode: ReaderMode): Boolean {
        val rawValue = prefs.getStringSet(KEY_READER_CROP, emptySet())
        if (rawValue.isNullOrEmpty()) {
            return false
        }
        val needle = if (mode == ReaderMode.WEBTOON) READER_CROP_WEBTOON else READER_CROP_PAGED
        return needle.toString() in rawValue
    }

    val isReaderEraseGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_READER_ERASE_GESTURE, true)

    fun isTipEnabled(tip: String): Boolean = prefs.getStringSet(KEY_TIPS_CLOSED, emptySet())?.contains(tip) != true

    fun reopenTip(tip: String) {
        val closedTips = prefs.getStringSet(KEY_TIPS_CLOSED, emptySet()).orEmpty()
        prefs.edit { putStringSet(KEY_TIPS_CLOSED, closedTips - tip) }
    }

    fun closeTip(tip: String) {
        val closedTips = prefs.getStringSet(KEY_TIPS_CLOSED, emptySet()).orEmpty()
        if (tip in closedTips) {
            return
        }
        prefs.edit { putStringSet(KEY_TIPS_CLOSED, closedTips + tip) }
    }

    fun isIncognitoModeEnabled(isNsfw: Boolean): Boolean = isIncognitoModeEnabled || (isNsfw && incognitoModeForNsfw == TriStateOption.ENABLED)

    fun getPagesSaveDir(context: Context): DocumentFile? = prefs.getString(KEY_PAGES_SAVE_DIR, null)?.toUriOrNull()?.let {
        DocumentFile.fromTreeUri(context, it)?.takeIf { it.canWrite() }
    }

    fun setPagesSaveDir(uri: Uri?) {
        prefs.edit { putString(KEY_PAGES_SAVE_DIR, uri?.toString()) }
    }

    fun getMangaListBadges(): Int {
        val raw = prefs.getStringSet(KEY_MANGA_LIST_BADGES, mangaListBadgesDefault).orEmpty()
        var result = 0
        for (item in raw) {
            result = result or item.toInt()
        }
        return result
    }

    fun subscribe(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unsubscribe(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    fun observeChanges() = prefs.observeChanges()

    fun observe(vararg keys: String): Flow<String?> = prefs
        .observeChanges()
        .filter { key -> key == null || key in keys }
        .onStart { emit(null) }
        .flowOn(Dispatchers.IO)

    fun getAllValues(): Map<String, *> = prefs.all

    /** Settings that make sense in a backup: [BACKUP_LOCAL_KEYS] belong to this device only. */
    fun getBackupValues(): Map<String, *> = prefs.all.filterKeys { it !in BACKUP_LOCAL_KEYS }

    /**
     * Replaces the settings with the imported ones. Device-bound keys ([BACKUP_LOCAL_KEYS]) are neither imported nor
     * erased, and a number keeps the type this key has now (JSON does not tell Int from Long from Float).
     */
    fun upsertAll(m: Map<String, *>) {
        val current = prefs.all
        val imported = HashMap<String, Any?>(m.size)
        for ((key, value) in m) {
            if (key in BACKUP_LOCAL_KEYS) continue
            imported[key] = if (value is Number) {
                when (current[key]) {
                    is Float -> value.toFloat().takeIf { it.isFinite() } ?: value
                    is Long -> value.toLong()
                    is Int -> value.toInt()
                    else -> value
                }
            } else {
                value
            }
        }
        prefs.edit {
            clear()
            putAll(normalizeImportedPreferences(imported))
            for (key in BACKUP_LOCAL_KEYS) {
                when (val v = current[key]) {
                    is Boolean -> putBoolean(key, v)
                    is Int -> putInt(key, v)
                    is Long -> putLong(key, v)
                    is Float -> putFloat(key, v)
                    is String -> putString(key, v)
                    is Set<*> -> putStringSet(key, v.filterIsInstanceTo(HashSet<String>()))
                }
            }
        }
    }

    private fun getLongCompat(
        key: String,
        defaultValue: Long,
    ): Long = try {
        prefs.getLong(key, defaultValue)
    } catch (_: ClassCastException) {
        val fixedValue =
            when (val rawValue = prefs.all[key]) {
                is Number -> rawValue.toLong()
                is String -> rawValue.toLongOrNull()
                else -> null
            }
        if (fixedValue == null) {
            prefs.edit { remove(key) }
            defaultValue
        } else {
            prefs.edit { putLong(key, fixedValue) }
            fixedValue
        }
    }

    private fun normalizeImportedPreferences(values: Map<String, *>): Map<String, *> {
        val result = HashMap(values)
        result[KEY_ACTIVE_SOURCE_PRESET]?.let { rawValue ->
            val fixedValue =
                when (rawValue) {
                    is Long -> rawValue
                    is Number -> rawValue.toLong()
                    is String -> rawValue.toLongOrNull()
                    else -> null
                }
            if (fixedValue != null) {
                result[KEY_ACTIVE_SOURCE_PRESET] = fixedValue
            }
        }
        for (key in FLOAT_PREFERENCE_KEYS) {
            result[key]?.let { rawValue ->
                val fixedValue =
                    when (rawValue) {
                        is Number -> rawValue.toFloat()
                        is String -> rawValue.toFloatOrNull()
                        else -> null
                    }
                if (fixedValue != null && fixedValue.isFinite()) {
                    result[key] = fixedValue
                }
            }
        }
        return result
    }

    private fun isBackgroundNetworkRestricted(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        connectivityManager.restrictBackgroundStatus == ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED
    } else {
        false
    }

    private fun getFloatCompat(
        key: String,
        defaultValue: Float,
    ): Float = try {
        prefs.getFloat(key, defaultValue)
    } catch (_: ClassCastException) {
        val fixedValue =
            when (val rawValue = prefs.all[key]) {
                is Number -> rawValue.toFloat()
                is String -> rawValue.toFloatOrNull()
                else -> null
            }
        if (fixedValue == null || !fixedValue.isFinite()) {
            prefs.edit { remove(key) }
            defaultValue
        } else {
            prefs.edit { putFloat(key, fixedValue) }
            fixedValue
        }
    }

    companion object {
        const val TRACK_HISTORY = "history"
        const val TRACK_FAVOURITES = "favourites"

        const val KEY_ADBLOCK = "adblock"
        const val KEY_LIST_MODE = "list_mode_2"
        const val KEY_LIST_MODE_HISTORY = "list_mode_history"
        const val KEY_LIST_MODE_FAVORITES = "list_mode_favorites"
        const val KEY_LIST_MODE_SUGGESTIONS = "list_mode_suggestions"
        const val KEY_THEME = "theme"
        const val KEY_COLOR_THEME = "color_theme"
        const val KEY_THEME_AMOLED = "amoled_theme"
        const val KEY_MANGA_CARD_STYLE = "manga_card_style"
        const val KEY_APP_FONT = "app_font"
        const val KEY_OFFLINE_DISABLED = "no_offline"
        const val KEY_PAGES_CACHE_CLEAR = "pages_cache_clear"
        const val KEY_HTTP_CACHE_CLEAR = "http_cache_clear"
        const val KEY_COOKIES_CLEAR = "cookies_clear"
        const val KEY_CHAPTERS_CLEAR = "chapters_clear"
        const val KEY_CHAPTERS_CLEAR_AUTO = "chapters_clear_auto"
        const val KEY_THUMBS_CACHE_CLEAR = "thumbs_cache_clear"
        const val KEY_SEARCH_HISTORY_CLEAR = "search_history_clear"
        const val KEY_UPDATES_FEED_CLEAR = "updates_feed_clear"
        const val KEY_GRID_SIZE = "grid_size"
        const val KEY_GRID_SIZE_PAGES = "grid_size_pages"
        const val KEY_GRID_SIZE_DISCOVER = "grid_size_discover"
        const val KEY_REMOTE_SOURCES = "remote_sources"
        const val KEY_LOCAL_STORAGE = "local_storage"
        const val KEY_READER_DOUBLE_PAGES = "reader_double_pages"
        const val KEY_READER_DOUBLE_PAGES_SENSITIVITY = "reader_double_pages_sensitivity_2"
        const val KEY_READER_DOUBLE_FOLDABLE = "reader_double_foldable"
        const val KEY_READER_DOUBLE_COVER_PAGE = "reader_double_cover_page"
        const val KEY_READER_ZOOM_BUTTONS = "reader_zoom_buttons"
        const val KEY_READER_CONTROL_LTR = "reader_taps_ltr"
        const val KEY_READER_NAVIGATION_INVERTED = "reader_navigation_inverted"
        const val KEY_READER_TAP_INVERSION = "reader_tap_inversion"
        const val KEY_READER_VERTICAL_SLIDER = "reader_vertical_slider"
        const val KEY_READER_FULLSCREEN = "reader_fullscreen"
        const val KEY_READER_VOLUME_BUTTONS = "reader_volume_buttons"
        const val KEY_READER_ORIENTATION = "reader_orientation"
        const val KEY_TRACKER_ENABLED = "tracker_enabled"
        const val KEY_TRACKER_WIFI_ONLY = "tracker_wifi"
        const val KEY_TRACKER_FREQUENCY = "tracker_freq"
        const val KEY_TRACK_SOURCES = "track_sources"
        const val KEY_TRACK_CATEGORIES = "track_categories"
        const val KEY_TRACK_WARNING = "track_warning"
        const val KEY_TRACKER_NOTIFICATIONS = "tracker_notifications"
        const val KEY_TRACKER_NO_NSFW = "tracker_no_nsfw"
        const val KEY_TRACKER_DOWNLOAD = "tracker_download"
        const val KEY_TRACKER_UNSTUCK_MIGRATION_V4 = "tracker_unstuck_migration_v4"
        const val KEY_TRACKER_PROGRESS_REFRESH_V1 = "tracker_progress_refresh_v1"
        const val KEY_NOTIFICATIONS_SETTINGS = "notifications_settings"
        const val KEY_NOTIFICATIONS_SOUND = "notifications_sound"
        const val KEY_NOTIFICATIONS_VIBRATE = "notifications_vibrate"
        const val KEY_NOTIFICATIONS_LIGHT = "notifications_light"
        const val KEY_NOTIFICATIONS_INFO = "tracker_notifications_info"
        const val KEY_READER_ANIMATION = "reader_animation2"
        const val KEY_READER_SCALER = "reader_scaler"
        private const val LEGACY_SCALER_BSPLINE = "BSPLINE"
        const val KEY_READER_DOWNSCALER = "reader_downscaler"
        const val KEY_READER_SMART_SHARPEN = "reader_smart_sharpen"
        const val KEY_READER_TILE_DPI = "reader_tile_dpi"
        const val KEY_READER_CONTROLS = "reader_controls"
        const val KEY_READER_MODE = "reader_mode"
        const val KEY_READER_MODE_DETECT = "reader_mode_detect"
        const val KEY_READER_CROP = "reader_crop"
        const val KEY_READER_CROP_TOLERANCE = "reader_crop_tolerance"
        const val KEY_APP_PASSWORD = "app_password"
        const val KEY_APP_PASSWORD_NUMERIC = "app_password_num"
        const val KEY_PROTECT_APP = "protect_app"
        const val KEY_PROTECT_APP_BIOMETRIC = "protect_app_bio"
        const val KEY_ZOOM_MODE = "zoom_mode"
        const val KEY_ZOOM_START = "zoom_start"
        const val KEY_READER_BRIGHTNESS = "reader_brightness"
        const val KEY_READER_DIM = "reader_dim"
        const val KEY_READER_TINT = "reader_tint"
        const val KEY_READER_TINT_STRENGTH = "reader_tint_strength"
        const val MAX_READER_DIM = 80
        const val MAX_READER_TINT_STRENGTH = 60
        const val DEFAULT_READER_TINT_STRENGTH = 25
        const val KEY_READER_HIDE_THRESHOLD = "reader_hide_threshold"
        const val KEY_TAP_TO_PAN = "tap_to_pan"
        const val KEY_DOUBLE_TAP_ZOOM = "reader_double_tap_zoom"
        const val KEY_DOUBLE_TAP_SPEED = "reader_double_tap_speed"
        const val KEY_LANDSCAPE_ZOOM = "landscape_zoom"
        const val KEY_BACKUP = "backup"
        const val KEY_RESTORE = "restore"
        const val KEY_BACKUP_PERIODICAL_ENABLED = "backup_periodic"
        const val KEY_BACKUP_PERIODICAL_FREQUENCY = "backup_periodic_freq"
        const val KEY_BACKUP_PERIODICAL_TRIM = "backup_periodic_trim"
        const val KEY_BACKUP_PERIODICAL_COUNT = "backup_periodic_count"
        const val KEY_BACKUP_PERIODICAL_OUTPUT = "backup_periodic_output"
        const val KEY_BACKUP_PERIODICAL_LAST = "backup_periodic_last"
        const val KEY_HISTORY_GROUPING = "history_grouping"
        const val KEY_UPDATED_GROUPING = "updated_grouping"
        const val KEY_PROGRESS_INDICATORS = "progress_indicators"
        const val KEY_REVERSE_CHAPTERS = "reverse_chapters"
        const val KEY_GRID_VIEW_CHAPTERS = "grid_view_chapters"
        const val KEY_INCOGNITO_NSFW = "incognito_nsfw"
        const val KEY_PAGES_NUMBERS = "pages_numbers"
        const val KEY_ANIMATED_IMAGES = "reader_animated"
        const val KEY_ANIMATED_AUTOPLAY = "reader_animated_autoplay"
        const val KEY_DETAILS_COVER_ANIMATED = "details_cover_animated"
        const val KEY_ANIMATED_CONTROLS = "reader_animated_controls"
        const val KEY_ANIMATED_ADVANCE = "reader_animated_advance"
        const val KEY_ANIMATED_SPEED = "reader_animated_speed"
        const val KEY_ANIMATED_LOOPS = "reader_animated_loops"
        const val KEY_PNG_DECODER = "reader_png_decoder"
        const val KEY_SCREENSHOTS_POLICY = "screenshots_policy"
        const val KEY_PAGES_PRELOAD = "pages_preload"
        const val KEY_SUGGESTIONS = "suggestions"
        const val KEY_SUGGESTIONS_WIFI_ONLY = "suggestions_wifi"
        const val KEY_SUGGESTIONS_EXCLUDE_NSFW = "suggestions_exclude_nsfw"
        const val KEY_SUGGESTIONS_EXCLUDE_TAGS = "suggestions_exclude_tags"
        const val KEY_SUGGESTIONS_DISABLED_SOURCES = "suggestions_disabled_sources"
        const val KEY_SUGGESTIONS_NOTIFICATIONS = "suggestions_notifications"
        const val KEY_SHIKIMORI = "shikimori"
        const val KEY_ANILIST = "anilist"
        const val KEY_MAL = "mal"
        const val KEY_KITSU = "kitsu"
        const val KEY_DOWNLOADS_METERED_NETWORK = "downloads_metered_network"
        const val KEY_DOWNLOADS_FORMAT = "downloads_format"
        const val KEY_DOWNLOAD_AHEAD = "download_ahead"
        const val KEY_ALL_FAVOURITES_VISIBLE = "all_favourites_visible"
        const val KEY_DOH = "doh"
        const val KEY_EXIT_CONFIRM = "exit_confirm"
        const val KEY_INCOGNITO_MODE = "incognito"
        const val KEY_READER_MULTITASK = "reader_multitask"
        const val KEY_READER_BAR = "reader_bar"
        const val KEY_READER_BAR_TRANSPARENT = "reader_bar_transparent"
        const val KEY_READER_CHAPTER_TOAST = "reader_chapter_toast"
        const val KEY_READER_MISSING_WARN = "reader_missing_warn"
        const val KEY_READER_SKIP_DUPES = "reader_skip_dupes"
        const val KEY_READER_BACKGROUND = "reader_background"
        const val KEY_READER_SCREEN_ON = "reader_screen_on"
        const val KEY_SHORTCUTS = "dynamic_shortcuts"
        const val KEY_SHORTCUTS_NO_NSFW = "shortcuts_no_nsfw"
        const val KEY_SYNC_PERIOD = "sync_period"
        const val KEY_READER_TAP_ACTIONS = "reader_tap_actions"
        const val KEY_READER_OPTIMIZE = "reader_optimize"
        const val KEY_EINK_FLASH = "eink_flash"
        const val KEY_EINK_FLASH_DURATION = "eink_flash_duration"
        const val KEY_EINK_FLASH_EVERY = "eink_flash_every"
        const val KEY_EINK_FLASH_COLOR = "eink_flash_color"
        const val KEY_LOCAL_LIST_ORDER = "local_order"
        const val KEY_HISTORY_ORDER = "history_order"
        const val KEY_FAVORITES_ORDER = "fav_order"
        const val KEY_WEBTOON_GAPS = "webtoon_gaps"
        const val KEY_WEBTOON_SIDE_PADDING = "webtoon_side_padding"
        const val KEY_DOUBLE_PAGE_GAP = "double_page_gap"
        const val KEY_WEBTOON_ZOOM = "webtoon_zoom"
        const val KEY_WEBTOON_ZOOM_OUT = "webtoon_zoom_out"
        const val KEY_WEBTOON_PULL_GESTURE = "webtoon_pull_gesture"
        const val KEY_READER_ERASE_GESTURE = "reader_erase_gesture"
        const val KEY_ERASE_TUTORIAL = "erase_tutorial"
        const val TIP_ERASE_TUTORIAL = "erase_tutorial"
        const val KEY_WEBTOON_MEMORY_SAVER = "webtoon_memory_saver"
        const val KEY_MEMORY_SAVER = "memory_saver"
        const val TIP_DISCOVER_DISMISS = "discover_dismiss"
        const val KEY_PREFETCH_CONTENT = "prefetch_content"
        const val KEY_APP_LOCALE = "app_locale"
        const val KEY_SOURCES_GRID = "sources_grid"
        const val KEY_UPDATES_UNSTABLE = "updates_unstable"
        const val KEY_TIPS_CLOSED = "tips_closed"
        const val KEY_SSL_BYPASS = "ssl_bypass"
        const val KEY_CF_AUTO_SOLVE_DISABLED = "cf_auto_solve_disabled"
        const val KEY_READER_AUTOSCROLL_SPEED = "as_speed"
        const val KEY_READER_AUTOSCROLL_FAB = "as_fab"
        const val KEY_MIRROR_SWITCHING = "mirror_switching"
        const val KEY_PROXY = "proxy"
        const val KEY_PROXY_TYPE = "proxy_type_2"
        const val KEY_PROXY_ADDRESS = "proxy_address"
        const val KEY_PROXY_PORT = "proxy_port"
        const val KEY_PROXY_AUTH = "proxy_auth"
        const val KEY_PROXY_LOGIN = "proxy_login"
        const val KEY_PROXY_PASSWORD = "proxy_password"
        const val KEY_IMAGES_PROXY = "images_proxy_2"
        const val KEY_LOCAL_MANGA_DIRS = "local_manga_dirs"
        const val KEY_DISABLE_NSFW = "no_nsfw"
        const val KEY_RELATED_MANGA = "related_manga"
        const val KEY_NAV_MAIN = "nav_main"
        const val KEY_NAV_LABELS = "nav_labels"
        const val KEY_NAV_PINNED = "nav_pinned"
        const val KEY_FLOATING_NAV = "floating_nav"
        const val KEY_MAIN_FAB = "main_fab"
        const val KEY_32BIT_COLOR = "enhanced_colors"
        const val KEY_SOURCES_ORDER = "sources_sort_order"
        const val KEY_SOURCES_CATALOG = "sources_catalog"
        const val KEY_CF_BRIGHTNESS = "cf_brightness"
        const val KEY_CF_CONTRAST = "cf_contrast"

        // Legacy (pre-split) keys: read once as a fallback in [readerColorFilter], then removed on save.
        const val KEY_CF_SHARPENING = "cf_sharpening"
        const val KEY_CF_SATURATION = "cf_vibrance"
        const val KEY_CF_VIBRANCE = "cf_vibrance2"
        const val KEY_CF_INVERTED = "cf_inverted"
        const val KEY_CF_GRAYSCALE = "cf_grayscale"
        const val KEY_CF_BOOK = "cf_book"
        const val KEY_CF_DENOISE = "cf_denoise"
        const val KEY_CF_SHARPEN_MODE = "cf_sharpen_mode"

        // Superseded (mislabeled) keys: read once as a fallback in [readerColorFilter], then removed on save.
        const val KEY_CF_RCAS_USM = "cf_rcas_usm"
        const val KEY_CF_ADAPTIVE_SMOOTHSTEP = "cf_adaptive_smoothstep"
        const val KEY_CF_ADAPTIVE_SIGMOID = "cf_adaptive_sigmoid"
        const val KEY_CF_RCAS = "cf_rcas"
        const val KEY_CF_ADAPTIVE_SHARPEN = "cf_adaptive_sharpen"
        const val KEY_CF_DEBAND = "cf_deband"
        const val KEY_CF_BINARIZE = "cf_binarize"
        const val KEY_CF_LINE_DARKEN = "cf_line_darken"
        const val KEY_CF_AUTO_CONTRAST = "cf_auto_contrast"
        const val KEY_CF_AUTO_BRIGHTNESS = "cf_auto_brightness"
        const val KEY_CF_AUTO_SATURATION = "cf_auto_saturation"
        const val KEY_CF_OVERLAY_R = "cf_overlay_r"
        const val KEY_CF_OVERLAY_G = "cf_overlay_g"
        const val KEY_CF_OVERLAY_B = "cf_overlay_b"
        const val KEY_CF_OVERLAY_A = "cf_overlay_a"
        const val KEY_PAGES_TAB = "pages_tab"
        const val KEY_PAGE_FORMAT_BADGE = "page_format_badge"
        const val KEY_PAGE_ANIMATED_BADGE = "page_animated_badge"
        const val KEY_PAGE_BADGE_HIDE_COMMON = "page_badge_hide_common"
        const val KEY_DETAILS_TAB = "details_tab"
        const val KEY_DETAILS_LAST_TAB = "details_last_tab"
        const val KEY_READING_TIME = "reading_time"
        const val KEY_PAGES_SAVE_DIR = "pages_dir"
        const val KEY_PAGES_SAVE_ASK = "pages_dir_ask"
        const val KEY_CBZ_AUTO_REPACK = "cbz_auto_repack"
        const val KEY_TALL_SPLIT = "split_tall_images"
        const val KEY_TALL_SPLIT_QUALITY = "tall_split_quality"
        const val KEY_WEBP_QUALITY_AUTO = "webp_quality_auto"
        const val KEY_CONVERT_WEBP_DOWNLOAD = "convert_webp_download"
        const val KEY_DUAL_SPLIT = "split_dual_pages"
        const val DUAL_SPLIT_OFF = 0
        const val DUAL_SPLIT_LTR = 1
        const val DUAL_SPLIT_RTL = 2
        const val KEY_STATS_ENABLED = "stats_on"
        const val KEY_FEED_HEADER = "feed_header"
        const val KEY_SEARCH_SUGGESTION_TYPES = "search_suggest_types"
        const val KEY_SOURCES_VERSION = "sources_version"
        const val KEY_SOURCES_ENABLED_ALL = "sources_enabled_all"
        const val KEY_SOURCES_NEW_DOWNLOADED = "sources_new_downloaded"
        const val KEY_PARSERS_AUTO_UPDATE = "parsers_auto_update"
        const val KEY_QUICK_FILTER = "quick_filter"
        const val KEY_COLLAPSE_DESCRIPTION = "description_collapse"
        const val KEY_BACKUP_TG_ENABLED = "backup_periodic_tg_enabled"
        const val KEY_BACKUP_TG_CHAT = "backup_periodic_tg_chat_id"
        const val KEY_MANGA_LIST_BADGES = "manga_list_badges"
        const val KEY_DISCORD_RPC = "discord_rpc"
        const val KEY_DISCORD_RPC_SKIP_NSFW = "discord_rpc_skip_nsfw"
        const val KEY_DISCORD_TOKEN = "discord_token"
        const val KEY_ACTIVE_SOURCE_PRESET = "active_source_preset"

        /** Device-bound or secret: never written to a backup, never imported, never erased by a restore. */
        val BACKUP_LOCAL_KEYS: Set<String> = setOf(
            KEY_LOCAL_STORAGE,
            KEY_LOCAL_MANGA_DIRS,
            KEY_PAGES_SAVE_DIR,
            KEY_BACKUP_PERIODICAL_ENABLED,
            KEY_BACKUP_PERIODICAL_OUTPUT,
            KEY_BACKUP_PERIODICAL_LAST,
            KEY_BACKUP_TG_ENABLED,
            KEY_BACKUP_TG_CHAT,
            KEY_APP_VERSION,
            KEY_PROTECT_APP,
            KEY_PROTECT_APP_BIOMETRIC,
            KEY_APP_PASSWORD,
            KEY_APP_PASSWORD_NUMERIC,
            KEY_PROXY_AUTH,
            KEY_PROXY_LOGIN,
            KEY_PROXY_PASSWORD,
            KEY_INCOGNITO_MODE,
            KEY_DISCORD_TOKEN,
        )

        private val FLOAT_PREFERENCE_KEYS =
            setOf(
                KEY_READER_DOUBLE_PAGES_SENSITIVITY,
                KEY_CF_BRIGHTNESS,
                KEY_CF_CONTRAST,
                KEY_READER_AUTOSCROLL_SPEED,
            )

        // keys for non-persistent preferences
        const val KEY_APP_VERSION = "app_version"
        const val KEY_IGNORE_DOZE = "ignore_dose"
        const val KEY_TRACKER_DEBUG = "tracker_debug"
        const val KEY_LINK_WEBLATE = "about_app_translation"
        const val KEY_LINK_DISCORD = "about_discord"
        const val KEY_LINK_GITHUB = "about_github"
        const val KEY_LINK_MANUAL = "about_help"
        const val KEY_PROXY_TEST = "proxy_test"
        const val KEY_OPEN_BROWSER = "open_browser"
        const val KEY_HANDLE_LINKS = "handle_links"
        const val KEY_BACKUP_TG = "backup_periodic_tg"
        const val KEY_BACKUP_TG_OPEN = "backup_periodic_tg_open"
        const val KEY_BACKUP_TG_TEST = "backup_periodic_tg_test"
        const val KEY_CLEAR_MANGA_DATA = "manga_data_clear"
        const val KEY_STORAGE_USAGE = "storage_usage"
        const val KEY_WEBVIEW_CLEAR = "webview_clear"

        // old keys are for migration only
        private const val KEY_IMAGES_PROXY_OLD = "images_proxy"

        // values
        private const val READER_CROP_PAGED = 1
        private const val READER_CROP_WEBTOON = 2

        /** Sync period options offered in settings, in hours. `0` means "only when local data changes". */
        @JvmField
        val SYNC_PERIODS = intArrayOf(0, 1, 6, 12, 24)
        const val SYNC_PERIOD_DEFAULT = 6
    }
}
