package org.koitharu.kotatsu.settings.sources.catalog

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import org.koitharu.kotatsu.list.ui.model.ListModel
import org.koitharu.kotatsu.parsers.model.ParserMangaSource

sealed interface SourceCatalogItem : ListModel {

    data class Source(
        val source: ParserMangaSource,
        val isInPreset: Boolean = false,
    ) : SourceCatalogItem {

        override fun areItemsTheSame(other: ListModel): Boolean = other is Source && other.source == source
    }

    data class Hint(
        @DrawableRes val icon: Int,
        @StringRes val title: Int,
        @StringRes val text: Int,
    ) : SourceCatalogItem {

        override fun areItemsTheSame(other: ListModel): Boolean = other is Hint && other.title == title
    }
}
