plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.room) apply false
    alias(libs.plugins.kotlinx.serizliation) apply false
    alias(libs.plugins.compose.compiler) apply false
    // alias(libs.plugins.decoroutinator) apply false

    // Code Formatting & Static Analysis
    id("com.diffplug.spotless") version "8.10.2" apply false
    id("io.gitlab.arturbosch.detekt") version "1.23.8" apply false
}

subprojects {
    // ---- Spotless Formatting Configuration ----
    apply(plugin = "com.diffplug.spotless")
    configure<com.diffplug.gradle.spotless.SpotlessExtension> {
        kotlin {
            target("**/*.kt")
            targetExclude("**/build/**/*.kt", "**/bin/**/*.kt")

            // Auto-fixes formatting, spacing, & removes unused imports
            ktlint("1.8.0").editorConfigOverride(
                mapOf(
                    "indent_size" to "4",
                    "continuation_indent_size" to "4",
                    "ij_kotlin_allow_trailing_comma" to "true",
                    "ktlint_standard_no-unused-imports" to "enabled",
                    // Long single-line @Query/SQL strings (DAOs, Room migrations) are more
                    // readable unwrapped; enforcing 120 cols here would require breaking SQL
                    // literals across dozens of pre-existing files for no functional benefit.
                    "ktlint_standard_max-line-length" to "disabled",
                ),
            )
            trimTrailingWhitespace()
            endWithNewline()

            // Belt-and-suspenders: even if a rule fires despite the override above
            // (e.g. on files added after this config), don't fail the build over it.
            suppressLintsFor {
                step = "ktlint"
                shortCode = "standard:max-line-length"
            }
            suppressLintsFor {
                step = "ktlint"
                shortCode = "standard:function-naming"
            }
        }
        kotlinGradle {
            target("**/*.gradle.kts")
            ktlint("1.8.0")
        }
    }

    // ---- Detekt Static Analysis Configuration ----
    apply(plugin = "io.gitlab.arturbosch.detekt")
    configure<io.gitlab.arturbosch.detekt.extensions.DetektExtension> {
        buildUponDefaultConfig = true
        allRules = false
        config.setFrom(files("$rootDir/config/detekt/detekt.yml"))
        autoCorrect = true
    }
}
