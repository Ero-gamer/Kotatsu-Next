package org.koitharu.kotatsu.core.db.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow
import org.koitharu.kotatsu.core.db.entity.MangaPrefsEntity

@Dao
abstract class PreferencesDao {

    @Query("SELECT * FROM preferences WHERE manga_id = :mangaId")
    abstract suspend fun find(mangaId: Long): MangaPrefsEntity?

    @Query("SELECT * FROM preferences WHERE manga_id = :mangaId")
    abstract fun observe(mangaId: Long): Flow<MangaPrefsEntity?>

    @Query("SELECT * FROM preferences WHERE title_override IS NOT NULL OR cover_override IS NOT NULL OR content_rating_override IS NOT NULL")
    abstract suspend fun getOverrides(): List<MangaPrefsEntity>

    @Query(
        "UPDATE preferences SET cf_brightness=0, cf_contrast=0, cf_invert=0, cf_grayscale=0, " +
            "cf_sharpening=0, cf_vibrance=0, cf_vibrance2=0, cf_denoise=0, cf_dither=0, cf_grain=0, " +
            "cf_sharpen_mode=0, cf_line_darken=0, cf_book=0, cf_disabled=0, cf_rcas_usm=0, " +
            "cf_adaptive_smoothstep=0, cf_adaptive_sigmoid=0, cf_catmull_rom=0, cf_bspline=0, " +
            "cf_rcas=0, cf_adaptive_sharpen=0, cf_deband=0",
    )
    abstract suspend fun resetColorFilters()

    @Upsert
    abstract suspend fun upsert(pref: MangaPrefsEntity)
}
