package org.koitharu.kotatsu.reader.ui.colorfilter

import androidx.lifecycle.SavedStateHandle
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import org.koitharu.kotatsu.core.model.parcelable.ParcelableManga
import org.koitharu.kotatsu.core.model.parcelable.ParcelableMangaPage
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.parser.MangaDataRepository
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.ui.BaseViewModel
import org.koitharu.kotatsu.core.util.ext.MutableEventFlow
import org.koitharu.kotatsu.core.util.ext.call
import org.koitharu.kotatsu.core.util.ext.require
import org.koitharu.kotatsu.reader.domain.ReaderColorFilter
import javax.inject.Inject

@HiltViewModel
class ColorFilterConfigViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val settings: AppSettings,
    private val mangaDataRepository: MangaDataRepository,
) : BaseViewModel() {

    private val manga = savedStateHandle.require<ParcelableManga>(AppRouter.KEY_MANGA).manga

    val preview = savedStateHandle.require<ParcelableMangaPage>(AppRouter.KEY_PAGES).page

    private var initialColorFilter: ReaderColorFilter? = null
    val colorFilter = MutableStateFlow<ReaderColorFilter?>(null)
    val onDismiss = MutableEventFlow<Unit>()

    val isChanged: Boolean
        get() = colorFilter.value != initialColorFilter

    init {
        launchLoadingJob {
            initialColorFilter = mangaDataRepository.getColorFilter(manga.id) ?: settings.readerColorFilter
            colorFilter.value = initialColorFilter
        }
    }

    fun setBrightness(brightness: Float) = updateColorFilter { it.copy(brightness = brightness) }
    fun setContrast(contrast: Float) = updateColorFilter { it.copy(contrast = contrast) }
    fun setRcasUsm(intensity: Float) = updateColorFilter { it.copy(rcasUsm = intensity) }
    fun setAdaptiveSmoothstep(intensity: Float) = updateColorFilter { it.copy(adaptiveSmoothstep = intensity) }
    fun setAdaptiveSigmoid(intensity: Float) = updateColorFilter { it.copy(adaptiveSigmoid = intensity) }
    fun setSaturation(saturation: Float) = updateColorFilter { it.copy(saturation = saturation) }
    fun setVibrance(vibrance: Float) = updateColorFilter { it.copy(vibrance = vibrance) }
    fun setDenoise(denoise: Float) = updateColorFilter { it.copy(denoise = denoise) }
    fun setLineDarkenEnabled(enabled: Boolean) = updateColorFilter { it.copy(isLineDarkenEnabled = enabled) }

    // setDither / setGrain removed — filters eliminated from GPU pipeline
    fun setInversion(invert: Boolean) = updateColorFilter { it.copy(isInverted = invert) }
    fun setGrayscale(grayscale: Boolean) = updateColorFilter { it.copy(isGrayscale = grayscale) }
    fun setBookEffect(book: Boolean) = updateColorFilter { it.copy(isBookBackground = book) }

    fun reset() {
        colorFilter.value = null
    }

    fun save() {
        launchLoadingJob(Dispatchers.Default) {
            mangaDataRepository.saveColorFilter(manga, colorFilter.value)
            onDismiss.call(Unit)
        }
    }

    fun saveGlobally() {
        launchLoadingJob(Dispatchers.Default) {
            settings.readerColorFilter = colorFilter.value
            mangaDataRepository.resetColorFilters()
            onDismiss.call(Unit)
        }
    }

    private inline fun updateColorFilter(block: (ReaderColorFilter) -> ReaderColorFilter) {
        colorFilter.value = block(
            colorFilter.value ?: ReaderColorFilter.EMPTY,
        ).takeUnless { it.isEmpty }
    }
}
